import sharp from "sharp";
import { mkdirSync } from "node:fs";
const svg = (rounded, pad = 0) => `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#13201c"/><stop offset="1" stop-color="#07090b"/></linearGradient>
<linearGradient id="ln" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6ee7b7"/><stop offset="1" stop-color="#10b981"/></linearGradient>
</defs>
<rect width="512" height="512" rx="${rounded ? 112 : 0}" fill="url(#bg)"/>
<g transform="translate(${pad} ${pad}) scale(${(512 - 2 * pad) / 512})">
<path d="M104 150 C 170 150, 196 352, 262 352 C 322 352, 350 236, 408 168" fill="none" stroke="url(#ln)" stroke-width="46" stroke-linecap="round"/>
<circle cx="408" cy="168" r="34" fill="#d1fae5"/>
<path d="M104 410 H 408" stroke="#ffffff" stroke-opacity="0.12" stroke-width="14" stroke-linecap="round"/>
</g>
</svg>`;
mkdirSync("public/icons", { recursive: true });
await sharp(Buffer.from(svg(true))).resize(192).png().toFile("public/icons/icon-192.png");
await sharp(Buffer.from(svg(true))).resize(512).png().toFile("public/icons/icon-512.png");
await sharp(Buffer.from(svg(false, 70))).resize(512).png().toFile("public/icons/maskable-512.png");
await sharp(Buffer.from(svg(false))).resize(180).png().toFile("public/icons/apple-touch-icon.png");
await sharp(Buffer.from(svg(true))).resize(32).png().toFile("public/favicon.png");
console.log("icons ok");
