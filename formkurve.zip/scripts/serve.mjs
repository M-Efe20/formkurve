// Mini-Static-Server für Tests: bildet GitHub Pages mit basePath nach
import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { join, extname } from "node:path";
const BASE = process.env.BASE || "/formkurve";
const PORT = +(process.env.PORT || 4173);
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml", ".txt": "text/plain", ".woff2": "font/woff2" };
http.createServer(async (req, res) => {
  let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (!p.startsWith(BASE)) { res.writeHead(404); return res.end("not found"); }
  p = p.slice(BASE.length) || "/";
  let file = join("out", p);
  try {
    const s = await stat(file);
    if (s.isDirectory()) file = join(file, "index.html");
  } catch {}
  try {
    const data = await readFile(file);
    res.writeHead(200, { "Content-Type": TYPES[extname(file)] || "application/octet-stream" });
    res.end(data);
  } catch {
    try { const d = await readFile(join("out", "404.html")); res.writeHead(404, { "Content-Type": TYPES[".html"] }); res.end(d); }
    catch { res.writeHead(404); res.end("not found"); }
  }
}).listen(PORT, () => console.log(`serving out/ at http://localhost:${PORT}${BASE}/`));
