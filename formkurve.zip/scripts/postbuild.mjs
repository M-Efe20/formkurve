// Füllt den Service Worker mit allen Dateien aus out/ und setzt eine Build-Version
import { readdirSync, statSync, readFileSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import { createHash } from "node:crypto";

const OUT = "out";
const files = [];
(function walk(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p);
    else files.push(relative(OUT, p).split("\\").join("/"));
  }
})(OUT);

const precache = files
  .filter((f) => !f.endsWith(".map") && f !== "sw.js" && !f.startsWith("404") && f !== ".nojekyll" && !f.endsWith("favicon.png"))
  .map((f) => (f === "index.html" ? "./" : f.endsWith("/index.html") ? "./" + f.slice(0, -"index.html".length) : "./" + f));

const hash = createHash("sha256");
for (const f of files.sort()) if (f !== "sw.js") hash.update(f + readFileSync(join(OUT, f)).length);
const version = hash.digest("hex").slice(0, 10);

const swPath = join(OUT, "sw.js");
let sw = readFileSync(swPath, "utf8");
sw = sw.replace("__VERSION__", version).replace("__PRECACHE__", JSON.stringify(precache));
writeFileSync(swPath, sw);
writeFileSync(join(OUT, ".nojekyll"), "");
console.log(`SW: ${precache.length} Dateien, Version ${version}`);
