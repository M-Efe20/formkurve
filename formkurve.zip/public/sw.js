/* Formkurve Service Worker – wird beim Build mit Precache-Liste befüllt */
const VERSION = "__VERSION__";
const PRECACHE = __PRECACHE__;
const CACHE = "formkurve-" + VERSION;
const SCOPE = self.registration.scope;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(PRECACHE.map((p) => new URL(p, SCOPE).toString())))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith("formkurve-") && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // APIs (Open Food Facts, Claude) nie cachen

  if (req.mode === "navigate") {
    // Network-first für Seiten, offline aus dem Cache
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(async () => (await caches.match(req, { ignoreSearch: true })) || (await caches.match(new URL("./", SCOPE).toString())) || Response.error()),
    );
    return;
  }

  // Cache-first für statische Dateien
  const ignoreSearch = url.pathname.includes("/_next/static/") || url.pathname.endsWith(".txt");
  event.respondWith(
    caches.match(req, { ignoreSearch }).then(
      (hit) =>
        hit ||
        fetch(req).then((res) => {
          if (res.ok && res.type === "basic") {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        }),
    ),
  );
});
