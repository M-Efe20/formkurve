"use client";
import { useEffect, useState, type ReactNode } from "react";
import { ensureSeed } from "@/lib/store";
import { useSettings } from "@/lib/hooks";
import { ToastProvider } from "./Toast";
import { BottomNav } from "./BottomNav";
import { Onboarding } from "./Onboarding";
import { AdaptiveUpdater } from "./AdaptiveUpdater";

const BASE = process.env.NEXT_PUBLIC_BASE_PATH || "";

export default function AppShell({ children }: { children: ReactNode }) {
  const settings = useSettings();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    ensureSeed()
      .then(() => setReady(true))
      .catch((e) => setError(String(e?.message || e)));
  }, []);

  // Theme
  const theme = settings?.theme;
  useEffect(() => {
    if (!theme) return;
    try {
      localStorage.setItem("fk-theme", theme);
    } catch {}
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = theme === "dark" || (theme === "system" && mq.matches);
      document.documentElement.classList.toggle("dark", dark);
      document.querySelector('meta[name="theme-color"]:not([media])')?.setAttribute("content", dark ? "#0b0c0f" : "#f3f4f6");
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [theme]);

  // Service Worker (nur im Produktions-Build)
  useEffect(() => {
    if (process.env.NODE_ENV !== "production" || !("serviceWorker" in navigator)) return;
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register(`${BASE}/sw.js`, { scope: `${BASE}/` }).catch(() => {});
    let reloaded = false;
    const onChange = () => {
      if (!hadController || reloaded) return;
      reloaded = true;
      window.location.reload();
    };
    navigator.serviceWorker.addEventListener("controllerchange", onChange);
    return () => navigator.serviceWorker.removeEventListener("controllerchange", onChange);
  }, []);

  if (error) {
    return (
      <div className="mx-auto max-w-md p-6 pt-safe">
        <h1 className="mt-10 text-xl font-bold">Speicher nicht verfügbar</h1>
        <p className="mt-2 text-muted">Die App braucht lokalen Browser-Speicher (IndexedDB). Bitte privaten Modus deaktivieren.</p>
        <pre className="mt-4 whitespace-pre-wrap text-xs text-muted">{error}</pre>
      </div>
    );
  }

  if (!ready || !settings) {
    return <div className="flex min-h-dvh items-center justify-center text-muted" aria-busy="true" />;
  }

  return (
    <ToastProvider>
      {!settings.onboarded ? (
        <Onboarding />
      ) : (
        <>
          <AdaptiveUpdater settings={settings} />
          <main className="mx-auto max-w-xl px-4 pb-nav">{children}</main>
          <BottomNav />
        </>
      )}
    </ToastProvider>
  );
}
