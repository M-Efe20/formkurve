"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Camera, Trash2, Sparkles, AlertTriangle, Plus } from "lucide-react";
import { MEALS, type Food, type MealKey } from "@/lib/db";
import { useSettings } from "@/lib/hooks";
import { aiEstimatePhoto, type PhotoItem } from "@/lib/coach";
import { blobToBase64, compressImage } from "@/lib/image";
import { logFood, upsertFood } from "@/lib/store";
import { fmt, sumNutrients } from "@/lib/calc";
import { Button, IconButton, Notice, NumberInput, Segmented, Sheet, TextInput } from "./ui";
import { MacroPills } from "./FoodBits";
import { useToast } from "./Toast";

export function PhotoEstimateSheet({ open, onClose, date, meal: initialMeal }: { open: boolean; onClose: () => void; date: string; meal: MealKey }) {
  const settings = useSettings();
  const toast = useToast();
  const [img, setImg] = useState<Blob | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [items, setItems] = useState<PhotoItem[] | null>(null);
  const [meta, setMeta] = useState<{ confidence?: string; hinweis?: string }>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [meal, setMeal] = useState<MealKey>(initialMeal);

  useEffect(() => {
    if (open) {
      setMeal(initialMeal);
    } else {
      setImg(null);
      setItems(null);
      setNote("");
      setError(null);
      setMeta({});
    }
  }, [open, initialMeal]);

  useEffect(() => {
    if (!img) {
      setPreview(null);
      return;
    }
    const u = URL.createObjectURL(img);
    setPreview(u);
    return () => URL.revokeObjectURL(u);
  }, [img]);

  const pick = async (f: File | undefined) => {
    if (!f) return;
    setError(null);
    setItems(null);
    try {
      setImg(await compressImage(f, 1024, 0.8));
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const analyze = async () => {
    if (!img || !settings) return;
    setBusy(true);
    setError(null);
    try {
      const b64 = await blobToBase64(img);
      const r = await aiEstimatePhoto(settings, b64, note.trim());
      setItems(r.items);
      setMeta({ confidence: r.confidence, hinweis: r.hinweis });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const setItem = (i: number, patch: Partial<PhotoItem>) =>
    setItems((cur) =>
      cur!.map((it, j) => {
        if (j !== i) return it;
        if (patch.grams != null && it.grams > 0 && patch.grams > 0) {
          const f = patch.grams / it.grams;
          return { ...it, grams: patch.grams, kcal: Math.round(it.kcal * f), protein: round1(it.protein * f), carbs: round1(it.carbs * f), fat: round1(it.fat * f) };
        }
        return { ...it, ...patch };
      }),
    );

  const confirm = async () => {
    if (!items?.length) return;
    for (const it of items) {
      if (!it.grams) continue;
      const f = 100 / it.grams;
      const food: Food = {
        name: it.name,
        source: "ai",
        kcal: Math.round(it.kcal * f),
        protein: round1(it.protein * f),
        carbs: round1(it.carbs * f),
        fat: round1(it.fat * f),
        units: [],
        favorite: 0,
        useCount: 0,
        updatedAt: Date.now(),
      };
      const id = await upsertFood(food);
      await logFood({ ...food, id }, it.grams, "g", meal, date);
    }
    toast({ text: `${items.length} Komponente${items.length === 1 ? "" : "n"} eingetragen` });
    onClose();
  };

  const total = sumNutrients(items || []);
  const hasKey = !!settings?.apiKey;

  return (
    <Sheet
      open={open}
      onClose={onClose}
      full
      title="Foto analysieren (KI)"
      testId="photo-sheet"
      footer={
        items ? (
          <Button size="lg" className="w-full" onClick={confirm} disabled={!items.length} data-testid="photo-confirm">
            Bestätigen & eintragen · {fmt(total.kcal)} kcal
          </Button>
        ) : (
          <Button size="lg" className="w-full" onClick={analyze} disabled={!img || busy || !hasKey} data-testid="photo-analyze">
            {busy ? (
              "Claude schätzt …"
            ) : (
              <>
                <Sparkles size={18} /> Kalorien schätzen
              </>
            )}
          </Button>
        )
      }
    >
      <div className="space-y-4">
        {!hasKey && (
          <Notice tone="warn">
            Für die Foto-Schätzung brauchst du einen Claude API-Key.{" "}
            <Link href="/settings/" className="underline" onClick={onClose}>
              Jetzt eintragen
            </Link>
          </Notice>
        )}
        <label className="relative flex aspect-[4/3] w-full cursor-pointer items-center justify-center overflow-hidden rounded-3xl bg-card2">
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="Mahlzeit" className="h-full w-full object-cover" />
          ) : (
            <span className="flex flex-col items-center gap-2 text-muted">
              <Camera size={32} />
              <span className="font-semibold">Foto aufnehmen oder auswählen</span>
            </span>
          )}
          <input type="file" accept="image/*" className="hidden" onChange={(e) => pick(e.target.files?.[0])} data-testid="photo-file" />
        </label>
        {!items && <TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional: z. B. „mit 1 EL Olivenöl, Reis ca. 200 g“" />}
        {error && <Notice tone="danger">{error}</Notice>}

        {items && (
          <>
            <Segmented size="sm" value={meal} onChange={setMeal} options={MEALS.map((m) => ({ value: m.key, label: m.label.replace("essen", "") }))} />
            <MacroPills {...total} />
            {meta.hinweis && (
              <Notice tone="warn">
                <span className="flex gap-2">
                  <AlertTriangle size={16} className="mt-0.5 shrink-0" /> {meta.hinweis}
                </span>
              </Notice>
            )}
            {meta.confidence && <div className="text-xs text-muted">Sicherheit der Schätzung: {meta.confidence}. Prüfe die Mengen und korrigiere sie bei Bedarf.</div>}
            <div className="space-y-3" data-testid="photo-items">
              {items.map((it, i) => (
                <div key={i} className="rounded-2xl bg-card2 p-3">
                  <div className="flex items-center gap-2">
                    <TextInput value={it.name} onChange={(e) => setItem(i, { name: e.target.value })} className="h-10 flex-1 bg-card" aria-label="Name" />
                    <IconButton label="Komponente entfernen" onClick={() => setItems(items.filter((_, j) => j !== i))} className="bg-card">
                      <Trash2 size={16} />
                    </IconButton>
                  </div>
                  <div className="mt-2 grid grid-cols-5 gap-1.5 text-center text-[11px] text-muted">
                    <span>Gramm</span>
                    <span>kcal</span>
                    <span>Eiweiß</span>
                    <span>KH</span>
                    <span>Fett</span>
                    <MiniNum value={it.grams} onChange={(v) => setItem(i, { grams: v })} label="Gramm" />
                    <MiniNum value={it.kcal} onChange={(v) => setItem(i, { kcal: v })} label="kcal" />
                    <MiniNum value={it.protein} onChange={(v) => setItem(i, { protein: v })} label="Eiweiß" />
                    <MiniNum value={it.carbs} onChange={(v) => setItem(i, { carbs: v })} label="Kohlenhydrate" />
                    <MiniNum value={it.fat} onChange={(v) => setItem(i, { fat: v })} label="Fett" />
                  </div>
                </div>
              ))}
              <Button variant="soft" size="sm" onClick={() => setItems([...items, { name: "Weitere Komponente", grams: 100, kcal: 0, protein: 0, carbs: 0, fat: 0 }])}>
                <Plus size={14} /> Komponente
              </Button>
            </div>
          </>
        )}
      </div>
    </Sheet>
  );
}

function MiniNum({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  return <NumberInput value={value} onChange={(v) => onChange(v ?? 0)} aria-label={label} className="[&_input]:h-10 [&_input]:px-1 [&_input]:text-center [&_input]:bg-card" />;
}

const round1 = (n: number) => Math.round(n * 10) / 10;
