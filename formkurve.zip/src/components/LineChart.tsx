"use client";
import { useMemo, useRef, useState } from "react";
import { daysBetween, formatDate } from "@/lib/dates";
import { fmt } from "@/lib/calc";

export interface ChartPoint {
  date: string;
  value: number;
  trend?: number;
}

/** Schlanker SVG-Linienchart: Rohwerte als Punkte, Trend (7-Tage-Ø) als Linie, optionale Ziellinie */
export function LineChart({
  points,
  goal,
  unit = "kg",
  height = 200,
  digits = 1,
  testId,
}: {
  points: ChartPoint[];
  goal?: number;
  unit?: string;
  height?: number;
  digits?: number;
  testId?: string;
}) {
  const ref = useRef<SVGSVGElement>(null);
  const [hover, setHover] = useState<number | null>(null);
  const W = 360;
  const H = height;
  const padL = 34;
  const padR = 10;
  const padT = 12;
  const padB = 22;

  const geo = useMemo(() => {
    if (points.length === 0) return null;
    const first = points[0].date;
    const span = Math.max(1, daysBetween(first, points[points.length - 1].date));
    const vals = points.flatMap((p) => [p.value, p.trend ?? p.value]);
    let min = Math.min(...vals);
    let max = Math.max(...vals);
    if (goal != null && goal >= min - 3 && goal <= max + 3) {
      min = Math.min(min, goal);
      max = Math.max(max, goal);
    }
    const pad = Math.max(0.5, (max - min) * 0.12);
    min -= pad;
    max += pad;
    const x = (d: string) => padL + (daysBetween(first, d) / span) * (W - padL - padR);
    const y = (v: number) => padT + (1 - (v - min) / (max - min)) * (H - padT - padB);
    const ticks = [0, 1, 2, 3].map((i) => min + ((max - min) * i) / 3);
    return { x, y, ticks, min, max, span };
  }, [points, goal, H]);

  if (!geo) return <div className="flex h-40 items-center justify-center text-sm text-muted">Noch keine Daten</div>;
  const { x, y, ticks } = geo;
  const trendPts = points.filter((p) => p.trend != null);
  const path = trendPts.map((p, i) => `${i ? "L" : "M"}${x(p.date).toFixed(1)},${y(p.trend!).toFixed(1)}`).join(" ");
  const h = hover != null ? points[hover] : points[points.length - 1];

  const onMove = (clientX: number) => {
    const svg = ref.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const px = ((clientX - rect.left) / rect.width) * W;
    let best = 0;
    let bd = Infinity;
    points.forEach((p, i) => {
      const d = Math.abs(x(p.date) - px);
      if (d < bd) {
        bd = d;
        best = i;
      }
    });
    setHover(best);
  };

  return (
    <div data-testid={testId}>
      <div className="mb-1 flex items-baseline justify-between text-sm">
        <span className="text-muted">{formatDate(h.date, { day: "numeric", month: "short", year: "2-digit" })}</span>
        <span>
          <b className="tabular">{fmt(h.value, digits, digits)} {unit}</b>
          {h.trend != null && <span className="text-muted tabular"> · Ø {fmt(h.trend, digits, digits)}</span>}
        </span>
      </div>
      <svg
        ref={ref}
        viewBox={`0 0 ${W} ${H}`}
        className="w-full touch-none select-none"
        onPointerMove={(e) => onMove(e.clientX)}
        onPointerDown={(e) => onMove(e.clientX)}
        onPointerLeave={() => setHover(null)}
      >
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--line)" strokeWidth={1} />
            <text x={padL - 6} y={y(t) + 4} textAnchor="end" fontSize={10} fill="var(--muted)">
              {fmt(t, 0)}
            </text>
          </g>
        ))}
        {goal != null && goal >= geo.min && goal <= geo.max && (
          <g>
            <line x1={padL} x2={W - padR} y1={y(goal)} y2={y(goal)} stroke="var(--accent)" strokeDasharray="5 5" strokeWidth={1.5} opacity={0.8} />
            <text x={W - padR} y={y(goal) - 4} textAnchor="end" fontSize={10} fill="var(--accent)">
              Ziel {fmt(goal, 1)}
            </text>
          </g>
        )}
        {points.map((p) => (
          <circle key={p.date} cx={x(p.date)} cy={y(p.value)} r={points.length > 60 ? 1.6 : 2.6} fill="var(--muted)" opacity={0.55} />
        ))}
        {trendPts.length > 1 && <path d={path} fill="none" stroke="var(--accent)" strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" />}
        {hover != null && (
          <g>
            <line x1={x(h.date)} x2={x(h.date)} y1={padT} y2={H - padB} stroke="var(--muted)" strokeWidth={1} opacity={0.6} />
            <circle cx={x(h.date)} cy={y(h.trend ?? h.value)} r={5} fill="var(--accent)" stroke="var(--card)" strokeWidth={2} />
          </g>
        )}
        <text x={padL} y={H - 6} fontSize={10} fill="var(--muted)">
          {formatDate(points[0].date, { day: "numeric", month: "short" })}
        </text>
        <text x={W - padR} y={H - 6} fontSize={10} fill="var(--muted)" textAnchor="end">
          {formatDate(points[points.length - 1].date, { day: "numeric", month: "short" })}
        </text>
      </svg>
    </div>
  );
}
