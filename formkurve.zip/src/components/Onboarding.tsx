"use client";
import { useEffect, useMemo, useState } from "react";
import { Button, Card, Field, NumberInput, Segmented, Select, Notice } from "./ui";
import { ScheduleEditor } from "./ScheduleEditor";
import { computeTargets, defaultSettings, fmt, NEAT_LEVELS } from "@/lib/calc";
import type { Settings } from "@/lib/db";
import { completeOnboarding } from "@/lib/store";
import { todayStr } from "@/lib/dates";
import { importData, parseBackup } from "@/lib/backup";

/** Optionales Vorbefüllen über Link: …/#setup=<base64 JSON> (bleibt lokal, Hash wird nie an Server gesendet) */
function readSetupHash(): Partial<Settings> {
  try {
    const m = window.location.hash.match(/setup=([^&]+)/);
    if (!m) return {};
    const json = JSON.parse(decodeURIComponent(escape(atob(m[1].replace(/-/g, "+").replace(/_/g, "/")))));
    const out: Partial<Settings> = {};
    if (json.sex === "m" || json.sex === "f") out.sex = json.sex;
    for (const k of ["age", "heightCm", "startWeightKg", "goalWeightKg", "deficit", "neatFactor"] as const) {
      if (typeof json[k] === "number") (out as Record<string, number>)[k] = json[k];
    }
    return out;
  } catch {
    return {};
  }
}

export function Onboarding() {
  const [step, setStep] = useState(0);
  const [s, setS] = useState<Settings>(() => ({ ...defaultSettings(), age: NaN, heightCm: NaN, startWeightKg: NaN, goalWeightKg: NaN }));
  useEffect(() => {
    const pre = readSetupHash();
    if (Object.keys(pre).length) {
      setS((cur) => ({ ...cur, ...pre }));
      history.replaceState(null, "", window.location.pathname);
    }
  }, []);
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setS((cur) => ({ ...cur, [k]: v }));
  const valid1 = s.age >= 14 && s.age <= 99 && s.heightCm >= 120 && s.heightCm <= 230 && s.startWeightKg >= 35 && s.startWeightKg <= 300 && s.goalWeightKg >= 35 && s.goalWeightKg <= 300;

  const today = todayStr();
  const preview = useMemo(() => {
    if (!valid1) return null;
    const t = computeTargets(s, s.startWeightKg, today);
    const nT = t.trainingDays;
    return { ...t, train: t.avgBudget + t.trainingOffset, rest: t.avgBudget + t.restOffset, nT };
  }, [s, valid1, today]);

  return (
    <div className="mx-auto min-h-dvh max-w-xl px-4 pb-10 pt-safe">
      <div className="mb-6 mt-6 flex items-center gap-3">
        <img src={`${process.env.NEXT_PUBLIC_BASE_PATH || ""}/icons/icon-192.png`} alt="" className="h-12 w-12 rounded-2xl" />
        <div>
          <div className="text-sm font-medium text-muted">Willkommen bei</div>
          <h1 className="text-3xl font-extrabold tracking-tight">Formkurve</h1>
        </div>
      </div>
      <div className="mb-4 flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <div key={i} className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-accent" : "bg-line"}`} />
        ))}
      </div>

      {step === 0 && (
        <Card className="space-y-4">
          <p className="text-[15px] text-muted">Deine Daten bleiben nur auf diesem Gerät. Alles ist später in den Einstellungen änderbar.</p>
          <Field label="Geschlecht">
            <Segmented value={s.sex} onChange={(v) => set("sex", v)} options={[{ value: "m", label: "Männlich" }, { value: "f", label: "Weiblich" }]} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Alter">
              <NumberInput value={s.age} onChange={(v) => set("age", v ?? NaN)} suffix="Jahre" placeholder="25" name="age" />
            </Field>
            <Field label="Größe">
              <NumberInput value={s.heightCm} onChange={(v) => set("heightCm", v ?? NaN)} suffix="cm" placeholder="175" name="height" />
            </Field>
            <Field label="Aktuelles Gewicht">
              <NumberInput value={s.startWeightKg} onChange={(v) => set("startWeightKg", v ?? NaN)} suffix="kg" placeholder="80" name="weight" />
            </Field>
            <Field label="Zielgewicht">
              <NumberInput value={s.goalWeightKg} onChange={(v) => set("goalWeightKg", v ?? NaN)} suffix="kg" placeholder="72" name="goal" />
            </Field>
          </div>
          <Button size="lg" className="w-full" disabled={!valid1} onClick={() => setStep(1)}>
            Weiter
          </Button>
          <label className="block cursor-pointer text-center text-sm font-semibold text-accent-strong dark:text-accent">
            Backup wiederherstellen
            <input
              type="file"
              accept="application/json,.json"
              className="hidden"
              data-testid="onboarding-import"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                try {
                  const data = parseBackup(await f.text());
                  if (!confirm(`Backup vom ${new Date(data.exportedAt).toLocaleString("de-DE")} wiederherstellen?`)) return;
                  await importData(data);
                  window.location.reload();
                } catch (err) {
                  alert(`Import fehlgeschlagen: ${(err as Error).message}`);
                }
              }}
            />
          </label>
        </Card>
      )}

      {step === 1 && (
        <Card className="space-y-4">
          <Field label="Alltag (ohne Sport)" hint="Der Sport wird aus deinem Trainingsplan dazugerechnet.">
            <Select value={s.neatFactor} onChange={(e) => set("neatFactor", parseFloat(e.target.value))}>
              {NEAT_LEVELS.map((l) => (
                <option key={l.value} value={l.value}>
                  {l.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Trainingsplan">
            <ScheduleEditor schedule={s.schedule} activities={s.activities} onChange={(v) => set("schedule", v)} />
          </Field>
          <Field label={`Kaloriendefizit: ${s.deficit} kcal/Tag`} hint="Empfohlen 500–700 kcal. Mehr erhöht das Risiko für Muskelverlust.">
            <input type="range" min={300} max={800} step={50} value={s.deficit} onChange={(e) => set("deficit", parseInt(e.target.value))} className="w-full accent-emerald-500" />
          </Field>
          <div className="flex gap-2">
            <Button variant="secondary" size="lg" onClick={() => setStep(0)}>
              Zurück
            </Button>
            <Button size="lg" className="flex-1" onClick={() => setStep(2)}>
              Weiter
            </Button>
          </div>
        </Card>
      )}

      {step === 2 && preview && (
        <Card className="space-y-4">
          <h2 className="text-xl font-bold">Dein Plan</h2>
          <div className="grid grid-cols-2 gap-3 text-center">
            <Stat label="Grundumsatz" value={`${fmt(preview.bmr)} kcal`} />
            <Stat label="Gesamtumsatz" value={`${fmt(preview.tdee)} kcal`} />
            <Stat label={`Trainingstag (${preview.nT}×/Woche)`} value={`${fmt(Math.max(s.minKcal, Math.round(preview.train / 10) * 10))} kcal`} accent />
            <Stat label={`Ruhetag (${7 - preview.nT}×/Woche)`} value={`${fmt(Math.max(s.minKcal, Math.round(preview.rest / 10) * 10))} kcal`} accent />
            <Stat label="Eiweiß" value={`${preview.protein} g`} />
            <Stat label="Fett (min.)" value={`${preview.fat} g`} />
          </div>
          <p className="text-sm text-muted">
            Ø {fmt(preview.avgBudget)} kcal/Tag ≈ {fmt((s.deficit * 7) / 7700, 2)} kg Fettverlust pro Woche. Trainingstage bekommen 300 kcal mehr als Ruhetage, die Wochensumme bleibt gleich.
          </p>
          {preview.clampedToFloor && <Notice tone="warn">Dein Budget wurde auf die Untergrenze von {s.minKcal} kcal angehoben.</Notice>}
          <div className="flex gap-2">
            <Button variant="secondary" size="lg" onClick={() => setStep(1)}>
              Zurück
            </Button>
            <Button size="lg" className="flex-1" onClick={() => completeOnboarding({ ...s, startDate: today })} data-testid="onboarding-finish">
              Los geht&apos;s
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl bg-card2 p-3">
      <div className="text-xs font-medium text-muted">{label}</div>
      <div className={`text-lg font-bold tabular ${accent ? "text-accent-strong dark:text-accent" : ""}`}>{value}</div>
    </div>
  );
}
