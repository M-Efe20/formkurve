"use client";
import { useEffect, useState, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div onClick={onClick} className={cx("rounded-3xl bg-card p-4 shadow-[0_1px_2px_rgba(0,0,0,0.04)]", onClick && "cursor-pointer active:scale-[0.99] transition", className)}>
      {children}
    </div>
  );
}

type BtnVariant = "primary" | "secondary" | "ghost" | "danger" | "soft";
export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm" | "md" | "lg" }) {
  const v: Record<BtnVariant, string> = {
    primary: "bg-accent-strong text-white dark:bg-accent dark:text-black",
    secondary: "bg-card2 text-fg",
    ghost: "bg-transparent text-fg",
    danger: "bg-danger/10 text-danger",
    soft: "bg-accent-soft text-accent-strong dark:text-accent",
  };
  const s = { sm: "h-9 px-3 text-sm rounded-xl", md: "h-11 px-4 text-[15px] rounded-2xl", lg: "h-14 px-5 text-base rounded-2xl" }[size];
  return (
    <button
      {...rest}
      className={cx(
        "inline-flex items-center justify-center gap-2 font-semibold transition active:scale-[0.97] disabled:opacity-40 disabled:active:scale-100 select-none",
        v[variant],
        s,
        className,
      )}
    >
      {children}
    </button>
  );
}

export function IconButton({ className, children, label, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      aria-label={label}
      title={label}
      {...rest}
      className={cx("inline-flex h-10 w-10 items-center justify-center rounded-full bg-card2 text-fg transition active:scale-90 disabled:opacity-40", className)}
    >
      {children}
    </button>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  children,
  footer,
  full,
  testId,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  full?: boolean;
  testId?: string;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);
  if (!open || !mounted) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex flex-col justify-end" data-testid={testId} role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/50 animate-fade" onClick={onClose} />
      <div className={cx("relative mx-auto flex w-full max-w-xl flex-col rounded-t-[28px] bg-card animate-sheet", full ? "h-[94dvh]" : "max-h-[92dvh]")}>
        <div className="mx-auto mt-2 h-1.5 w-10 rounded-full bg-line" />
        <div className="flex items-center justify-between gap-3 px-4 pb-2 pt-2">
          <div className="min-w-0 flex-1 text-lg font-bold">{title}</div>
          <IconButton label="Schließen" onClick={onClose} className="h-9 w-9">
            <X size={18} />
          </IconButton>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-4">{children}</div>
        {footer && <div className="border-t border-line px-4 pt-3 pb-safe">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
  size = "md",
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode }[];
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <div className={cx("flex rounded-2xl bg-card2 p-1", className)} role="tablist">
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={cx(
            "flex-1 rounded-xl font-semibold transition whitespace-nowrap",
            size === "sm" ? "px-2 py-1.5 text-[13px]" : "px-3 py-2 text-sm",
            value === o.value ? "bg-card text-fg shadow-sm" : "text-muted",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Field({ label, hint, children, className }: { label: ReactNode; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={cx("block", className)}>
      <span className="mb-1 block text-[13px] font-medium text-muted">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export function TextInput({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...rest}
      className={cx("h-12 w-full rounded-2xl border border-line bg-card2 px-4 outline-none transition focus:border-accent placeholder:text-muted/70", className)}
    />
  );
}

/** Zahlenfeld mit Komma-Unterstützung (deutsche Tastatur) */
export function NumberInput({
  value,
  onChange,
  className,
  suffix,
  ...rest
}: Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange"> & {
  value: number | undefined | null;
  onChange: (v: number | undefined) => void;
  suffix?: string;
}) {
  const [text, setText] = useState(value == null || Number.isNaN(value) ? "" : String(value).replace(".", ","));
  useEffect(() => {
    const parsed = parseFloat(text.replace(",", "."));
    if (value == null || Number.isNaN(value)) {
      if (text !== "" && !Number.isNaN(parsed)) setText("");
    } else if (parsed !== value) {
      setText(String(value).replace(".", ","));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return (
    <div className={cx("relative", className)}>
      <input
        inputMode="decimal"
        enterKeyHint="done"
        {...rest}
        value={text}
        onChange={(e) => {
          const t = e.target.value.replace(/[^0-9.,-]/g, "");
          setText(t);
          const n = parseFloat(t.replace(",", "."));
          onChange(Number.isNaN(n) ? undefined : n);
        }}
        className={cx(
          "h-12 w-full rounded-2xl border border-line bg-card2 px-4 outline-none transition focus:border-accent tabular placeholder:text-muted/70",
          suffix && "pr-14",
        )}
      />
      {suffix && <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-sm text-muted">{suffix}</span>}
    </div>
  );
}

export function Select({ className, children, ...rest }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...rest} className={cx("h-12 w-full appearance-none rounded-2xl border border-line bg-card2 px-4 outline-none focus:border-accent", className)}>
      {children}
    </select>
  );
}

export function Toggle({ checked, onChange, label, testId }: { checked: boolean; onChange: (v: boolean) => void; label?: string; testId?: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      data-testid={testId}
      onClick={() => onChange(!checked)}
      className={cx("relative h-7 w-12 shrink-0 rounded-full transition", checked ? "bg-accent-strong dark:bg-accent" : "bg-line")}
    >
      <span className={cx("absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
    </button>
  );
}

export function Chip({ active, children, onClick, className, testId }: { active?: boolean; children: ReactNode; onClick?: () => void; className?: string; testId?: string }) {
  return (
    <button
      onClick={onClick}
      data-testid={testId}
      aria-pressed={active}
      className={cx(
        "inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-sm font-semibold transition active:scale-95 whitespace-nowrap",
        active ? "bg-accent-strong text-white dark:bg-accent dark:text-black" : "bg-card2 text-fg",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Bar({ value, max, color, className, marker }: { value: number; max: number; color: string; className?: string; marker?: number }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const over = value > max * 1.05;
  return (
    <div className={cx("relative h-2.5 w-full overflow-hidden rounded-full bg-card2", className)}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: over ? "var(--danger)" : color }} />
      {marker != null && max > 0 && <div className="absolute top-0 h-full w-0.5 bg-fg/40" style={{ left: `${Math.min(100, (marker / max) * 100)}%` }} />}
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-2 mt-6 flex items-center justify-between px-1">
      <h2 className="text-[13px] font-bold uppercase tracking-wide text-muted">{children}</h2>
      {action}
    </div>
  );
}

export function PageHeader({ title, subtitle, right }: { title: ReactNode; subtitle?: ReactNode; right?: ReactNode }) {
  return (
    <header className="pt-safe mb-3 flex items-end justify-between gap-3 px-1">
      <div className="min-w-0">
        {subtitle && <div className="text-sm font-medium text-muted">{subtitle}</div>}
        <h1 className="truncate text-[28px] font-extrabold tracking-tight">{title}</h1>
      </div>
      {right}
    </header>
  );
}

export function Notice({ tone = "info", children, className }: { tone?: "info" | "warn" | "danger" | "ok"; children: ReactNode; className?: string }) {
  const t = {
    info: "bg-card2 text-fg",
    warn: "bg-warn/12 text-warn",
    danger: "bg-danger/12 text-danger",
    ok: "bg-accent-soft text-accent-strong dark:text-accent",
  }[tone];
  return <div className={cx("rounded-2xl px-3.5 py-2.5 text-sm font-medium", t, className)}>{children}</div>;
}

export function Spinner({ className }: { className?: string }) {
  return <span className={cx("inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent", className)} />;
}

export function SettingRow({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div>
        <div className="font-semibold">{label}</div>
        {hint && <div className="text-xs text-muted">{hint}</div>}
      </div>
      {children}
    </div>
  );
}
