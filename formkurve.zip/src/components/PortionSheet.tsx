"use client";
import { useEffect, useMemo, useState } from "react";
import { Star, Trash2, Pencil } from "lucide-react";
import { db, MEALS, type Entry, type Food, type MealKey } from "@/lib/db";
import { fmt, gramsFor, nutrientsFor } from "@/lib/calc";
import { defaultPortion, logFood, updateEntryPortion, upsertFood } from "@/lib/store";
import { Button, Chip, IconButton, NumberInput, Segmented, Select, Sheet } from "./ui";
import { HalalBadge, MacroPills } from "./FoodBits";
import { useToast } from "./Toast";

export function PortionSheet({
  food,
  entry,
  date,
  meal,
  onClose,
  onDone,
  onEditFood,
}: {
  food: Food | null;
  entry?: Entry | null;
  date: string;
  meal: MealKey;
  onClose: () => void;
  onDone?: () => void;
  onEditFood?: (f: Food) => void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState<number | undefined>(100);
  const [unit, setUnit] = useState("g");
  const [m, setM] = useState<MealKey>(meal);
  const [fav, setFav] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!food) return;
    if (entry) {
      setAmount(entry.amount);
      setUnit(entry.unit);
      setM(entry.meal);
    } else {
      const p = defaultPortion(food);
      setAmount(p.amount);
      setUnit(p.unit);
      setM(meal);
    }
    setFav(!!food.favorite);
  }, [food, entry, meal]);

  const units = useMemo(() => food?.units || [], [food]);
  const grams = food && amount ? gramsFor(amount, unit, units) : 0;
  const n = food ? nutrientsFor(food, grams) : { kcal: 0, protein: 0, carbs: 0, fat: 0 };
  const quick = unit === "g" || unit === "ml" ? [50, 100, 150, 200, 250] : [0.5, 1, 1.5, 2, 3];

  const toggleFav = async () => {
    if (!food) return;
    const next = !fav;
    setFav(next);
    if (food.id) await db.foods.update(food.id, { favorite: next ? 1 : 0 });
    else food.favorite = next ? 1 : 0;
  };

  const submit = async () => {
    if (!food || !amount || amount <= 0) return;
    setBusy(true);
    try {
      if (entry?.id) {
        await updateEntryPortion(entry, amount, unit, m);
        toast({ text: "Gespeichert" });
      } else {
        const toLog = { ...food, favorite: (fav ? 1 : 0) as 0 | 1 };
        if (!toLog.id && fav) toLog.id = await upsertFood(toLog);
        const id = await logFood(toLog, amount, unit, m, date);
        toast({ text: `${food.name} eingetragen`, action: { label: "Rückgängig", run: () => db.entries.delete(id) } });
      }
      onDone?.();
      onClose();
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!entry?.id) return;
    const copy = { ...entry };
    await db.entries.delete(entry.id);
    toast({ text: "Eintrag gelöscht", action: { label: "Rückgängig", run: () => db.entries.add(copy) } });
    onClose();
  };

  return (
    <Sheet
      open={!!food}
      onClose={onClose}
      testId="portion-sheet"
      title={
        <div className="min-w-0">
          <div className="truncate">{food?.name}</div>
          {food?.brand && <div className="truncate text-sm font-medium text-muted">{food.brand}</div>}
        </div>
      }
      footer={
        <div className="flex gap-2">
          {entry?.id && (
            <Button variant="danger" size="lg" onClick={remove} aria-label="Eintrag löschen">
              <Trash2 size={18} />
            </Button>
          )}
          <Button size="lg" className="flex-1" onClick={submit} disabled={busy || !amount || amount <= 0} data-testid="portion-submit">
            {entry?.id ? "Speichern" : `Eintragen · ${fmt(n.kcal)} kcal`}
          </Button>
        </div>
      }
    >
      {food && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted">
            <span className="tabular">
              pro 100 g: {fmt(food.kcal)} kcal · P {fmt(food.protein, 1)} · KH {fmt(food.carbs, 1)} · F {fmt(food.fat, 1)}
            </span>
            <HalalBadge status={food.halal} note={food.halalNote} />
          </div>
          <div className="flex items-end gap-2">
            <NumberInput value={amount} onChange={setAmount} className="flex-1" aria-label="Menge" data-testid="portion-amount" />
            {(units.length > 0 || unit !== "g") && (
              <Select value={unit} onChange={(e) => setUnit(e.target.value)} className="w-[48%]" aria-label="Einheit">
                <option value="g">g</option>
                {units.map((u) => (
                  <option key={u.label} value={u.label}>
                    {u.label} ({fmt(u.grams)} g)
                  </option>
                ))}
                {unit !== "g" && !units.some((u) => u.label === unit) && <option value={unit}>{unit}</option>}
              </Select>
            )}
            {units.length === 0 && unit === "g" && <span className="pb-3 text-muted">g</span>}
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {quick.map((q) => (
              <Chip key={q} active={amount === q} onClick={() => setAmount(q)}>
                {fmt(q, 1)}
                {unit === "g" ? " g" : ""}
              </Chip>
            ))}
          </div>
          {unit !== "g" && grams > 0 && <div className="-mt-2 text-sm text-muted">= {fmt(grams)} g</div>}
          <MacroPills {...n} />
          <Segmented size="sm" value={m} onChange={setM} options={MEALS.map((x) => ({ value: x.key, label: x.label.replace("essen", "") }))} />
          <div className="flex items-center justify-between">
            <button onClick={toggleFav} className="inline-flex items-center gap-2 text-sm font-semibold" aria-pressed={fav}>
              <Star size={18} className={fav ? "fill-amber-400 text-amber-400" : "text-muted"} />
              {fav ? "Favorit" : "Als Favorit merken"}
            </button>
            {onEditFood && food.id && (food.source === "custom" || food.source === "recipe" || food.source === "off") && (
              <IconButton label="Lebensmittel bearbeiten" onClick={() => onEditFood(food)}>
                <Pencil size={16} />
              </IconButton>
            )}
          </div>
        </div>
      )}
    </Sheet>
  );
}

/** Für Einträge ohne (noch vorhandenes) Lebensmittel: Pseudo-Lebensmittel aus dem Eintrag */
export function foodFromEntry(e: Entry): Food {
  const g = e.grams || 100;
  const f = 100 / g;
  return {
    name: e.name,
    brand: e.brand,
    source: "ai",
    kcal: Math.round(e.kcal * f),
    protein: Math.round(e.protein * f * 10) / 10,
    carbs: Math.round(e.carbs * f * 10) / 10,
    fat: Math.round(e.fat * f * 10) / 10,
    units: e.unit !== "g" && e.amount ? [{ label: e.unit, grams: g / e.amount }] : [],
    favorite: 0,
    useCount: 0,
    updatedAt: Date.now(),
  };
}
