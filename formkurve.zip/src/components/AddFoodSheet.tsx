"use client";
import { useCallback, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Search, ScanBarcode, PenLine, ChefHat, Loader2, X, WifiOff } from "lucide-react";
import { db, MEALS, type Food, type MealKey } from "@/lib/db";
import { lookupBarcode } from "@/lib/off";
import { defaultPortion, logFood } from "@/lib/store";
import { Segmented, Sheet, TextInput, cx } from "./ui";
import { FoodRow } from "./FoodBits";
import { PortionSheet } from "./PortionSheet";
import { FoodEditor } from "./FoodEditor";
import { RecipeEditor } from "./RecipeEditor";
import { BarcodeScanner } from "./BarcodeScanner";
import { filterLocal, useAllFoods, useOnlineSearch } from "./useFoodSearch";
import { useToast } from "./Toast";
import { PhotoEstimateSheet } from "./PhotoEstimateSheet";
import { Camera } from "lucide-react";

type Tab = "recent" | "fav" | "mine";

export function AddFoodSheet({ open, onClose, date, meal: initialMeal }: { open: boolean; onClose: () => void; date: string; meal: MealKey }) {
  const toast = useToast();
  const [meal, setMeal] = useState<MealKey>(initialMeal);
  const [lastInitial, setLastInitial] = useState(initialMeal);
  if (initialMeal !== lastInitial) {
    setLastInitial(initialMeal);
    setMeal(initialMeal);
  }
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<Tab>("recent");
  const [portionFood, setPortionFood] = useState<Food | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editorInitial, setEditorInitial] = useState<Partial<Food> | null>(null);
  const [recipeOpen, setRecipeOpen] = useState(false);
  const [recipeInitial, setRecipeInitial] = useState<Food | null>(null);
  const [scanOpen, setScanOpen] = useState(false);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [lookingUp, setLookingUp] = useState(false);

  const foods = useAllFoods();
  const recent = useLiveQuery(
    () =>
      db.foods
        .orderBy("lastUsed")
        .reverse()
        .filter((f) => !!f.lastUsed)
        .limit(40)
        .toArray(),
    [],
  );
  const favorites = useMemo(() => (foods || []).filter((f) => f.favorite).sort((a, b) => (b.useCount || 0) - (a.useCount || 0)), [foods]);
  const mine = useMemo(
    () => (foods || []).filter((f) => f.source === "custom" || f.source === "recipe").sort((a, b) => a.name.localeCompare(b.name, "de")),
    [foods],
  );
  const local = useMemo(() => filterLocal(foods, query), [foods, query]);
  const online = useOnlineSearch(query, open);
  const onlineFiltered = useMemo(() => {
    const codes = new Set(local.map((f) => f.barcode).filter(Boolean));
    return online.results.filter((f) => !f.barcode || !codes.has(f.barcode));
  }, [online.results, local]);

  const quickAdd = async (f: Food) => {
    const p = defaultPortion(f);
    const id = await logFood(f, p.amount, p.unit, meal, date);
    toast({
      text: `${f.name} · ${p.amount} ${p.unit} eingetragen`,
      action: { label: "Rückgängig", run: () => db.entries.delete(id) },
    });
  };

  const onDetected = useCallback(
    async (code: string) => {
      setScanOpen(false);
      setLookingUp(true);
      try {
        const localHit = await db.foods.where("barcode").equals(code).first();
        if (localHit) {
          setPortionFood(localHit);
          return;
        }
        const hit = await lookupBarcode(code);
        if (hit) setPortionFood(hit);
        else {
          toast({ text: "Produkt nicht gefunden – bitte selbst anlegen", tone: "warn" });
          setEditorInitial({ barcode: code });
          setEditorOpen(true);
        }
      } catch {
        toast({ text: "Open Food Facts nicht erreichbar", tone: "error" });
        setEditorInitial({ barcode: code });
        setEditorOpen(true);
      } finally {
        setLookingUp(false);
      }
    },
    [toast],
  );

  const editFood = (f: Food) => {
    setPortionFood(null);
    if (f.source === "recipe") {
      setRecipeInitial(f);
      setRecipeOpen(true);
    } else {
      setEditorInitial(f);
      setEditorOpen(true);
    }
  };

  const close = () => {
    setQuery("");
    setTab("recent");
    onClose();
  };

  const list = tab === "recent" ? recent : tab === "fav" ? favorites : mine;
  const searching = query.trim().length > 0;

  return (
    <>
      <Sheet open={open} onClose={close} full title="Essen hinzufügen" testId="add-food-sheet">
        <div className="sticky top-0 z-10 -mx-4 space-y-3 bg-card px-4 pb-3">
          <Segmented size="sm" value={meal} onChange={setMeal} options={MEALS.map((m) => ({ value: m.key, label: m.label.replace("essen", "") }))} />
          <div className="relative">
            <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <TextInput
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Lebensmittel oder Marke suchen"
              className="pl-11 pr-11"
              enterKeyHint="search"
              data-testid="food-search"
            />
            {query && (
              <button aria-label="Suche leeren" onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted">
                <X size={18} />
              </button>
            )}
          </div>
          <div className="grid grid-cols-4 gap-2">
            <ActionBtn icon={<ScanBarcode size={20} />} label="Scannen" onClick={() => setScanOpen(true)} testId="btn-scan" />
            <ActionBtn icon={<Camera size={20} />} label="Foto (KI)" onClick={() => setPhotoOpen(true)} testId="btn-photo" />
            <ActionBtn
              icon={<PenLine size={20} />}
              label="Eigenes"
              onClick={() => {
                setEditorInitial(query.trim() ? { name: query.trim() } : null);
                setEditorOpen(true);
              }}
              testId="btn-custom"
            />
            <ActionBtn
              icon={<ChefHat size={20} />}
              label="Gericht"
              onClick={() => {
                setRecipeInitial(null);
                setRecipeOpen(true);
              }}
              testId="btn-recipe"
            />
          </div>
          {lookingUp && (
            <div className="flex items-center gap-2 text-sm text-muted">
              <Loader2 size={16} className="animate-spin" /> Produkt wird gesucht …
            </div>
          )}
          {!searching && (
            <Segmented
              size="sm"
              value={tab}
              onChange={setTab}
              options={[
                { value: "recent", label: "Zuletzt" },
                { value: "fav", label: "Favoriten" },
                { value: "mine", label: "Meine" },
              ]}
            />
          )}
        </div>

        {searching ? (
          <div data-testid="search-results">
            {local.length > 0 && <div className="mt-1 text-xs font-bold uppercase tracking-wide text-muted">Gespeichert</div>}
            {local.map((f) => (
              <FoodRow key={`l${f.id}`} food={f} onOpen={() => setPortionFood(f)} onQuickAdd={() => quickAdd(f)} />
            ))}
            <div className="mt-4 flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-muted">
              Open Food Facts {online.loading && <Loader2 size={14} className="animate-spin" />}
            </div>
            {query.trim().length < 3 && <div className="py-3 text-sm text-muted">Mind. 3 Zeichen für die Online-Suche.</div>}
            {online.error && (
              <div className="flex items-center gap-2 py-3 text-sm text-muted">
                <WifiOff size={16} /> {online.error}
              </div>
            )}
            {!online.loading && !online.error && query.trim().length >= 3 && onlineFiltered.length === 0 && (
              <div className="py-3 text-sm text-muted">Keine Online-Treffer. Tipp: Barcode scannen oder eigenes Lebensmittel anlegen.</div>
            )}
            {onlineFiltered.map((f, i) => (
              <FoodRow key={`o${f.barcode || i}`} food={f} onOpen={() => setPortionFood(f)} testId="online-result" />
            ))}
          </div>
        ) : (
          <div data-testid={`list-${tab}`}>
            {list && list.length === 0 && (
              <div className="py-10 text-center text-sm text-muted">
                {tab === "recent" ? "Noch nichts eingetragen. Suche oben nach einem Lebensmittel." : tab === "fav" ? "Markiere Lebensmittel mit ★ als Favorit." : "Lege eigene Lebensmittel oder Gerichte an."}
              </div>
            )}
            {list?.map((f) => (
              <FoodRow key={f.id} food={f} showLast={tab !== "mine"} onOpen={() => setPortionFood(f)} onQuickAdd={() => quickAdd(f)} />
            ))}
          </div>
        )}
      </Sheet>

      <PortionSheet food={portionFood} date={date} meal={meal} onClose={() => setPortionFood(null)} onEditFood={editFood} />
      <FoodEditor open={editorOpen} initial={editorInitial} onClose={() => setEditorOpen(false)} onSaved={(f) => setPortionFood(f)} />
      <RecipeEditor open={recipeOpen} initial={recipeInitial} onClose={() => setRecipeOpen(false)} onSaved={(f) => setPortionFood(f)} />
      <BarcodeScanner open={scanOpen} onClose={() => setScanOpen(false)} onDetected={onDetected} />
      <PhotoEstimateSheet open={photoOpen} onClose={() => setPhotoOpen(false)} date={date} meal={meal} />
    </>
  );
}

function ActionBtn({ icon, label, onClick, testId }: { icon: React.ReactNode; label: string; onClick: () => void; testId?: string }) {
  return (
    <button onClick={onClick} data-testid={testId} className={cx("flex flex-col items-center gap-1 rounded-2xl bg-card2 py-2.5 text-[12px] font-semibold transition active:scale-95")}>
      {icon}
      {label}
    </button>
  );
}
