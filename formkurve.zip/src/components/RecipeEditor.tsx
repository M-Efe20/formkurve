"use client";
import { useEffect, useMemo, useState } from "react";
import { Search, Trash2, Loader2 } from "lucide-react";
import { db, type Food } from "@/lib/db";
import { fmt, nutrientsFor, sumNutrients } from "@/lib/calc";
import { upsertFood } from "@/lib/store";
import { Button, Field, IconButton, NumberInput, Sheet, TextInput } from "./ui";
import { FoodRow, MacroPills } from "./FoodBits";
import { filterLocal, useAllFoods, useOnlineSearch } from "./useFoodSearch";
import { useToast } from "./Toast";

type Ing = NonNullable<Food["ingredients"]>[number] & { per100: { kcal: number; protein: number; carbs: number; fat: number } };

export function RecipeEditor({ open, initial, onClose, onSaved }: { open: boolean; initial?: Food | null; onClose: () => void; onSaved?: (f: Food) => void }) {
  const toast = useToast();
  const foods = useAllFoods();
  const [name, setName] = useState("");
  const [portions, setPortions] = useState<number | undefined>(2);
  const [ings, setIngs] = useState<Ing[]>([]);
  const [query, setQuery] = useState("");
  const online = useOnlineSearch(query, open);

  useEffect(() => {
    if (!open) return;
    setName(initial?.name || "");
    const portionUnit = initial?.units?.find((u) => u.label === "Portion");
    const total = (initial?.ingredients || []).reduce((s, i) => s + i.grams, 0);
    setPortions(portionUnit && total ? Math.round(total / portionUnit.grams) : 2);
    setIngs(
      (initial?.ingredients || []).map((i) => ({
        ...i,
        per100: i.grams ? { kcal: (i.kcal / i.grams) * 100, protein: (i.protein / i.grams) * 100, carbs: (i.carbs / i.grams) * 100, fat: (i.fat / i.grams) * 100 } : { kcal: 0, protein: 0, carbs: 0, fat: 0 },
      })),
    );
    setQuery("");
  }, [open, initial]);

  const local = useMemo(() => filterLocal(foods?.filter((f) => f.source !== "recipe"), query, 8), [foods, query]);

  const add = async (food: Food) => {
    const id = food.id ?? (await upsertFood(food));
    const grams = food.units?.[0]?.grams && food.units[0].grams < 400 ? food.units[0].grams : 100;
    const n = nutrientsFor(food, grams);
    setIngs((cur) => [...cur, { foodId: id, name: food.name, grams, ...n, per100: { kcal: food.kcal, protein: food.protein, carbs: food.carbs, fat: food.fat } }]);
    setQuery("");
  };

  const setGrams = (i: number, g: number) =>
    setIngs((cur) => cur.map((x, j) => (j === i ? { ...x, grams: g, ...nutrientsFor(x.per100, g) } : x)));

  const total = sumNutrients(ings);
  const totalG = ings.reduce((s, i) => s + i.grams, 0);
  const p = portions && portions > 0 ? portions : 1;
  const valid = name.trim() && ings.length > 0 && totalG > 0;

  const save = async () => {
    const food: Food = {
      ...(initial || {}),
      name: name.trim(),
      source: "recipe",
      kcal: Math.round((total.kcal / totalG) * 100),
      protein: Math.round((total.protein / totalG) * 1000) / 10,
      carbs: Math.round((total.carbs / totalG) * 1000) / 10,
      fat: Math.round((total.fat / totalG) * 1000) / 10,
      units: [{ label: "Portion", grams: Math.round(totalG / p) }],
      ingredients: ings.map(({ per100: _p, ...rest }) => rest),
      favorite: initial?.favorite ?? 1,
      useCount: initial?.useCount ?? 0,
      lastAmount: initial?.lastAmount ?? 1,
      lastUnit: "Portion",
      updatedAt: Date.now(),
    } as Food;
    const id = await upsertFood(food);
    toast({ text: "Gericht gespeichert" });
    onSaved?.((await db.foods.get(id))!);
    onClose();
  };

  return (
    <Sheet
      open={open}
      onClose={onClose}
      full
      title={initial?.id ? "Gericht bearbeiten" : "Neues Gericht"}
      testId="recipe-editor"
      footer={
        <Button size="lg" className="w-full" disabled={!valid} onClick={save} data-testid="recipe-save">
          Gericht speichern · {fmt(total.kcal / p)} kcal/Portion
        </Button>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-[1fr_120px] gap-3">
          <Field label="Name">
            <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="z. B. Hähnchen-Reis-Bowl" data-testid="recipe-name" />
          </Field>
          <Field label="Portionen">
            <NumberInput value={portions} onChange={setPortions} />
          </Field>
        </div>
        <MacroPills kcal={total.kcal / p} protein={total.protein / p} carbs={total.carbs / p} fat={total.fat / p} />
        <div className="text-center text-xs text-muted">pro Portion ({fmt(totalG / p)} g) · gesamt {fmt(totalG)} g</div>

        <div>
          <div className="mb-1 text-[13px] font-medium text-muted">Zutaten</div>
          {ings.length === 0 && <div className="rounded-2xl bg-card2 p-4 text-sm text-muted">Noch keine Zutaten – unten suchen und hinzufügen.</div>}
          {ings.map((i, idx) => (
            <div key={idx} className="flex items-center gap-2 border-b border-line/70 py-2">
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{i.name}</div>
                <div className="text-xs text-muted tabular">
                  {fmt(i.kcal)} kcal · {fmt(i.protein)} g P
                </div>
              </div>
              <NumberInput value={i.grams} onChange={(v) => setGrams(idx, v || 0)} suffix="g" className="w-28" aria-label={`Menge ${i.name}`} />
              <IconButton label="Zutat entfernen" onClick={() => setIngs((cur) => cur.filter((_, j) => j !== idx))}>
                <Trash2 size={16} />
              </IconButton>
            </div>
          ))}
        </div>

        <div className="relative">
          <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <TextInput value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Zutat suchen …" className="pl-11" data-testid="recipe-search" />
        </div>
        {query.trim() && (
          <div>
            {local.map((f) => (
              <FoodRow key={`l${f.id}`} food={f} onOpen={() => add(f)} />
            ))}
            {online.loading && (
              <div className="flex items-center gap-2 py-3 text-sm text-muted">
                <Loader2 size={16} className="animate-spin" /> Suche bei Open Food Facts …
              </div>
            )}
            {online.results.map((f, i) => (
              <FoodRow key={`o${f.barcode || i}`} food={f} onOpen={() => add(f)} />
            ))}
          </div>
        )}
      </div>
    </Sheet>
  );
}
