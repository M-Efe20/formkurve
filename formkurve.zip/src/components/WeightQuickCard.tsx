"use client";
import { useState } from "react";
import Link from "next/link";
import { Scale, ChevronRight } from "lucide-react";
import { useWeights } from "@/lib/hooks";
import { avg7, fmt } from "@/lib/calc";
import { setWeight } from "@/lib/store";
import { Button, Card, NumberInput } from "./ui";
import { useToast } from "./Toast";

export function WeightQuickCard({ date, now }: { date: string; now: Date }) {
  const weights = useWeights();
  const toast = useToast();
  const [v, setV] = useState<number | undefined>();
  if (!weights) return null;
  const todays = weights.find((w) => w.date === date);
  const avg = avg7(weights, date);

  if (todays) {
    return (
      <Link href="/progress/" className="mt-3 flex items-center justify-between rounded-3xl bg-card px-4 py-3" data-testid="weight-summary">
        <span className="flex items-center gap-2 text-sm font-semibold">
          <Scale size={18} className="text-muted" /> Heute {fmt(todays.kg, 1, 1)} kg
        </span>
        <span className="flex items-center gap-1 text-sm text-muted">
          Ø 7 Tage <b className="text-fg tabular">{avg != null ? fmt(avg, 1, 1) : "–"} kg</b>
          <ChevronRight size={16} />
        </span>
      </Link>
    );
  }
  if (now.getHours() >= 14) return null;
  const save = async () => {
    if (!v || v < 30 || v > 300) return;
    await setWeight(date, Math.round(v * 10) / 10);
    toast({ text: "Gewicht gespeichert" });
  };
  return (
    <Card className="mt-3">
      <div className="mb-2 flex items-center gap-2 font-bold">
        <Scale size={18} className="text-muted" /> Morgengewicht
      </div>
      <p className="mb-3 text-sm text-muted">Nach dem Aufstehen, nach der Toilette, vor dem Frühstück.</p>
      <div className="flex gap-2">
        <NumberInput value={v} onChange={setV} suffix="kg" placeholder={avg ? fmt(avg, 1) : "kg"} className="flex-1" data-testid="weight-quick-input" />
        <Button size="lg" onClick={save} disabled={!v} data-testid="weight-quick-save">
          Speichern
        </Button>
      </div>
    </Card>
  );
}
