"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, Plus, Minus, TrendingUp, History, Trash2 } from "lucide-react";
import { db, type Workout, type ExerciseDef } from "@/lib/db";
import { formatSets, lastPerformance, suggestNext } from "@/lib/training";
import { formatDate } from "@/lib/dates";
import { updateDay } from "@/lib/store";
import { Button, IconButton, NumberInput, Select, Sheet, cx } from "./ui";
import { useToast } from "./Toast";

export async function startWorkout(date: string): Promise<number> {
  const existing = await db.workouts.where("date").equals(date).first();
  if (existing?.id) return existing.id;
  const [defs, all] = await Promise.all([db.exercises.orderBy("order").filter((e) => e.active === 1).toArray(), db.workouts.toArray()]);
  const exercises = defs.map((d) => ({ name: d.name, sets: suggestNext(d, lastPerformance(all, d.name, date)).sets }));
  return db.workouts.add({ date, name: "Ganzkörper", exercises, createdAt: Date.now() });
}

export function WorkoutSheet({ id, onClose }: { id: number | null; onClose: () => void }) {
  const toast = useToast();
  const stored = useLiveQuery(() => (id ? db.workouts.get(id) : undefined), [id]);
  const defs = useLiveQuery(() => db.exercises.orderBy("order").toArray(), []);
  const all = useLiveQuery(() => db.workouts.toArray(), []);
  const [draft, setDraft] = useState<Workout | null>(null);
  const [addName, setAddName] = useState("");
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (stored && (!draft || draft.id !== stored.id)) setDraft(stored);
    if (!id) setDraft(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stored, id]);

  const persist = (w: Workout) => {
    setDraft(w);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => db.workouts.put(w), 300);
  };

  const defByName = useMemo(() => new Map((defs || []).map((d) => [d.name, d])), [defs]);

  if (!id) return null;

  const update = (ei: number, si: number, patch: Partial<{ kg: number; reps: number; done: boolean }>) => {
    if (!draft) return;
    const exercises = draft.exercises.map((e, i) => (i !== ei ? e : { ...e, sets: e.sets.map((s, j) => (j !== si ? s : { ...s, ...patch })) }));
    persist({ ...draft, exercises });
  };
  const addSet = (ei: number) => {
    if (!draft) return;
    const ex = draft.exercises[ei];
    const last = ex.sets[ex.sets.length - 1] || { kg: 0, reps: 8 };
    persist({ ...draft, exercises: draft.exercises.map((e, i) => (i !== ei ? e : { ...e, sets: [...e.sets, { kg: last.kg, reps: last.reps, done: false }] })) });
  };
  const removeSet = (ei: number) => {
    if (!draft) return;
    persist({ ...draft, exercises: draft.exercises.map((e, i) => (i !== ei ? e : { ...e, sets: e.sets.slice(0, -1) })) });
  };
  const removeExercise = (ei: number) => draft && persist({ ...draft, exercises: draft.exercises.filter((_, i) => i !== ei) });
  const addExercise = () => {
    if (!draft || !addName) return;
    const d = defByName.get(addName);
    const sets = d ? suggestNext(d, lastPerformance(all || [], d.name, draft.date, draft.id)).sets : [{ kg: 0, reps: 10, done: false }];
    persist({ ...draft, exercises: [...draft.exercises, { name: addName, sets }] });
    setAddName("");
  };

  const finish = async () => {
    if (!draft) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    const exercises = draft.exercises.map((e) => ({ ...e, sets: e.sets.filter((s) => s.done) })).filter((e) => e.sets.length > 0);
    if (!exercises.length) {
      if (!confirm("Kein Satz abgehakt. Training verwerfen?")) return;
      await db.workouts.delete(draft.id!);
      onClose();
      return;
    }
    await db.workouts.put({ ...draft, exercises });
    await updateDay(draft.date, (d) => ({ activities: d.activities.includes("gym") ? d.activities : [...d.activities, "gym"] }));
    const sets = exercises.reduce((s, e) => s + e.sets.length, 0);
    toast({ text: `Training gespeichert: ${exercises.length} Übungen, ${sets} Sätze` });
    onClose();
  };

  const remove = async () => {
    if (!draft?.id || !confirm("Dieses Training löschen?")) return;
    await db.workouts.delete(draft.id);
    onClose();
  };

  const doneCount = draft?.exercises.reduce((s, e) => s + e.sets.filter((x) => x.done).length, 0) || 0;
  const usedNames = new Set(draft?.exercises.map((e) => e.name));

  return (
    <Sheet
      open={!!id}
      onClose={() => {
        if (saveTimer.current) clearTimeout(saveTimer.current);
        if (draft) {
          // Nichts abgehakt → angefangenes Training verwerfen (lässt sich jederzeit neu starten)
          const anyDone = draft.exercises.some((e) => e.sets.some((x) => x.done));
          if (anyDone) db.workouts.put(draft);
          else db.workouts.delete(draft.id!);
        }
        onClose();
      }}
      full
      testId="workout-sheet"
      title={
        <div>
          <div>Ganzkörper</div>
          {draft && <div className="text-sm font-medium text-muted">{formatDate(draft.date, { weekday: "long", day: "numeric", month: "long" })}</div>}
        </div>
      }
      footer={
        <div className="flex gap-2">
          <Button variant="danger" size="lg" onClick={remove} aria-label="Training löschen">
            <Trash2 size={18} />
          </Button>
          <Button size="lg" className="flex-1" onClick={finish} data-testid="workout-finish">
            Training beenden · {doneCount} Sätze
          </Button>
        </div>
      }
    >
      {draft && (
        <div className="space-y-4">
          <p className="text-sm text-muted">Werte sind als Ziel vorausgefüllt. Tatsächliches Gewicht/Wdh. eintragen und Satz mit ✓ abhaken.</p>
          {draft.exercises.map((ex, ei) => {
            const def = defByName.get(ex.name);
            const last = lastPerformance(all || [], ex.name, draft.date, draft.id);
            const sug = def ? suggestNext(def, last) : null;
            return (
              <div key={ex.name + ei} className="rounded-3xl bg-card2 p-3" data-testid="exercise-block">
                <div className="mb-1 flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-bold">{ex.name}</div>
                    <div className="flex items-center gap-1 text-[13px] text-muted" data-testid="last-time">
                      <History size={13} /> {last ? `Letztes Mal (${formatDate(last.date, { day: "numeric", month: "short" })}): ${formatSets(last.sets)}` : "Noch keine Daten"}
                    </div>
                    {sug && (
                      <div className={cx("mt-0.5 flex items-start gap-1 text-[13px] font-semibold", sug.kind === "increase" ? "text-accent-strong dark:text-accent" : "text-fg")} data-testid="suggestion-text">
                        <TrendingUp size={13} className="mt-0.5 shrink-0" /> {sug.text}
                      </div>
                    )}
                  </div>
                  <button aria-label={`${ex.name} entfernen`} className="p-1 text-muted" onClick={() => removeExercise(ei)}>
                    <Trash2 size={15} />
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-[28px_1fr_1fr_44px] items-center gap-2 text-center text-[11px] font-semibold text-muted">
                  <span>Satz</span>
                  <span>kg</span>
                  <span>Wdh.</span>
                  <span />
                </div>
                {ex.sets.map((s, si) => (
                  <div key={si} className="mt-1.5 grid grid-cols-[28px_1fr_1fr_44px] items-center gap-2">
                    <span className="text-center text-sm font-bold text-muted">{si + 1}</span>
                    <NumberInput value={s.kg} onChange={(v) => update(ei, si, { kg: v ?? 0 })} aria-label={`${ex.name} Satz ${si + 1} kg`} className="[&_input]:h-11 [&_input]:bg-card [&_input]:text-center" />
                    <NumberInput value={s.reps} onChange={(v) => update(ei, si, { reps: Math.round(v ?? 0) })} aria-label={`${ex.name} Satz ${si + 1} Wdh`} className="[&_input]:h-11 [&_input]:bg-card [&_input]:text-center" />
                    <button
                      aria-label={`${ex.name} Satz ${si + 1} erledigt`}
                      aria-pressed={!!s.done}
                      onClick={() => update(ei, si, { done: !s.done })}
                      className={cx("flex h-11 w-11 items-center justify-center rounded-xl transition active:scale-90", s.done ? "bg-accent-strong text-white dark:bg-accent dark:text-black" : "bg-card text-muted")}
                    >
                      <Check size={20} strokeWidth={3} />
                    </button>
                  </div>
                ))}
                <div className="mt-2 flex gap-2">
                  <Button size="sm" variant="ghost" onClick={() => addSet(ei)}>
                    <Plus size={14} /> Satz
                  </Button>
                  {ex.sets.length > 1 && (
                    <Button size="sm" variant="ghost" onClick={() => removeSet(ei)}>
                      <Minus size={14} /> Satz
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
          <div className="flex gap-2">
            <Select value={addName} onChange={(e) => setAddName(e.target.value)} className="flex-1" aria-label="Übung hinzufügen">
              <option value="">Übung hinzufügen …</option>
              {(defs || [])
                .filter((d) => !usedNames.has(d.name))
                .map((d: ExerciseDef) => (
                  <option key={d.id} value={d.name}>
                    {d.name}
                  </option>
                ))}
            </Select>
            <IconButton label="Hinzufügen" onClick={addExercise} disabled={!addName} className="h-12 w-12">
              <Plus size={18} />
            </IconButton>
          </div>
        </div>
      )}
    </Sheet>
  );
}
