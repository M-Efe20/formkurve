"use client";
import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db, type Food } from "@/lib/db";
import { searchOff, type OffFood } from "@/lib/off";

export function normalize(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/ß/g, "ss");
}

export function useAllFoods() {
  return useLiveQuery(() => db.foods.toArray(), []);
}

export function filterLocal(foods: Food[] | undefined, query: string, limit = 20): Food[] {
  if (!foods) return [];
  const q = normalize(query.trim());
  if (!q) return [];
  const tokens = q.split(/\s+/).filter(Boolean);
  return foods
    .filter((f) => {
      const hay = normalize(`${f.name} ${f.brand || ""}`);
      return tokens.every((t) => hay.includes(t));
    })
    .map((f) => {
      const name = normalize(f.name);
      let score = f.useCount * 2 + (f.favorite ? 20 : 0);
      if (name.startsWith(q)) score += 15;
      if (f.source === "basic") score += 3;
      return { f, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.f);
}

export function useOnlineSearch(query: string, enabled = true) {
  const [results, setResults] = useState<OffFood[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const q = query.trim();
  useEffect(() => {
    if (!enabled || q.length < 3) {
      setResults([]);
      setLoading(false);
      setError(null);
      return;
    }
    const ctrl = new AbortController();
    setLoading(true);
    setError(null);
    const t = setTimeout(async () => {
      try {
        const r = await searchOff(q, ctrl.signal);
        if (!ctrl.signal.aborted) setResults(r);
      } catch (e) {
        if (!ctrl.signal.aborted) {
          setResults([]);
          setError(navigator.onLine === false ? "Offline – nur lokale Treffer" : String((e as Error).message || e));
        }
      } finally {
        if (!ctrl.signal.aborted) setLoading(false);
      }
    }, 450);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [q, enabled]);
  return useMemo(() => ({ results, loading, error }), [results, loading, error]);
}
