"use client";
import type { ActivityDef } from "@/lib/db";
import { WEEK_ORDER, WEEKDAYS_SHORT } from "@/lib/dates";
import { cx } from "./ui";

export function ScheduleEditor({
  schedule,
  activities,
  onChange,
}: {
  schedule: Record<number, string[]>;
  activities: ActivityDef[];
  onChange: (s: Record<number, string[]>) => void;
}) {
  const toggle = (wd: number, key: string) => {
    const cur = schedule[wd] || [];
    onChange({ ...schedule, [wd]: cur.includes(key) ? cur.filter((k) => k !== key) : [...cur, key] });
  };
  return (
    <div className="grid grid-cols-[auto_repeat(7,minmax(0,1fr))] items-center gap-1.5" data-testid="schedule-editor">
      <span />
      {WEEK_ORDER.map((wd) => (
        <span key={wd} className="text-center text-xs font-semibold text-muted">
          {WEEKDAYS_SHORT[wd]}
        </span>
      ))}
      {activities.map((a) => (
        <div key={a.key} className="contents">
          <span className="pr-1 text-[13px] font-semibold whitespace-nowrap">{a.label.replace(/ \(.*\)/, "")}</span>
          {WEEK_ORDER.map((wd) => {
            const on = (schedule[wd] || []).includes(a.key);
            return (
              <button
                key={wd}
                aria-label={`${a.label} am ${WEEKDAYS_SHORT[wd]}`}
                aria-pressed={on}
                onClick={() => toggle(wd, a.key)}
                className={cx(
                  "aspect-square w-full max-w-10 justify-self-center rounded-xl text-xs font-bold transition active:scale-90",
                  on ? "bg-accent-strong text-white dark:bg-accent dark:text-black" : "bg-card2 text-muted",
                )}
              >
                {on ? "✓" : ""}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
