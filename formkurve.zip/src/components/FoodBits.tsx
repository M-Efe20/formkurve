"use client";
import { Plus, Star, ShieldCheck, AlertTriangle, HelpCircle, ChefHat, Sparkles } from "lucide-react";
import type { Food, HalalStatus } from "@/lib/db";
import { fmt, gramsFor, nutrientsFor } from "@/lib/calc";
import { cx } from "./ui";

export function HalalBadge({ status, note, compact }: { status?: HalalStatus; note?: string; compact?: boolean }) {
  if (!status || status === "unknown") return null;
  if (status === "certified")
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-accent-soft px-2 py-0.5 text-[11px] font-bold text-accent-strong dark:text-accent">
        <ShieldCheck size={12} /> Halal
      </span>
    );
  if (status === "warning")
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-danger/12 px-2 py-0.5 text-[11px] font-bold text-danger" title={note}>
        <AlertTriangle size={12} /> {compact ? "Nicht halal?" : `Achtung: ${note || "nicht halal"}`}
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-warn/12 px-2 py-0.5 text-[11px] font-bold text-warn" title={note}>
      <HelpCircle size={12} /> {compact ? "Prüfen" : `Prüfen: ${note}`}
    </span>
  );
}

export function FoodRow({
  food,
  onOpen,
  onQuickAdd,
  showLast,
  testId,
}: {
  food: Food;
  onOpen: () => void;
  onQuickAdd?: () => void;
  showLast?: boolean;
  testId?: string;
}) {
  let sub = `${fmt(food.kcal)} kcal / 100 g`;
  if (showLast && food.lastAmount && food.lastUnit) {
    const g = gramsFor(food.lastAmount, food.lastUnit, food.units || []);
    const n = nutrientsFor(food, g);
    sub = `${fmt(food.lastAmount, 1)} ${food.lastUnit === "g" ? "g" : food.lastUnit} · ${fmt(n.kcal)} kcal · ${fmt(n.protein)} g P`;
  }
  return (
    <div className="flex items-center gap-2 border-b border-line/70 py-2.5 last:border-0" data-testid={testId}>
      <button onClick={onOpen} className="flex min-w-0 flex-1 items-center gap-3 text-left active:opacity-60">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-card2 text-muted">
          {food.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={food.imageUrl} alt="" className="h-full w-full object-cover" loading="lazy" />
          ) : food.source === "recipe" ? (
            <ChefHat size={18} />
          ) : food.source === "ai" ? (
            <Sparkles size={18} />
          ) : (
            <span className="text-sm font-bold">{food.name.slice(0, 1)}</span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-[15px] font-semibold">{food.name}</span>
            {food.favorite ? <Star size={13} className="shrink-0 fill-amber-400 text-amber-400" /> : null}
          </div>
          <div className="flex items-center gap-1.5 truncate text-[13px] text-muted">
            {food.brand && <span className="truncate">{food.brand} ·</span>}
            <span className="truncate tabular">{sub}</span>
          </div>
          {food.halal && food.halal !== "unknown" && (
            <div className="mt-0.5">
              <HalalBadge status={food.halal} note={food.halalNote} compact />
            </div>
          )}
        </div>
      </button>
      {onQuickAdd && (
        <button
          aria-label={`${food.name} schnell eintragen`}
          onClick={onQuickAdd}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent-soft text-accent-strong transition active:scale-90 dark:text-accent"
        >
          <Plus size={20} strokeWidth={2.6} />
        </button>
      )}
    </div>
  );
}

export function MacroPills({ kcal, protein, carbs, fat, className }: { kcal: number; protein: number; carbs: number; fat: number; className?: string }) {
  return (
    <div className={cx("grid grid-cols-4 gap-2 text-center", className)}>
      <div className="rounded-2xl bg-card2 py-2">
        <div className="text-lg font-extrabold tabular">{fmt(kcal)}</div>
        <div className="text-[11px] font-semibold text-muted">kcal</div>
      </div>
      <div className="rounded-2xl bg-card2 py-2">
        <div className="text-lg font-extrabold tabular text-protein">{fmt(protein, protein < 10 ? 1 : 0)}</div>
        <div className="text-[11px] font-semibold text-muted">Eiweiß</div>
      </div>
      <div className="rounded-2xl bg-card2 py-2">
        <div className="text-lg font-extrabold tabular text-carbs">{fmt(carbs, carbs < 10 ? 1 : 0)}</div>
        <div className="text-[11px] font-semibold text-muted">KH</div>
      </div>
      <div className="rounded-2xl bg-card2 py-2">
        <div className="text-lg font-extrabold tabular text-fat">{fmt(fat, fat < 10 ? 1 : 0)}</div>
        <div className="text-[11px] font-semibold text-muted">Fett</div>
      </div>
    </div>
  );
}
