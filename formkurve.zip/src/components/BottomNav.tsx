"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, LineChart, Dumbbell, Sparkles, Settings } from "lucide-react";
import { cx } from "./ui";

const TABS = [
  { href: "/", label: "Heute", icon: Home },
  { href: "/progress/", label: "Fortschritt", icon: LineChart },
  { href: "/training/", label: "Training", icon: Dumbbell },
  { href: "/coach/", label: "Coach", icon: Sparkles },
  { href: "/settings/", label: "Mehr", icon: Settings },
];

export function BottomNav() {
  const path = usePathname() || "/";
  const norm = path.endsWith("/") ? path : path + "/";
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/90 backdrop-blur-xl pb-safe">
      <ul className="mx-auto flex max-w-xl">
        {TABS.map((t) => {
          const active = t.href === "/" ? norm === "/" : norm.startsWith(t.href);
          const Icon = t.icon;
          return (
            <li key={t.href} className="flex-1">
              <Link
                href={t.href}
                className={cx("flex flex-col items-center gap-0.5 pt-2 pb-1 text-[11px] font-semibold transition", active ? "text-accent-strong dark:text-accent" : "text-muted")}
                aria-current={active ? "page" : undefined}
              >
                <Icon size={23} strokeWidth={active ? 2.4 : 2} />
                {t.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
