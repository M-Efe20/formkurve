"use client";
import { useCallback, useState } from "react";
import { ThumbsUp, Wrench, Lightbulb } from "lucide-react";
import type { CoachSuggestion, Settings, WeeklyReview } from "@/lib/db";
import { fmt } from "@/lib/calc";
import { aiDailyFeedback, aiEveningSuggestion, aiWeeklyReview, basicSuggestion, computeWeekStats, loadDayContext, saveWeeklyReview } from "@/lib/coach";
import { updateDay } from "@/lib/store";

/** Verhindert doppelte automatische KI-Aufrufe (auch über Re-Renders hinweg) */
const autoTried = new Set<string>();
export function markAutoTried(key: string): boolean {
  if (autoTried.has(key)) return false;
  autoTried.add(key);
  return true;
}

export function useCoachRunner(settings: Settings, date: string) {
  const [busy, setBusy] = useState<null | "suggestion" | "feedback" | "weekly">(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(
    async (kind: "suggestion" | "feedback" | "weekly") => {
      setBusy(kind);
      setError(null);
      try {
        if (kind === "weekly") {
          const st = await computeWeekStats(settings, date);
          const review = await aiWeeklyReview(settings, st);
          await saveWeeklyReview(date, review);
          return;
        }
        const ctx = await loadDayContext(settings, date);
        if (kind === "suggestion") {
          const s = settings.apiKey ? await aiEveningSuggestion(ctx) : basicSuggestion(ctx);
          await updateDay(date, { suggestion: s, suggestionAt: Date.now() });
        } else {
          const text = await aiDailyFeedback(ctx);
          await updateDay(date, { feedback: text, feedbackAt: Date.now() });
        }
      } catch (e) {
        setError((e as Error).message || String(e));
      } finally {
        setBusy(null);
      }
    },
    [settings, date],
  );
  return { run, busy, error };
}

export function SuggestionView({ s, compact }: { s: CoachSuggestion; compact?: boolean }) {
  return (
    <div className="space-y-3" data-testid="suggestion">
      {s.intro && <p className="text-[15px]">{s.intro}</p>}
      {s.options.map((o, i) => (
        <div key={i} className="rounded-2xl bg-card2 p-3">
          <div className="flex items-start justify-between gap-2">
            <div className="font-bold leading-snug">{o.title}</div>
            <div className="shrink-0 text-right text-[13px] font-semibold tabular">
              <div>{fmt(o.kcal)} kcal</div>
              <div className="text-protein">{fmt(o.protein)} g P</div>
            </div>
          </div>
          <ul className="mt-1.5 space-y-0.5 text-sm">
            {o.items.map((it, j) => (
              <li key={j} className="flex gap-2">
                <span className="w-20 shrink-0 font-semibold tabular text-muted">{it.amount}</span>
                <span>{it.name}</span>
              </li>
            ))}
          </ul>
          {!compact && (o.prep || o.cost) && (
            <div className="mt-1.5 text-xs text-muted">
              {o.prep}
              {o.prep && o.cost ? " · " : ""}
              {o.cost}
            </div>
          )}
        </div>
      ))}
      {s.tip && <p className="text-sm text-muted">{s.tip}</p>}
    </div>
  );
}

export function ReviewView({ r }: { r: WeeklyReview }) {
  return (
    <div className="space-y-3 text-[15px]" data-testid="weekly-review">
      <p className="font-medium">{r.summary}</p>
      <ListBlock icon={<ThumbsUp size={16} />} title="Lief gut" items={r.good} color="text-accent-strong dark:text-accent" />
      <ListBlock icon={<Wrench size={16} />} title="Verbessern" items={r.improve} color="text-warn" />
      <ListBlock icon={<Lightbulb size={16} />} title="Tipps für nächste Woche" items={r.tips} color="text-protein" />
    </div>
  );
}

function ListBlock({ icon, title, items, color }: { icon: React.ReactNode; title: string; items: string[]; color: string }) {
  if (!items?.length) return null;
  return (
    <div>
      <div className={`mb-1 flex items-center gap-1.5 text-sm font-bold ${color}`}>
        {icon} {title}
      </div>
      <ul className="space-y-1 pl-1">
        {items.map((t, i) => (
          <li key={i} className="flex gap-2 text-sm">
            <span className="text-muted">•</span>
            <span>{t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
