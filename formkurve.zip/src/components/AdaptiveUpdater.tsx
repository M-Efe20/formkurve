"use client";
import { useEffect, useRef } from "react";
import type { Settings } from "@/lib/db";
import { db } from "@/lib/db";
import { computeAdaptive, computeTargets, dailyKcalMap, fmt, trendWeight } from "@/lib/calc";
import { addDays, daysBetween, todayStr } from "@/lib/dates";
import { saveSettings } from "@/lib/store";
import { useToast } from "./Toast";

/** Berechnet im adaptiven Modus höchstens einmal pro Woche den echten Verbrauch neu */
export function AdaptiveUpdater({ settings }: { settings: Settings }) {
  const toast = useToast();
  const running = useRef(false);
  useEffect(() => {
    if (!settings.adaptive || !settings.startDate || running.current) return;
    const today = todayStr();
    if (settings.adaptiveUpdated && daysBetween(settings.adaptiveUpdated, today) < 7) return;
    running.current = true;
    (async () => {
      const entries = await db.entries.where("date").between(addDays(today, -30), today, true, true).toArray();
      const weights = await db.weights.toArray();
      const tw = trendWeight(weights, today, settings.startWeightKg);
      const formula = computeTargets({ ...settings, adaptive: false }, tw, today).tdeeFormula;
      const r = computeAdaptive(dailyKcalMap(entries), weights, today, settings.startDate, formula);
      if (!r.ready || !r.tdee) return;
      const prev = settings.adaptiveTdee;
      const next = prev ? Math.round((prev + r.tdee) / 2) : r.tdee;
      await saveSettings({ adaptiveTdee: next, adaptiveUpdated: today });
      toast({ text: `Budget angepasst: echter Verbrauch ≈ ${fmt(next)} kcal` }, 5000);
    })().finally(() => {
      running.current = false;
    });
  }, [settings, toast]);
  return null;
}
