"use client";
import { useRef, useState } from "react";
import { Download, Upload, Trash2 } from "lucide-react";
import { useSettings } from "@/lib/hooks";
import { downloadBackup, importData, parseBackup, wipeAll } from "@/lib/backup";
import { daysBetween, formatDate, todayStr } from "@/lib/dates";
import { Button, Card, Notice, SectionTitle, SettingRow, Toggle } from "./ui";
import { useToast } from "./Toast";

export function DataSettings() {
  const s = useSettings();
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [photos, setPhotos] = useState(true);
  const [busy, setBusy] = useState(false);
  if (!s) return null;
  const ago = s.lastBackup ? daysBetween(s.lastBackup, todayStr()) : null;

  const doExport = async () => {
    setBusy(true);
    try {
      const r = await downloadBackup({ photos, apiKey: false });
      toast({ text: r === "shared" ? "Backup geteilt" : "Backup heruntergeladen" });
    } catch (e) {
      if ((e as Error).name !== "AbortError") toast({ text: `Export fehlgeschlagen: ${(e as Error).message}`, tone: "error" });
    } finally {
      setBusy(false);
    }
  };

  const doImport = async (file?: File) => {
    if (!file) return;
    try {
      const data = parseBackup(await file.text());
      const counts = Object.entries(data.tables)
        .map(([k, v]) => `${k}: ${v.length}`)
        .join(", ");
      if (!confirm(`Backup vom ${new Date(data.exportedAt).toLocaleString("de-DE")} importieren?\n\n${counts}\n\nAlle aktuellen Daten werden ersetzt.`)) return;
      setBusy(true);
      await importData(data);
      toast({ text: "Backup importiert" });
      setTimeout(() => window.location.reload(), 600);
    } catch (e) {
      toast({ text: `Import fehlgeschlagen: ${(e as Error).message}`, tone: "error" });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const doWipe = async () => {
    if (!confirm("Wirklich ALLE Daten auf diesem Gerät löschen? Das kann nicht rückgängig gemacht werden.")) return;
    if (!confirm("Ganz sicher? Erstelle vorher ein Backup.")) return;
    await wipeAll();
    window.location.reload();
  };

  return (
    <>
      <SectionTitle>Daten & Backup</SectionTitle>
      <Card className="space-y-4" >
        <div id="daten" />
        <Notice tone={ago == null || ago > 14 ? "warn" : "info"}>
          {s.lastBackup ? `Letztes Backup: ${formatDate(s.lastBackup, { day: "numeric", month: "long" })} (vor ${ago} Tag${ago === 1 ? "" : "en"})` : "Noch kein Backup. Deine Daten liegen nur auf diesem iPhone."}
        </Notice>
        <SettingRow label="Fotos einschließen" hint="Macht die Datei größer">
          <Toggle checked={photos} onChange={setPhotos} />
        </SettingRow>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="soft" size="lg" onClick={doExport} disabled={busy} data-testid="export">
            <Download size={18} /> Exportieren
          </Button>
          <Button variant="secondary" size="lg" onClick={() => fileRef.current?.click()} disabled={busy} data-testid="import">
            <Upload size={18} /> Importieren
          </Button>
        </div>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => doImport(e.target.files?.[0])} data-testid="import-file" />
        <p className="text-xs text-muted">Export als JSON (ohne API-Key). Tipp: in iCloud Drive speichern. Import ersetzt alle Daten.</p>
        <Button variant="danger" className="w-full" onClick={doWipe}>
          <Trash2 size={16} /> Alle Daten löschen
        </Button>
      </Card>
    </>
  );
}
