"use client";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { X, Keyboard } from "lucide-react";
import { Button, TextInput } from "./ui";

type Controls = { stop: () => void };

export function BarcodeScanner({ open, onClose, onDetected }: { open: boolean; onClose: () => void; onDetected: (code: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<Controls | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [manual, setManual] = useState("");
  const [showManual, setShowManual] = useState(false);
  const cbRef = useRef(onDetected);
  cbRef.current = onDetected;

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setError(null);
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Kamera wird von diesem Browser nicht unterstützt.");
        const [{ BrowserMultiFormatReader }, { DecodeHintType, BarcodeFormat }] = await Promise.all([import("@zxing/browser"), import("@zxing/library")]);
        const hints = new Map();
        hints.set(DecodeHintType.POSSIBLE_FORMATS, [BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E]);
        hints.set(DecodeHintType.TRY_HARDER, true);
        const reader = new BrowserMultiFormatReader(hints, { delayBetweenScanAttempts: 120 });
        if (cancelled || !videoRef.current) return;
        const controls = await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false },
          videoRef.current,
          (result) => {
            if (result && !cancelled) {
              cancelled = true;
              controls.stop();
              if (navigator.vibrate) navigator.vibrate(40);
              cbRef.current(result.getText());
            }
          },
        );
        controlsRef.current = controls;
        if (cancelled) controls.stop();
      } catch (e) {
        const msg = (e as Error)?.name === "NotAllowedError" ? "Kamerazugriff verweigert. Bitte in den iOS-Einstellungen erlauben." : String((e as Error)?.message || e);
        setError(msg);
        setShowManual(true);
      }
    })();
    return () => {
      cancelled = true;
      controlsRef.current?.stop();
      controlsRef.current = null;
    };
  }, [open]);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[60] flex flex-col bg-black text-white" data-testid="barcode-scanner">
      <div className="pt-safe flex items-center justify-between px-4 pb-3">
        <div className="text-lg font-bold">Barcode scannen</div>
        <button aria-label="Schließen" onClick={onClose} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/15">
          <X size={20} />
        </button>
      </div>
      <div className="relative flex-1 overflow-hidden">
        <video ref={videoRef} className="h-full w-full object-cover" playsInline muted autoPlay />
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-40 w-72 rounded-3xl border-4 border-white/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]" />
        </div>
        {error && <div className="absolute inset-x-4 top-4 rounded-2xl bg-red-500/90 p-3 text-sm font-semibold">{error}</div>}
      </div>
      <div className="space-y-3 px-4 pt-4 pb-safe">
        {showManual ? (
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (manual.replace(/\D/g, "").length >= 8) onDetected(manual.replace(/\D/g, ""));
            }}
          >
            <TextInput value={manual} onChange={(e) => setManual(e.target.value)} inputMode="numeric" placeholder="EAN eingeben" className="flex-1 border-white/20 bg-white/10 text-white" data-testid="barcode-manual" />
            <Button type="submit" size="lg">
              OK
            </Button>
          </form>
        ) : (
          <Button variant="secondary" className="w-full bg-white/15 text-white" onClick={() => setShowManual(true)}>
            <Keyboard size={18} /> Nummer eintippen
          </Button>
        )}
        <p className="text-center text-xs text-white/60">Halte den Barcode in den Rahmen.</p>
      </div>
    </div>,
    document.body,
  );
}
