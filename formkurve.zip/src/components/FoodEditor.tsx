"use client";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { db, type Food, type FoodUnit } from "@/lib/db";
import { upsertFood } from "@/lib/store";
import { Button, Field, IconButton, NumberInput, Segmented, Sheet, TextInput, Toggle } from "./ui";
import { useToast } from "./Toast";

const EMPTY: Food = { name: "", source: "custom", kcal: 0, protein: 0, carbs: 0, fat: 0, units: [], favorite: 0, useCount: 0, updatedAt: 0 };

export function FoodEditor({
  open,
  initial,
  onClose,
  onSaved,
}: {
  open: boolean;
  initial?: Partial<Food> | null;
  onClose: () => void;
  onSaved?: (f: Food) => void;
}) {
  const toast = useToast();
  const [f, setF] = useState<Food>(EMPTY);
  const [mode, setMode] = useState<"100" | "portion">("100");
  const [portionG, setPortionG] = useState<number | undefined>(undefined);
  const [vals, setVals] = useState<{ kcal?: number; protein?: number; carbs?: number; fat?: number }>({});

  useEffect(() => {
    if (!open) return;
    const base = { ...EMPTY, ...(initial || {}) } as Food;
    if (base.source !== "custom" && base.source !== "recipe") {
      // OFF-/Basis-Lebensmittel bearbeiten → wird zu eigenem Lebensmittel
      base.source = initial?.id ? (initial.source as Food["source"]) : "custom";
    }
    setF(base);
    setMode("100");
    setPortionG(undefined);
    setVals(initial?.id || initial?.kcal ? { kcal: base.kcal, protein: base.protein, carbs: base.carbs, fat: base.fat } : {});
  }, [open, initial]);

  const per100 = (v?: number) => {
    if (v == null) return 0;
    if (mode === "portion" && portionG) return Math.round((v / portionG) * 1000) / 10;
    return v;
  };

  const valid = f.name.trim().length > 0 && vals.kcal != null && (mode === "100" || (portionG && portionG > 0));

  const save = async () => {
    const units: FoodUnit[] = [...f.units.filter((u) => u.label.trim() && u.grams > 0)];
    if (mode === "portion" && portionG && !units.some((u) => u.grams === portionG)) units.unshift({ label: "Portion", grams: portionG });
    const food: Food = {
      ...f,
      name: f.name.trim(),
      brand: f.brand?.trim() || undefined,
      barcode: f.barcode?.trim() || undefined,
      kcal: Math.round(per100(vals.kcal)),
      protein: per100(vals.protein),
      carbs: per100(vals.carbs),
      fat: per100(vals.fat),
      units,
      source: f.source === "recipe" ? "recipe" : f.source === "off" && f.id ? "off" : "custom",
      updatedAt: Date.now(),
    };
    const id = await upsertFood(food);
    const saved = (await db.foods.get(id))!;
    toast({ text: "Lebensmittel gespeichert" });
    onSaved?.(saved);
    onClose();
  };

  const remove = async () => {
    if (!f.id) return;
    await db.foods.delete(f.id);
    toast({ text: "Lebensmittel gelöscht" });
    onClose();
  };

  const setUnit = (i: number, patch: Partial<FoodUnit>) => setF((cur) => ({ ...cur, units: cur.units.map((u, j) => (j === i ? { ...u, ...patch } : u)) }));

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={f.id ? "Lebensmittel bearbeiten" : "Eigenes Lebensmittel"}
      testId="food-editor"
      footer={
        <div className="flex gap-2">
          {f.id && (
            <Button variant="danger" size="lg" onClick={remove} aria-label="Löschen">
              <Trash2 size={18} />
            </Button>
          )}
          <Button size="lg" className="flex-1" disabled={!valid} onClick={save} data-testid="food-save">
            Speichern
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        <Field label="Name">
          <TextInput value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="z. B. Omas Linsensuppe" data-testid="food-name" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Marke (optional)">
            <TextInput value={f.brand || ""} onChange={(e) => setF({ ...f, brand: e.target.value })} />
          </Field>
          <Field label="Barcode (optional)">
            <TextInput value={f.barcode || ""} inputMode="numeric" onChange={(e) => setF({ ...f, barcode: e.target.value })} />
          </Field>
        </div>
        <Segmented
          value={mode}
          onChange={setMode}
          options={[
            { value: "100", label: "pro 100 g" },
            { value: "portion", label: "pro Portion" },
          ]}
        />
        {mode === "portion" && (
          <Field label="Portionsgröße">
            <NumberInput value={portionG} onChange={setPortionG} suffix="g" placeholder="z. B. 60" />
          </Field>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Kalorien">
            <NumberInput value={vals.kcal} onChange={(v) => setVals({ ...vals, kcal: v })} suffix="kcal" data-testid="food-kcal" />
          </Field>
          <Field label="Eiweiß">
            <NumberInput value={vals.protein} onChange={(v) => setVals({ ...vals, protein: v })} suffix="g" data-testid="food-protein" />
          </Field>
          <Field label="Kohlenhydrate">
            <NumberInput value={vals.carbs} onChange={(v) => setVals({ ...vals, carbs: v })} suffix="g" data-testid="food-carbs" />
          </Field>
          <Field label="Fett">
            <NumberInput value={vals.fat} onChange={(v) => setVals({ ...vals, fat: v })} suffix="g" data-testid="food-fat" />
          </Field>
        </div>
        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[13px] font-medium text-muted">Einheiten (z. B. „Stück“ = 60 g)</span>
            <Button size="sm" variant="soft" onClick={() => setF({ ...f, units: [...f.units, { label: "Stück", grams: 0 }] })}>
              <Plus size={14} /> Einheit
            </Button>
          </div>
          <div className="space-y-2">
            {f.units.map((u, i) => (
              <div key={i} className="flex items-center gap-2">
                <TextInput value={u.label} onChange={(e) => setUnit(i, { label: e.target.value })} className="flex-1" aria-label="Einheit" />
                <NumberInput value={u.grams || undefined} onChange={(v) => setUnit(i, { grams: v || 0 })} suffix="g" className="w-32" aria-label="Gramm" />
                <IconButton label="Einheit entfernen" onClick={() => setF({ ...f, units: f.units.filter((_, j) => j !== i) })}>
                  <Trash2 size={16} />
                </IconButton>
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between rounded-2xl bg-card2 px-4 py-3">
          <span className="font-semibold">Favorit</span>
          <Toggle checked={!!f.favorite} onChange={(v) => setF({ ...f, favorite: v ? 1 : 0 })} />
        </div>
      </div>
    </Sheet>
  );
}
