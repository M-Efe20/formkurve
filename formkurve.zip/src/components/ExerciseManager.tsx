"use client";
import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowUp, ArrowDown, Trash2, Plus } from "lucide-react";
import { db } from "@/lib/db";
import { Button, IconButton, NumberInput, Sheet, TextInput, Toggle } from "./ui";

export function ExerciseManager({ open, onClose }: { open: boolean; onClose: () => void }) {
  const defs = useLiveQuery(() => db.exercises.orderBy("order").toArray(), []);
  const [name, setName] = useState("");

  const move = async (i: number, dir: -1 | 1) => {
    if (!defs) return;
    const j = i + dir;
    if (j < 0 || j >= defs.length) return;
    await db.transaction("rw", db.exercises, async () => {
      await db.exercises.update(defs[i].id!, { order: defs[j].order });
      await db.exercises.update(defs[j].id!, { order: defs[i].order });
    });
  };
  const add = async () => {
    const n = name.trim();
    if (!n || defs?.some((d) => d.name.toLowerCase() === n.toLowerCase())) return;
    const maxOrder = Math.max(-1, ...(defs || []).map((d) => d.order));
    await db.exercises.add({ name: n, repMin: 8, repMax: 12, increment: 2.5, sets: 3, order: maxOrder + 1, active: 1 });
    setName("");
  };

  return (
    <Sheet open={open} onClose={onClose} full title="Übungen im Ganzkörperplan" testId="exercise-manager">
      <div className="space-y-3">
        <p className="text-sm text-muted">Aktive Übungen landen automatisch im Training. Spanne = Wiederholungsbereich für die Doppel-Progression.</p>
        {defs?.map((d, i) => (
          <div key={d.id} className="rounded-2xl bg-card2 p-3">
            <div className="flex items-center gap-2">
              <Toggle checked={!!d.active} onChange={(v) => db.exercises.update(d.id!, { active: v ? 1 : 0 })} label={`${d.name} aktiv`} />
              <span className="min-w-0 flex-1 truncate font-semibold">{d.name}</span>
              <IconButton label="Nach oben" className="h-8 w-8 bg-card" onClick={() => move(i, -1)}>
                <ArrowUp size={14} />
              </IconButton>
              <IconButton label="Nach unten" className="h-8 w-8 bg-card" onClick={() => move(i, 1)}>
                <ArrowDown size={14} />
              </IconButton>
              <IconButton label={`${d.name} löschen`} className="h-8 w-8 bg-card" onClick={() => confirm(`„${d.name}“ löschen?`) && db.exercises.delete(d.id!)}>
                <Trash2 size={14} />
              </IconButton>
            </div>
            <div className="mt-2 grid grid-cols-4 gap-2 text-[11px] text-muted">
              <label>
                Sätze
                <NumberInput value={d.sets} onChange={(v) => v && v > 0 && v < 10 && db.exercises.update(d.id!, { sets: Math.round(v) })} className="[&_input]:h-10 [&_input]:bg-card" />
              </label>
              <label>
                Wdh. min
                <NumberInput value={d.repMin} onChange={(v) => v && v > 0 && db.exercises.update(d.id!, { repMin: Math.round(v) })} className="[&_input]:h-10 [&_input]:bg-card" />
              </label>
              <label>
                Wdh. max
                <NumberInput value={d.repMax} onChange={(v) => v && v >= d.repMin && db.exercises.update(d.id!, { repMax: Math.round(v) })} className="[&_input]:h-10 [&_input]:bg-card" />
              </label>
              <label>
                + kg
                <NumberInput value={d.increment} onChange={(v) => v != null && v >= 0 && db.exercises.update(d.id!, { increment: v })} className="[&_input]:h-10 [&_input]:bg-card" />
              </label>
            </div>
          </div>
        ))}
        <div className="flex gap-2">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Neue Übung, z. B. Beinpresse" className="flex-1" />
          <Button size="lg" onClick={add} disabled={!name.trim()}>
            <Plus size={18} />
          </Button>
        </div>
      </div>
    </Sheet>
  );
}
