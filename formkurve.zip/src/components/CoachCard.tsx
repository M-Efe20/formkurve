"use client";
import { useEffect, useMemo } from "react";
import Link from "next/link";
import { useLiveQuery } from "dexie-react-hooks";
import { Sparkles, RefreshCw, MessageCircle, CalendarCheck } from "lucide-react";
import { db, type Entry, type Settings } from "@/lib/db";
import type { Targets } from "@/lib/calc";
import { basicSuggestion } from "@/lib/coach";
import { weekStart } from "@/lib/dates";
import { useDay } from "@/lib/hooks";
import { Button, Card, IconButton, Notice, Spinner } from "./ui";
import { ReviewView, SuggestionView, markAutoTried, useCoachRunner } from "./CoachViews";

export function CoachCard({
  date,
  now,
  totals,
  targets,
  settings,
  entries,
}: {
  date: string;
  now: Date;
  totals: { kcal: number; protein: number; carbs: number; fat: number };
  targets: Targets;
  settings: Settings;
  entries: Entry[];
}) {
  const day = useDay(date);
  const weekly = useLiveQuery(
    async () => (await db.notes.where("date").equals(weekStart(date)).filter((n) => n.type === "weekly").first()) ?? null,
    [date],
  );
  const { run, busy, error } = useCoachRunner(settings, date);
  const hasKey = !!settings.apiKey;
  const evening = now.getHours() >= 17;
  const sunday = now.getDay() === 0;
  const dinnerLogged = entries.some((e) => e.meal === "dinner");
  const auto = settings.autoCoach && hasKey;

  // Automatische KI-Aufrufe (je einmal pro Tag/Woche)
  useEffect(() => {
    if (!auto || !day || weekly === undefined || busy) return;
    if (sunday && now.getHours() >= 12 && !weekly && markAutoTried(`weekly-${weekStart(date)}`)) {
      run("weekly");
      return;
    }
    if (dinnerLogged && !day.feedback && markAutoTried(`feedback-${date}`)) {
      run("feedback");
      return;
    }
    if (evening && !day.suggestion && !dinnerLogged && markAutoTried(`suggestion-${date}`)) {
      run("suggestion");
    }
  }, [auto, day, weekly, sunday, evening, dinnerLogged, date, now, run, busy]);

  const ctxSuggestion = useMemo(() => {
    if (hasKey || !evening) return null;
    return basicSuggestion({
      settings,
      date,
      entries,
      weight: targets.weightUsed,
      budget: targets.budget,
      protein: targets.protein,
      carbs: targets.carbs,
      fat: targets.fat,
      isTraining: targets.isTraining,
      activitiesDone: day?.activities || [],
      favorites: [],
    });
    // totals ändert sich mit entries
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasKey, evening, entries, targets, settings, date, totals.kcal]);

  if (!day) return null;
  const suggestion = day.suggestion || ctxSuggestion;
  const showWeekly = sunday && (weekly || busy === "weekly");
  const showFeedback = !!day.feedback || busy === "feedback";
  const showSuggestion = evening;
  if (!showWeekly && !showFeedback && !showSuggestion && !error) return null;

  return (
    <div className="mt-3 space-y-3" data-testid="coach-card">
      {error && <Notice tone="warn">KI-Coach: {error}</Notice>}

      {showWeekly && (
        <Card>
          <Header icon={<CalendarCheck size={18} />} title="Wochenrückblick" busy={busy === "weekly"} onRefresh={hasKey ? () => run("weekly") : undefined} />
          {weekly && <ReviewView r={weekly.data} />}
        </Card>
      )}

      {showFeedback && (
        <Card>
          <Header icon={<MessageCircle size={18} />} title="Dein Tag" busy={busy === "feedback"} onRefresh={hasKey ? () => run("feedback") : undefined} />
          {day.feedback && (
            <p className="text-[15px]" data-testid="daily-feedback">
              {day.feedback}
            </p>
          )}
        </Card>
      )}

      {showSuggestion && (
        <Card>
          <Header icon={<Sparkles size={18} />} title="Was geht heute noch?" busy={busy === "suggestion"} onRefresh={() => run("suggestion")} />
          {suggestion ? (
            <SuggestionView s={suggestion} compact />
          ) : (
            busy !== "suggestion" && (
              <Button variant="soft" className="w-full" onClick={() => run("suggestion")} data-testid="suggestion-get">
                Vorschlag holen
              </Button>
            )
          )}
          {!hasKey && (
            <p className="mt-3 text-xs text-muted">
              Einfacher Vorschlag ohne KI.{" "}
              <Link href="/settings/" className="font-semibold text-accent-strong dark:text-accent">
                API-Key eintragen
              </Link>{" "}
              für persönliche Gerichte.
            </p>
          )}
        </Card>
      )}
    </div>
  );
}

function Header({ icon, title, busy, onRefresh }: { icon: React.ReactNode; title: string; busy: boolean; onRefresh?: () => void }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <div className="flex items-center gap-2 font-bold">
        <span className="text-accent-strong dark:text-accent">{icon}</span>
        {title}
      </div>
      {busy ? (
        <Spinner className="text-muted" />
      ) : (
        onRefresh && (
          <IconButton label={`${title} aktualisieren`} className="h-8 w-8" onClick={onRefresh}>
            <RefreshCw size={15} />
          </IconButton>
        )
      )}
    </div>
  );
}
