"use client";
import { useEffect, useState } from "react";
import { Eye, EyeOff, CheckCircle2 } from "lucide-react";
import { useSettings } from "@/lib/hooks";
import { saveSettings } from "@/lib/store";
import { callClaude, FALLBACK_MODELS, listModels } from "@/lib/ai";
import { Button, Card, Field, Notice, SectionTitle, Select, SettingRow, TextInput, Toggle, Spinner } from "./ui";

export function AiSettings() {
  const s = useSettings();
  const [key, setKey] = useState("");
  const [show, setShow] = useState(false);
  const [models, setModels] = useState(FALLBACK_MODELS);
  const [status, setStatus] = useState<{ tone: "ok" | "danger"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (s?.apiKey !== undefined) setKey(s.apiKey || "");
  }, [s?.apiKey]);

  useEffect(() => {
    if (!s?.apiKey) return;
    listModels(s.apiKey)
      .then((list) => {
        const claude = list.filter((m) => m.id.startsWith("claude"));
        if (claude.length) setModels(claude);
      })
      .catch(() => {});
  }, [s?.apiKey]);

  if (!s) return null;

  const saveKey = async () => {
    await saveSettings({ apiKey: key.trim() || undefined });
    setStatus(null);
  };

  const test = async () => {
    setBusy(true);
    setStatus(null);
    try {
      await saveKey();
      const r = await callClaude({ apiKey: key.trim(), aiModel: s.aiModel }, { system: "Antworte sehr kurz.", content: "Sag nur: OK", maxTokens: 10 });
      setStatus({ tone: "ok", text: `Verbindung steht (${s.aiModel}): ${r.slice(0, 20)}` });
    } catch (e) {
      setStatus({ tone: "danger", text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const modelList = models.some((m) => m.id === s.aiModel) ? models : [{ id: s.aiModel, name: s.aiModel }, ...models];

  return (
    <>
      <SectionTitle>KI-Coach (Claude)</SectionTitle>
      <Card className="space-y-4">
        <Field label="Claude API-Key" hint="Bekommst du unter console.anthropic.com → API Keys. Wird nur auf diesem Gerät gespeichert.">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <TextInput
                type={show ? "text" : "password"}
                value={key}
                onChange={(e) => setKey(e.target.value)}
                onBlur={saveKey}
                placeholder="sk-ant-…"
                autoComplete="off"
                autoCapitalize="off"
                spellCheck={false}
                className="pr-11"
                data-testid="api-key"
              />
              <button type="button" aria-label={show ? "Key verbergen" : "Key anzeigen"} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted" onClick={() => setShow(!show)}>
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <Button variant="secondary" size="lg" onClick={test} disabled={!key.trim() || busy} data-testid="api-test">
              {busy ? <Spinner /> : "Testen"}
            </Button>
          </div>
        </Field>
        {status && (
          <Notice tone={status.tone}>
            <span className="flex items-center gap-2">
              {status.tone === "ok" && <CheckCircle2 size={16} />} {status.text}
            </span>
          </Notice>
        )}
        <Field label="Modell">
          <Select value={s.aiModel} onChange={(e) => saveSettings({ aiModel: e.target.value })} data-testid="ai-model">
            {modelList.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </Select>
        </Field>
        <SettingRow label="Automatischer Coach" hint="Abendvorschlag, Tagesfeedback nach dem Abendessen, Wochenrückblick am Sonntag">
          <Toggle checked={s.autoCoach} onChange={(v) => saveSettings({ autoCoach: v })} />
        </SettingRow>
        <p className="text-xs text-muted">Kosten: wenige Cent pro Tag (abhängig vom Modell). Anfragen gehen direkt vom Handy an Anthropic, nicht über einen anderen Server.</p>
      </Card>
    </>
  );
}
