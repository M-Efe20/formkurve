"use client";
import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";

interface ToastItem {
  id: number;
  text: string;
  action?: { label: string; run: () => void };
  tone?: "ok" | "warn" | "error";
}

const Ctx = createContext<(t: Omit<ToastItem, "id">, ms?: number) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const seq = useRef(0);
  const show = useCallback((t: Omit<ToastItem, "id">, ms = 3200) => {
    const id = ++seq.current;
    setItems((cur) => [...cur.slice(-1), { ...t, id }]);
    setTimeout(() => setItems((cur) => cur.filter((x) => x.id !== id)), ms);
  }, []);
  return (
    <Ctx.Provider value={show}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 z-[70] flex flex-col items-center gap-2 px-4" style={{ bottom: "calc(env(safe-area-inset-bottom) + 92px)" }}>
        {items.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto flex w-full max-w-md items-center justify-between gap-3 rounded-2xl px-4 py-3 text-sm font-semibold shadow-lg animate-toast ${
              t.tone === "error" ? "bg-danger text-white" : t.tone === "warn" ? "bg-warn text-black" : "bg-fg text-bg"
            }`}
          >
            <span>{t.text}</span>
            {t.action && (
              <button
                className="shrink-0 rounded-lg px-2 py-1 font-bold underline-offset-2 hover:underline"
                onClick={() => {
                  t.action!.run();
                  setItems((cur) => cur.filter((x) => x.id !== t.id));
                }}
              >
                {t.action.label}
              </button>
            )}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  return useContext(Ctx);
}
