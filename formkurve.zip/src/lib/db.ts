import Dexie, { type Table } from "dexie";

export type Sex = "m" | "f";
export type MealKey = "breakfast" | "lunch" | "dinner" | "snack";
export type ThemePref = "system" | "dark" | "light";

export const MEALS: { key: MealKey; label: string }[] = [
  { key: "breakfast", label: "Frühstück" },
  { key: "lunch", label: "Mittagessen" },
  { key: "dinner", label: "Abendessen" },
  { key: "snack", label: "Snacks" },
];

export interface ActivityDef {
  key: string;
  label: string;
  minutes: number;
  met: number;
}

export interface Settings {
  id: "main";
  onboarded: boolean;
  sex: Sex;
  age: number;
  heightCm: number;
  startWeightKg: number;
  goalWeightKg: number;
  startDate: string;
  /** "auto" = aus Alltag + Trainingsplan berechnet, sonst fester Faktor */
  activityMode: "auto" | "manual";
  neatFactor: number;
  manualFactor: number;
  deficit: number;
  trainingBonus: number;
  minKcal: number;
  proteinPerKg: number;
  fatPerKg: number;
  waterGoalMl: number;
  stepGoalMin: number;
  stepGoal: number;
  /** Wochentag (0 = Sonntag … 6 = Samstag) → Aktivitäts-Keys */
  schedule: Record<number, string[]>;
  activities: ActivityDef[];
  adaptive: boolean;
  adaptiveTdee?: number;
  adaptiveUpdated?: string;
  apiKey?: string;
  aiModel: string;
  autoCoach: boolean;
  theme: ThemePref;
  lastBackup?: string;
}

export interface FoodUnit {
  label: string;
  grams: number;
}

export type HalalStatus = "certified" | "warning" | "caution" | "unknown";

export interface Food {
  id?: number;
  name: string;
  brand?: string;
  barcode?: string;
  source: "off" | "custom" | "basic" | "recipe" | "ai";
  /** Nährwerte pro 100 g */
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  units: FoodUnit[];
  ingredients?: { foodId?: number; name: string; grams: number; kcal: number; protein: number; carbs: number; fat: number }[];
  halal?: HalalStatus;
  halalNote?: string;
  favorite: 0 | 1;
  lastUsed?: number;
  useCount: number;
  lastAmount?: number;
  lastUnit?: string;
  lastMeal?: MealKey;
  imageUrl?: string;
  updatedAt: number;
}

export interface Entry {
  id?: number;
  date: string;
  meal: MealKey;
  foodId?: number;
  name: string;
  brand?: string;
  amount: number;
  unit: string;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  createdAt: number;
}

export interface DayLog {
  date: string;
  waterMl: number;
  steps?: number;
  activities: string[];
  feedback?: string;
  feedbackAt?: number;
  suggestion?: CoachSuggestion;
  suggestionAt?: number;
}

export interface CoachSuggestion {
  intro?: string;
  options: {
    title: string;
    items: { name: string; amount: string }[];
    kcal: number;
    protein: number;
    carbs?: number;
    fat?: number;
    prep?: string;
    cost?: string;
  }[];
  tip?: string;
  source: "ai" | "basic";
}

export interface WeightLog {
  date: string;
  kg: number;
}

export interface WaistLog {
  date: string;
  cm: number;
}

export interface ProgressPhoto {
  id?: number;
  date: string;
  blob: Blob;
  note?: string;
}

export interface WorkoutSet {
  kg: number;
  reps: number;
  done?: boolean;
}

export interface Workout {
  id?: number;
  date: string;
  name: string;
  exercises: { name: string; sets: WorkoutSet[] }[];
  notes?: string;
  createdAt: number;
}

export interface ExerciseDef {
  id?: number;
  name: string;
  repMin: number;
  repMax: number;
  increment: number;
  sets: number;
  order: number;
  active: 0 | 1;
}

export interface CoachNote {
  id?: number;
  type: "weekly";
  date: string;
  data: WeeklyReview;
  createdAt: number;
}

export interface WeeklyReview {
  summary: string;
  good: string[];
  improve: string[];
  tips: string[];
  stats?: Record<string, number | string>;
}

export class FormkurveDB extends Dexie {
  settings!: Table<Settings, string>;
  foods!: Table<Food, number>;
  entries!: Table<Entry, number>;
  days!: Table<DayLog, string>;
  weights!: Table<WeightLog, string>;
  waists!: Table<WaistLog, string>;
  photos!: Table<ProgressPhoto, number>;
  workouts!: Table<Workout, number>;
  exercises!: Table<ExerciseDef, number>;
  notes!: Table<CoachNote, number>;

  constructor() {
    super("formkurve");
    this.version(1).stores({
      settings: "id",
      foods: "++id, barcode, name, favorite, lastUsed, source",
      entries: "++id, date, meal, foodId, createdAt",
      days: "date",
      weights: "date",
      waists: "date",
      photos: "++id, date",
      workouts: "++id, date",
      exercises: "++id, name, order",
      notes: "++id, type, date",
    });
  }
}

export const db = new FormkurveDB();

export const TABLE_NAMES = [
  "settings",
  "foods",
  "entries",
  "days",
  "weights",
  "waists",
  "photos",
  "workouts",
  "exercises",
  "notes",
] as const;
export type TableName = (typeof TABLE_NAMES)[number];
