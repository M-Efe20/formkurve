import { db, type Food, type Entry, type DayLog, type MealKey, type Settings, type ExerciseDef } from "./db";
import { basicFoods } from "./basics";
import { defaultSettings, gramsFor, nutrientsFor } from "./calc";
import { todayStr } from "./dates";

export const DEFAULT_EXERCISES: Omit<ExerciseDef, "id">[] = [
  { name: "Kniebeuge (Langhantel)", repMin: 6, repMax: 10, increment: 2.5, sets: 3, order: 0, active: 1 },
  { name: "Bankdrücken", repMin: 6, repMax: 10, increment: 2.5, sets: 3, order: 1, active: 1 },
  { name: "Latzug", repMin: 8, repMax: 12, increment: 2.5, sets: 3, order: 2, active: 1 },
  { name: "Rumänisches Kreuzheben", repMin: 8, repMax: 12, increment: 2.5, sets: 3, order: 3, active: 1 },
  { name: "Schulterdrücken (Kurzhantel)", repMin: 8, repMax: 12, increment: 2, sets: 3, order: 4, active: 1 },
  { name: "Rudern am Kabel", repMin: 8, repMax: 12, increment: 2.5, sets: 3, order: 5, active: 1 },
];

let seeded: Promise<void> | null = null;

export function ensureSeed(): Promise<void> {
  if (!seeded) {
    seeded = db.transaction("rw", db.foods, db.exercises, db.settings, async () => {
      const basics = await db.foods.where("source").equals("basic").count();
      if (basics === 0) await db.foods.bulkAdd(basicFoods());
      const ex = await db.exercises.count();
      if (ex === 0) await db.exercises.bulkAdd(DEFAULT_EXERCISES.map((e) => ({ ...e })));
      const s = await db.settings.get("main");
      if (!s) await db.settings.put(defaultSettings());
    });
    if (typeof navigator !== "undefined" && navigator.storage?.persist) {
      navigator.storage.persist().catch(() => {});
    }
  }
  return seeded;
}

export async function getSettings(): Promise<Settings> {
  const s = await db.settings.get("main");
  return { ...defaultSettings(), ...(s || {}) };
}

export async function saveSettings(patch: Partial<Settings>): Promise<void> {
  const cur = await getSettings();
  await db.settings.put({ ...cur, ...patch, id: "main" });
  if (patch.theme && typeof localStorage !== "undefined") {
    try {
      localStorage.setItem("fk-theme", patch.theme);
    } catch {}
  }
}

/** Speichert ein (z. B. Open-Food-Facts-)Lebensmittel lokal, dedupliziert per Barcode */
export async function upsertFood(food: Food): Promise<number> {
  if (food.id) {
    await db.foods.put({ ...food, updatedAt: Date.now() });
    return food.id;
  }
  if (food.barcode) {
    const existing = await db.foods.where("barcode").equals(food.barcode).first();
    if (existing?.id) {
      const merged: Food = {
        ...existing,
        ...food,
        id: existing.id,
        favorite: existing.favorite,
        useCount: existing.useCount,
        lastUsed: existing.lastUsed,
        lastAmount: existing.lastAmount,
        lastUnit: existing.lastUnit,
        // eigene Korrekturen nicht überschreiben
        ...(existing.source === "custom" ? { kcal: existing.kcal, protein: existing.protein, carbs: existing.carbs, fat: existing.fat, name: existing.name, source: "custom" as const } : {}),
        updatedAt: Date.now(),
      };
      await db.foods.put(merged);
      return existing.id;
    }
  }
  // Hilfsfelder (isGerman) entfernen
  const clean: Food & { isGerman?: boolean } = { ...food };
  delete clean.isGerman;
  return db.foods.add({ ...clean, updatedAt: Date.now() });
}

export function defaultPortion(food: Food): { amount: number; unit: string } {
  if (food.lastAmount && food.lastUnit) return { amount: food.lastAmount, unit: food.lastUnit };
  if (food.units?.length) return { amount: 1, unit: food.units[0].label };
  return { amount: 100, unit: "g" };
}

export function buildEntry(food: Food, amount: number, unit: string, meal: MealKey, date: string): Entry {
  const grams = gramsFor(amount, unit, food.units || []);
  const n = nutrientsFor(food, grams);
  return {
    date,
    meal,
    foodId: food.id,
    name: food.name,
    brand: food.brand,
    amount,
    unit,
    grams,
    ...n,
    createdAt: Date.now(),
  };
}

export async function logFood(food: Food, amount: number, unit: string, meal: MealKey, date: string): Promise<number> {
  const foodId = food.id ?? (await upsertFood(food));
  const stored = (await db.foods.get(foodId)) || { ...food, id: foodId };
  const entry = buildEntry(stored, amount, unit, meal, date);
  const id = await db.entries.add(entry);
  await db.foods.update(foodId, {
    lastUsed: Date.now(),
    useCount: (stored.useCount || 0) + 1,
    lastAmount: amount,
    lastUnit: unit,
    lastMeal: meal,
  });
  return id;
}

export async function updateEntryPortion(entry: Entry, amount: number, unit: string, meal: MealKey): Promise<void> {
  const food = entry.foodId ? await db.foods.get(entry.foodId) : undefined;
  if (food) {
    const e = buildEntry(food, amount, unit, meal, entry.date);
    await db.entries.update(entry.id!, { amount, unit, meal, grams: e.grams, kcal: e.kcal, protein: e.protein, carbs: e.carbs, fat: e.fat });
    await db.foods.update(food.id!, { lastAmount: amount, lastUnit: unit });
  } else {
    // freie Einträge (z. B. KI): proportional skalieren
    const f = entry.amount ? amount / entry.amount : 1;
    await db.entries.update(entry.id!, {
      amount,
      unit,
      meal,
      grams: Math.round(entry.grams * f),
      kcal: Math.round(entry.kcal * f),
      protein: Math.round(entry.protein * f * 10) / 10,
      carbs: Math.round(entry.carbs * f * 10) / 10,
      fat: Math.round(entry.fat * f * 10) / 10,
    });
  }
}

export async function getDay(date: string): Promise<DayLog> {
  return (await db.days.get(date)) || { date, waterMl: 0, activities: [] };
}

export async function updateDay(date: string, patch: Partial<DayLog> | ((d: DayLog) => Partial<DayLog>)): Promise<void> {
  await db.transaction("rw", db.days, async () => {
    const cur = await getDay(date);
    const p = typeof patch === "function" ? patch(cur) : patch;
    await db.days.put({ ...cur, ...p, date });
  });
}

export async function toggleActivity(date: string, key: string): Promise<void> {
  await updateDay(date, (d) => ({
    activities: d.activities.includes(key) ? d.activities.filter((a) => a !== key) : [...d.activities, key],
  }));
}

export async function setWeight(date: string, kg: number): Promise<void> {
  await db.weights.put({ date, kg });
}

export async function completeOnboarding(patch: Partial<Settings>): Promise<void> {
  const today = todayStr();
  await saveSettings({ ...patch, onboarded: true, startDate: patch.startDate || today });
  if (patch.startWeightKg) {
    const existing = await db.weights.get(today);
    if (!existing) await setWeight(today, patch.startWeightKg);
  }
}
