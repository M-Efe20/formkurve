import { db, TABLE_NAMES, type Settings } from "./db";
import { blobToDataUrl, dataUrlToBlob } from "./image";
import { todayStr } from "./dates";

export interface BackupFile {
  app: "formkurve";
  version: 1;
  exportedAt: string;
  tables: Record<string, unknown[]>;
}

export async function exportData(opts: { photos: boolean; apiKey: boolean }): Promise<BackupFile> {
  const tables: Record<string, unknown[]> = {};
  for (const name of TABLE_NAMES) {
    if (name === "photos") {
      if (!opts.photos) continue;
      const rows = await db.photos.toArray();
      tables.photos = await Promise.all(rows.map(async (p) => ({ ...p, blob: undefined, dataUrl: await blobToDataUrl(p.blob) })));
      continue;
    }
    let rows = await (db[name] as unknown as { toArray: () => Promise<unknown[]> }).toArray();
    if (name === "settings" && !opts.apiKey) rows = (rows as Settings[]).map((s) => ({ ...s, apiKey: undefined }));
    tables[name] = rows;
  }
  return { app: "formkurve", version: 1, exportedAt: new Date().toISOString(), tables };
}

export async function downloadBackup(opts: { photos: boolean; apiKey: boolean }): Promise<"shared" | "downloaded"> {
  const data = await exportData(opts);
  const name = `formkurve-backup-${todayStr()}.json`;
  const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
  const file = new File([blob], name, { type: "application/json" });
  const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
  const isTouch = matchMedia("(pointer: coarse)").matches;
  if (isTouch && nav.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: name });
      await markBackup();
      return "shared";
    } catch (e) {
      if ((e as Error).name === "AbortError") throw e;
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  await markBackup();
  return "downloaded";
}

async function markBackup() {
  const s = await db.settings.get("main");
  if (s) await db.settings.put({ ...s, lastBackup: todayStr() });
}

export function parseBackup(text: string): BackupFile {
  const data = JSON.parse(text);
  if (data?.app !== "formkurve" || !data.tables) throw new Error("Keine gültige Formkurve-Sicherung.");
  return data as BackupFile;
}

export async function importData(data: BackupFile): Promise<void> {
  const current = await db.settings.get("main");
  const photos = data.tables.photos
    ? await Promise.all(
        (data.tables.photos as { id?: number; date: string; note?: string; dataUrl: string }[]).map(async (p) => ({ id: p.id, date: p.date, note: p.note, blob: await dataUrlToBlob(p.dataUrl) })),
      )
    : null;
  await db.transaction("rw", TABLE_NAMES.map((n) => db[n]), async () => {
    for (const name of TABLE_NAMES) {
      if (name === "photos" && !photos) continue; // vorhandene Fotos behalten, wenn Backup keine enthält
      await db[name].clear();
      if (name === "photos") {
        await db.photos.bulkPut(photos!);
        continue;
      }
      let rows = (data.tables[name] || []) as unknown[];
      if (name === "settings") rows = (rows as Settings[]).map((s) => ({ ...s, apiKey: s.apiKey || current?.apiKey }));
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (db[name] as any).bulkPut(rows);
    }
  });
}

export async function wipeAll(): Promise<void> {
  await db.transaction("rw", TABLE_NAMES.map((n) => db[n]), async () => {
    for (const name of TABLE_NAMES) await db[name].clear();
  });
}
