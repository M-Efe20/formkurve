import type { ExerciseDef, Workout, WorkoutSet } from "./db";

export interface LastPerformance {
  date: string;
  sets: WorkoutSet[];
}

/** Letzte Einheit einer Übung vor einem Datum (ohne das aktuelle Workout) */
export function lastPerformance(workouts: Workout[], exercise: string, beforeDate: string, excludeId?: number): LastPerformance | null {
  const sorted = workouts
    .filter((w) => w.date <= beforeDate && w.id !== excludeId)
    .sort((a, b) => (a.date === b.date ? b.createdAt - a.createdAt : a.date < b.date ? 1 : -1));
  for (const w of sorted) {
    const ex = w.exercises.find((e) => e.name === exercise);
    const sets = ex?.sets.filter((s) => s.done !== false && s.reps > 0) || [];
    if (sets.length) return { date: w.date, sets };
  }
  return null;
}

export interface Suggestion {
  kind: "first" | "increase" | "reps" | "hold";
  text: string;
  sets: WorkoutSet[];
}

const r25 = (n: number) => Math.round(n * 4) / 4;

/**
 * Progressive Overload per Doppel-Progression:
 * - Alle Sätze am oberen Ende der Wdh.-Spanne → Gewicht + Inkrement, zurück aufs untere Ende
 * - Sonst gleiches Gewicht, pro Satz +1 Wiederholung (max. obere Grenze)
 */
export function suggestNext(def: Pick<ExerciseDef, "repMin" | "repMax" | "increment" | "sets">, last: LastPerformance | null): Suggestion {
  const n = Math.max(1, def.sets);
  if (!last || !last.sets.length) {
    return {
      kind: "first",
      text: `Erstes Mal: Gewicht wählen, mit dem ${def.repMin}–${def.repMax} saubere Wiederholungen gehen.`,
      sets: Array.from({ length: n }, () => ({ kg: 0, reps: def.repMin, done: false })),
    };
  }
  const topKg = Math.max(...last.sets.map((s) => s.kg));
  const top = last.sets.filter((s) => s.kg === topKg);
  const bodyweight = topKg === 0;

  if (top.length >= n && top.slice(0, n).every((s) => s.reps >= def.repMax)) {
    if (bodyweight) {
      return {
        kind: "reps",
        text: `Ziel geschafft – nächstes Mal ${def.repMax + 2} Wdh. oder eine schwerere Variante.`,
        sets: Array.from({ length: n }, () => ({ kg: 0, reps: def.repMax + 2, done: false })),
      };
    }
    const kg = r25(topKg + def.increment);
    return {
      kind: "increase",
      text: `Steigern: ${fmtKg(kg)} kg (+${fmtKg(def.increment)}) × ${def.repMin}+ Wdh.`,
      sets: Array.from({ length: n }, () => ({ kg, reps: def.repMin, done: false })),
    };
  }

  const allBelow = top.every((s) => s.reps < def.repMin);
  const sets = Array.from({ length: n }, (_, i) => {
    const prev = top[i] ?? top[top.length - 1];
    return { kg: topKg, reps: Math.min(def.repMax, Math.max(def.repMin, prev.reps + 1)), done: false };
  });
  if (allBelow) {
    return { kind: "hold", text: `Gewicht halten (${fmtKg(topKg)} kg) und auf ${def.repMin} Wdh. pro Satz hinarbeiten.`, sets };
  }
  return { kind: "reps", text: `Gleiches Gewicht (${fmtKg(topKg)} kg), je Satz +1 Wdh. – Ziel ${sets.map((s) => s.reps).join("/")}.`, sets };
}

export function fmtKg(n: number): string {
  return n.toLocaleString("de-DE", { maximumFractionDigits: 2 });
}

export function formatSets(sets: WorkoutSet[]): string {
  if (!sets.length) return "–";
  const sameKg = sets.every((s) => s.kg === sets[0].kg);
  if (sameKg) return `${fmtKg(sets[0].kg)} kg × ${sets.map((s) => s.reps).join(" · ")}`;
  return sets.map((s) => `${fmtKg(s.kg)}×${s.reps}`).join(", ");
}

export function workoutVolume(w: Workout): number {
  return w.exercises.reduce((s, e) => s + e.sets.filter((x) => x.done !== false).reduce((a, x) => a + x.kg * x.reps, 0), 0);
}

/** Geschätztes 1RM (Epley) – für den Fortschrittsgraphen */
export function e1rm(s: WorkoutSet): number {
  return s.reps <= 1 ? s.kg : s.kg * (1 + s.reps / 30);
}
