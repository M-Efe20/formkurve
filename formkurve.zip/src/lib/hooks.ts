"use client";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect, useMemo, useState } from "react";
import { db, type Settings, type DayLog } from "./db";
import { computeTargets, defaultSettings, trendWeight, sumNutrients, dailyKcalMap, computeStreak, type Targets } from "./calc";
import { todayStr, addDays } from "./dates";

export function useSettings(): Settings | undefined {
  return useLiveQuery(async () => {
    const s = await db.settings.get("main");
    return s ? { ...defaultSettings(), ...s } : undefined;
  });
}

export function useWeights() {
  return useLiveQuery(() => db.weights.orderBy("date").toArray(), [], undefined);
}

export function useDay(date: string): DayLog | undefined {
  return useLiveQuery(async () => (await db.days.get(date)) || { date, waterMl: 0, activities: [] }, [date]);
}

export function useEntries(date: string) {
  return useLiveQuery(() => db.entries.where("date").equals(date).sortBy("createdAt"), [date]);
}

export function useTargets(date: string): { targets?: Targets; settings?: Settings } {
  const settings = useSettings();
  const weights = useWeights();
  const day = useDay(date);
  const targets = useMemo(() => {
    if (!settings || !weights || !day) return undefined;
    const tw = trendWeight(weights, date, settings.startWeightKg);
    return computeTargets(settings, tw, date, day.activities);
  }, [settings, weights, day, date]);
  return { targets, settings };
}

export function useDayTotals(date: string) {
  const entries = useEntries(date);
  return useMemo(() => (entries ? sumNutrients(entries) : undefined), [entries]);
}

/** Streak über die letzten 400 Tage */
export function useStreak(settings?: Settings) {
  const today = todayStr();
  const data = useLiveQuery(async () => {
    const from = addDays(today, -400);
    const [entries, weights, days] = await Promise.all([
      db.entries.where("date").between(from, today, true, true).toArray(),
      db.weights.toArray(),
      db.days.where("date").between(from, today, true, true).toArray(),
    ]);
    return { entries, weights, days };
  }, [today]);
  return useMemo(() => {
    if (!data || !settings) return undefined;
    const kcal = dailyKcalMap(data.entries);
    const acts = new Map(data.days.map((d) => [d.date, d.activities]));
    const tw = trendWeight(data.weights, today, settings.startWeightKg);
    return computeStreak(kcal, (d) => computeTargets(settings, tw, d, acts.get(d) || []).budget, settings.minKcal, today);
  }, [data, settings, today]);
}

/** Aktualisiert sich jede Minute (für tageszeitabhängige Anzeigen und Datumswechsel) */
export function useNow(intervalMs = 60000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), intervalMs);
    const onVis = () => document.visibilityState === "visible" && setNow(new Date());
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [intervalMs]);
  return now;
}
