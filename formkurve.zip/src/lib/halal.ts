import type { HalalStatus } from "./db";

export interface HalalCheck {
  status: HalalStatus;
  reasons: string[];
}

const PORK = [
  /schwein/i,
  /\bspeck\b/i,
  /schmalz/i,
  /\bpork\b/i,
  /\bporc\b/i,
  /\blard\b/i,
  /\bbacon\b/i,
  /\bham\b/i,
];
const ALCOHOL = [
  /(?<![a-zäöüß])alkohol/i,
  /(?<![a-zäöüß])ethanol/i,
  /\balcohol\b/i,
  /\bwein\b/i,
  /weinbrand/i,
  /\brum\b/i,
  /likör/i,
  /\bbier\b/i,
  /wodka|vodka/i,
  /whisk(e)?y/i,
  /\bsekt\b/i,
  /cognac|brandy|amaretto/i,
];
const GELATIN = [/gelatine?/i, /\be\s?441\b/i];
const UNCLEAR = [
  { re: /\be\s?47[0-9]\b/i, note: "Emulgator E47x (kann tierisch sein)" },
  { re: /\be\s?542\b/i, note: "E542 (Knochenphosphat)" },
  { re: /\be\s?120\b|karmin|cochenille/i, note: "Karmin/E120" },
  { re: /\bl-?cystein|e\s?920\b/i, note: "L-Cystein/E920" },
  { re: /\blab\b|tierisches lab/i, note: "Lab (Herkunft prüfen)" },
];

export function checkHalal(input: { ingredients?: string; labels?: string[]; name?: string; categories?: string[] }): HalalCheck {
  const labels = (input.labels || []).map((l) => l.toLowerCase());
  const certified = labels.some((l) => l.includes("halal"));
  const text = `${input.name || ""} \n ${input.ingredients || ""}`;
  const cats = (input.categories || []).join(" ").toLowerCase();
  const reasons: string[] = [];

  if (PORK.some((r) => r.test(text)) || /\bpork\b|en:pork/.test(cats)) reasons.push("Schwein");
  if (ALCOHOL.some((r) => r.test(text)) || /alcoholic-beverages|en:wines|en:beers/.test(cats)) reasons.push("Alkohol");
  if (GELATIN.some((r) => r.test(text))) {
    const safeGel = /(rind|fisch|halal|bovine|beef|fish)[^.;,]{0,20}gelatine|gelatine[^.;,]{0,20}(rind|fisch|halal|bovine|beef|fish)/i.test(text);
    if (!safeGel) reasons.push("Gelatine (Herkunft unklar)");
  }

  if (reasons.length) {
    // Halal-Siegel überstimmt nur die unklare Gelatine
    if (certified && reasons.every((r) => r.startsWith("Gelatine"))) return { status: "certified", reasons: [] };
    return { status: "warning", reasons };
  }
  if (certified) return { status: "certified", reasons: [] };

  const unclear = UNCLEAR.filter((u) => u.re.test(text)).map((u) => u.note);
  if (unclear.length) return { status: "caution", reasons: unclear };
  return { status: "unknown", reasons: [] };
}
