import type { Settings, WeightLog, Entry, ActivityDef } from "./db";
import { addDays, daysBetween, weekday, rangeDates } from "./dates";

export const KCAL_PER_KG_FAT = 7700;

export const DEFAULT_ACTIVITIES: ActivityDef[] = [
  { key: "gym", label: "Gym (Ganzkörper)", minutes: 45, met: 5 },
  { key: "volleyball", label: "Volleyball", minutes: 90, met: 4 },
  { key: "boxing", label: "Boxen", minutes: 60, met: 7 },
];

export const DEFAULT_SCHEDULE: Record<number, string[]> = {
  0: [],
  1: ["gym"],
  2: ["volleyball"],
  3: ["gym"],
  4: ["boxing"],
  5: [],
  6: ["gym"],
};

export const NEAT_LEVELS = [
  { value: 1.2, label: "Überwiegend sitzend" },
  { value: 1.35, label: "Leicht aktiv (viel stehen/gehen)" },
  { value: 1.5, label: "Körperlich aktiv (Job auf den Beinen)" },
];

export const MANUAL_FACTORS = [
  { value: 1.2, label: "1,2 – kaum aktiv" },
  { value: 1.375, label: "1,375 – leicht aktiv (1–3x Sport)" },
  { value: 1.55, label: "1,55 – moderat aktiv (3–5x Sport)" },
  { value: 1.725, label: "1,725 – sehr aktiv (6–7x Sport)" },
];

export function defaultSettings(): Settings {
  return {
    id: "main",
    onboarded: false,
    sex: "m",
    age: 25,
    heightCm: 175,
    startWeightKg: 80,
    goalWeightKg: 72,
    startDate: "",
    activityMode: "auto",
    neatFactor: 1.35,
    manualFactor: 1.55,
    deficit: 700,
    trainingBonus: 150,
    minKcal: 1800,
    proteinPerKg: 2,
    fatPerKg: 0.8,
    waterGoalMl: 3000,
    stepGoalMin: 8000,
    stepGoal: 10000,
    schedule: { ...DEFAULT_SCHEDULE },
    activities: DEFAULT_ACTIVITIES.map((a) => ({ ...a })),
    adaptive: true,
    aiModel: "claude-sonnet-5-5",
    autoCoach: true,
    theme: "system",
  };
}

/** Grundumsatz nach Mifflin-St Jeor */
export function bmr(sex: "m" | "f", kg: number, cm: number, age: number): number {
  return 10 * kg + 6.25 * cm - 5 * age + (sex === "m" ? 5 : -161);
}

/** Wöchentliche Sport-kcal (Netto, d. h. ohne den ohnehin enthaltenen Grundumsatz) */
export function weeklySportKcal(s: Pick<Settings, "schedule" | "activities">, kg: number): number {
  let total = 0;
  for (let wd = 0; wd < 7; wd++) {
    for (const key of s.schedule[wd] || []) {
      const a = s.activities.find((x) => x.key === key);
      if (!a) continue;
      total += Math.max(0, a.met - 1) * kg * (a.minutes / 60);
    }
  }
  return total;
}

export function trainingDayCount(schedule: Record<number, string[]>): number {
  let n = 0;
  for (let wd = 0; wd < 7; wd++) if ((schedule[wd] || []).length > 0) n++;
  return n;
}

export interface Targets {
  weightUsed: number;
  bmr: number;
  factor: number;
  tdeeFormula: number;
  tdee: number;
  tdeeSource: "formel" | "adaptiv";
  avgBudget: number;
  budget: number;
  rawBudget: number;
  clampedToFloor: boolean;
  isTraining: boolean;
  plannedActivities: string[];
  trainingOffset: number;
  restOffset: number;
  trainingDays: number;
  protein: number;
  fat: number;
  carbs: number;
}

export function activityFactor(s: Settings, kg: number, bmrValue: number): number {
  if (s.activityMode === "manual") return s.manualFactor;
  const sportPerDay = weeklySportKcal(s, kg) / 7;
  return s.neatFactor + sportPerDay / bmrValue;
}

export function round10(n: number) {
  return Math.round(n / 10) * 10;
}

/**
 * Tagesbudget: Ø-Budget = TDEE − Defizit. Trainings- und Ruhetage liegen
 * 2 × Bonus (Standard 300 kcal) auseinander, so verschoben, dass die
 * Wochensumme exakt 7 × Ø-Budget bleibt.
 */
export function computeTargets(s: Settings, trendWeight: number, date: string, dayActivities: string[] = []): Targets {
  const kg = trendWeight || s.startWeightKg;
  const b = bmr(s.sex, kg, s.heightCm, s.age);
  const factor = activityFactor(s, kg, b);
  const tdeeFormula = b * factor;
  const useAdaptive = s.adaptive && !!s.adaptiveTdee;
  const tdee = useAdaptive ? s.adaptiveTdee! : tdeeFormula;
  const avg = tdee - s.deficit;

  const nT = trainingDayCount(s.schedule);
  const nR = 7 - nT;
  const bonus = s.trainingBonus;
  const c = (bonus * (nT - nR)) / 7;
  const trainingOffset = nT === 0 ? 0 : bonus - c;
  const restOffset = nR === 0 ? 0 : -bonus - c;

  const planned = s.schedule[weekday(date)] || [];
  const isTraining = planned.length > 0 || dayActivities.length > 0;
  const raw = avg + (isTraining ? trainingOffset : restOffset);
  const clamped = raw < s.minKcal;
  const budget = round10(Math.max(s.minKcal, raw));

  const protein = Math.round(s.proteinPerKg * s.goalWeightKg);
  const fat = Math.round(s.fatPerKg * s.goalWeightKg);
  const carbs = Math.max(0, Math.round((budget - protein * 4 - fat * 9) / 4));

  return {
    weightUsed: kg,
    bmr: Math.round(b),
    factor,
    tdeeFormula: Math.round(tdeeFormula),
    tdee: Math.round(tdee),
    tdeeSource: useAdaptive ? "adaptiv" : "formel",
    avgBudget: Math.round(avg),
    budget,
    rawBudget: Math.round(raw),
    clampedToFloor: clamped,
    isTraining,
    plannedActivities: planned,
    trainingOffset: Math.round(trainingOffset),
    restOffset: Math.round(restOffset),
    trainingDays: nT,
    protein,
    fat,
    carbs,
  };
}

// ---------- Gewicht ----------

export function sortWeights(w: WeightLog[]): WeightLog[] {
  return [...w].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

/** 7-Tage-Durchschnitt (alle Einträge im Fenster [date-6, date]) */
export function avg7(weights: WeightLog[], date: string): number | null {
  const from = addDays(date, -6);
  const inWin = weights.filter((w) => w.date >= from && w.date <= date);
  if (!inWin.length) return null;
  return inWin.reduce((s, w) => s + w.kg, 0) / inWin.length;
}

export function trendWeight(weights: WeightLog[], date: string, fallback: number): number {
  const a = avg7(weights, date);
  if (a != null) return a;
  const before = sortWeights(weights).filter((w) => w.date <= date);
  if (before.length) return before[before.length - 1].kg;
  return fallback;
}

export interface WeeklyChange {
  current: number;
  previous: number;
  diffKg: number;
  pct: number;
  tooFast: boolean;
}

/** Veränderung des 7-Tage-Schnitts gegenüber der Vorwoche */
export function weeklyChange(weights: WeightLog[], date: string, maxPct = 1): WeeklyChange | null {
  const cur = avg7(weights, date);
  const prev = avg7(weights, addDays(date, -7));
  if (cur == null || prev == null) return null;
  const diff = cur - prev;
  const pct = (diff / prev) * 100;
  return { current: cur, previous: prev, diffKg: diff, pct, tooFast: pct < -maxPct };
}

export function weightSeries(weights: WeightLog[]): { date: string; kg: number; avg: number }[] {
  const sorted = sortWeights(weights);
  return sorted.map((w) => ({ date: w.date, kg: w.kg, avg: avg7(sorted, w.date)! }));
}

export function linearSlope(points: { x: number; y: number }[]): number {
  const n = points.length;
  if (n < 2) return 0;
  const mx = points.reduce((s, p) => s + p.x, 0) / n;
  const my = points.reduce((s, p) => s + p.y, 0) / n;
  let num = 0;
  let den = 0;
  for (const p of points) {
    num += (p.x - mx) * (p.y - my);
    den += (p.x - mx) ** 2;
  }
  return den === 0 ? 0 : num / den;
}

// ---------- Adaptiver TDEE ----------

export interface AdaptiveResult {
  ready: boolean;
  reason?: string;
  daysTracked: number;
  tdee?: number;
  avgIntake?: number;
  kgPerWeek?: number;
  loggedDays?: number;
  weighIns?: number;
}

export const ADAPTIVE_MIN_DAYS = 21;
export const MIN_LOGGED_KCAL = 1000;

export function dailyKcalMap(entries: Pick<Entry, "date" | "kcal">[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const e of entries) m.set(e.date, (m.get(e.date) || 0) + e.kcal);
  return m;
}

/**
 * Echter Verbrauch = Ø Kalorienaufnahme − (Gewichtstrend kg/Tag × 7700).
 * Nutzt die letzten 28 Tage (mind. 21 Tage seit Start, 14 vollständig
 * erfasste Tage, 8 Wiegungen). Das Ergebnis wird auf ±25 % der Formel begrenzt.
 */
export function computeAdaptive(
  kcalByDate: Map<string, number>,
  weights: WeightLog[],
  today: string,
  startDate: string,
  formulaTdee: number,
): AdaptiveResult {
  const daysTracked = startDate ? daysBetween(startDate, today) : 0;
  if (daysTracked < ADAPTIVE_MIN_DAYS) {
    return { ready: false, daysTracked, reason: `Noch ${ADAPTIVE_MIN_DAYS - daysTracked} Tage sammeln` };
  }
  const from = addDays(today, -27);
  const end = addDays(today, -1); // heute ist noch nicht vollständig
  const days = rangeDates(from > startDate ? from : startDate, end);
  const logged = days.filter((d) => (kcalByDate.get(d) || 0) >= MIN_LOGGED_KCAL);
  const ws = sortWeights(weights).filter((w) => w.date >= days[0] && w.date <= today);
  if (logged.length < 14) {
    return { ready: false, daysTracked, loggedDays: logged.length, weighIns: ws.length, reason: `Erst ${logged.length} von 14 vollständig erfassten Tagen` };
  }
  if (ws.length < 8) {
    return { ready: false, daysTracked, loggedDays: logged.length, weighIns: ws.length, reason: `Erst ${ws.length} von 8 Wiegungen` };
  }
  const avgIntake = logged.reduce((s, d) => s + (kcalByDate.get(d) || 0), 0) / logged.length;
  const slope = linearSlope(ws.map((w) => ({ x: daysBetween(days[0], w.date), y: w.kg })));
  let tdee = avgIntake - slope * KCAL_PER_KG_FAT;
  tdee = Math.min(formulaTdee * 1.25, Math.max(formulaTdee * 0.75, tdee));
  return {
    ready: true,
    daysTracked,
    tdee: Math.round(tdee),
    avgIntake: Math.round(avgIntake),
    kgPerWeek: slope * 7,
    loggedDays: logged.length,
    weighIns: ws.length,
  };
}

// ---------- Tagesziel / Streak ----------

export function dayInGoal(kcal: number, budget: number, minKcal: number): boolean {
  return kcal >= minKcal && kcal <= budget * 1.05;
}

/**
 * Tage in Folge im Ziel: zusammenhängende Kette bis gestern
 * plus heute, falls heute (bisher) im Ziel.
 */
export function computeStreak(
  kcalByDate: Map<string, number>,
  budgetFor: (date: string) => number,
  minKcal: number,
  today: string,
): { streak: number; todayCounts: boolean } {
  let streak = 0;
  let d = addDays(today, -1);
  for (let i = 0; i < 3650; i++) {
    const k = kcalByDate.get(d) || 0;
    if (!dayInGoal(k, budgetFor(d), minKcal)) break;
    streak++;
    d = addDays(d, -1);
  }
  const t = kcalByDate.get(today) || 0;
  const todayCounts = dayInGoal(t, budgetFor(today), minKcal);
  return { streak: streak + (todayCounts ? 1 : 0), todayCounts };
}

// ---------- Portionen ----------

export function gramsFor(amount: number, unit: string, units: { label: string; grams: number }[]): number {
  if (unit === "g" || unit === "ml") return amount;
  const u = units.find((x) => x.label === unit);
  return u ? amount * u.grams : amount;
}

export function nutrientsFor(food: { kcal: number; protein: number; carbs: number; fat: number }, grams: number) {
  const f = grams / 100;
  return {
    kcal: Math.round(food.kcal * f),
    protein: Math.round(food.protein * f * 10) / 10,
    carbs: Math.round(food.carbs * f * 10) / 10,
    fat: Math.round(food.fat * f * 10) / 10,
  };
}

export function sumNutrients<T extends { kcal: number; protein: number; carbs: number; fat: number }>(rows: T[]) {
  return rows.reduce(
    (s, r) => ({ kcal: s.kcal + r.kcal, protein: s.protein + r.protein, carbs: s.carbs + r.carbs, fat: s.fat + r.fat }),
    { kcal: 0, protein: 0, carbs: 0, fat: 0 },
  );
}

export function parseNum(v: string | number | undefined | null): number {
  if (v == null) return NaN;
  if (typeof v === "number") return v;
  return parseFloat(v.replace(",", ".").trim());
}

export function fmt(n: number, digits = 0, minDigits = 0): string {
  return n.toLocaleString("de-DE", { maximumFractionDigits: digits, minimumFractionDigits: Math.min(minDigits, digits) });
}
