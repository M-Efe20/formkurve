const pad = (n: number) => String(n).padStart(2, "0");

export function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function todayStr(): string {
  return toDateStr(new Date());
}

export function parseDate(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d, 12, 0, 0);
}

export function addDays(s: string, n: number): string {
  const d = parseDate(s);
  d.setDate(d.getDate() + n);
  return toDateStr(d);
}

export function daysBetween(a: string, b: string): number {
  return Math.round((parseDate(b).getTime() - parseDate(a).getTime()) / 86400000);
}

/** 0 = Sonntag … 6 = Samstag */
export function weekday(s: string): number {
  return parseDate(s).getDay();
}

export const WEEKDAYS_SHORT = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
export const WEEKDAYS_LONG = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
/** Anzeige-Reihenfolge Mo–So */
export const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0];

export function formatDate(s: string, opts: Intl.DateTimeFormatOptions = { weekday: "short", day: "numeric", month: "short" }): string {
  return parseDate(s).toLocaleDateString("de-DE", opts);
}

export function relativeDayLabel(s: string): string {
  const diff = daysBetween(todayStr(), s);
  if (diff === 0) return "Heute";
  if (diff === -1) return "Gestern";
  if (diff === 1) return "Morgen";
  return formatDate(s);
}

/** Montag der Woche (ISO-Woche) */
export function weekStart(s: string): string {
  const wd = weekday(s);
  const delta = wd === 0 ? -6 : 1 - wd;
  return addDays(s, delta);
}

export function rangeDates(from: string, to: string): string[] {
  const out: string[] = [];
  let cur = from;
  while (cur <= to) {
    out.push(cur);
    cur = addDays(cur, 1);
  }
  return out;
}
