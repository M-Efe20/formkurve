import { db, MEALS, type CoachSuggestion, type Entry, type Settings, type WeeklyReview } from "./db";
import { callClaude, extractJson, type ContentBlock } from "./ai";
import { PROTEIN_SNACKS } from "./basics";
import { avg7, computeTargets, dailyKcalMap, dayInGoal, fmt, sumNutrients, trendWeight, weeklyChange } from "./calc";
import { addDays, rangeDates, weekStart, WEEKDAYS_LONG, weekday } from "./dates";

const SYSTEM = `Du bist "Formkurve", ein freundlicher, kompetenter Ernährungs- und Fitnesscoach.
Ziel des Nutzers: Fett verlieren, Muskeln erhalten bzw. aufbauen.
Feste Regeln:
- Alles strikt halal: kein Schwein (auch kein Speck, Schinken, Schmalz), kein Alkohol (auch nicht zum Kochen), keine Schweinegelatine. Fleisch nur halal (z. B. Hähnchen/Pute/Rind mit Halal-Siegel); Käse bevorzugt mit mikrobiellem Lab.
- Vorschläge eiweißreich, günstig und mit Zutaten aus normalen deutschen Supermärkten (Aldi, Lidl, Rewe), wenig Aufwand.
- Konkrete Mengen in Gramm oder Stück, realistische Nährwerte.
- Sprache: Deutsch, Du-Form, kurz, motivierend, ehrlich, keine Floskeln, keine Emojis.`;

function profile(s: Settings, weight: number) {
  return `Profil: ${s.sex === "m" ? "männlich" : "weiblich"}, ${s.age} Jahre, ${s.heightCm} cm, aktuell ca. ${fmt(weight, 1)} kg (7-Tage-Schnitt), Ziel ${s.goalWeightKg} kg.`;
}

function mealsText(entries: Entry[]) {
  if (!entries.length) return "Noch nichts eingetragen.";
  return MEALS.map((m) => {
    const list = entries.filter((e) => e.meal === m.key);
    if (!list.length) return null;
    return `${m.label}: ${list.map((e) => `${e.name} (${fmt(e.amount, 1)} ${e.unit}, ${fmt(e.kcal)} kcal, ${fmt(e.protein)} g P)`).join("; ")}`;
  })
    .filter(Boolean)
    .join("\n");
}

export interface DayContext {
  settings: Settings;
  date: string;
  entries: Entry[];
  weight: number;
  budget: number;
  protein: number;
  carbs: number;
  fat: number;
  isTraining: boolean;
  activitiesDone: string[];
  favorites: string[];
}

export async function loadDayContext(settings: Settings, date: string): Promise<DayContext> {
  const [entries, weights, day, favs] = await Promise.all([
    db.entries.where("date").equals(date).sortBy("createdAt"),
    db.weights.toArray(),
    db.days.get(date),
    db.foods.where("favorite").equals(1).limit(15).toArray(),
  ]);
  const tw = trendWeight(weights, date, settings.startWeightKg);
  const t = computeTargets(settings, tw, date, day?.activities || []);
  return {
    settings,
    date,
    entries,
    weight: tw,
    budget: t.budget,
    protein: t.protein,
    carbs: t.carbs,
    fat: t.fat,
    isTraining: t.isTraining,
    activitiesDone: day?.activities || [],
    favorites: favs.map((f) => f.name),
  };
}

function remainingOf(ctx: DayContext) {
  const tot = sumNutrients(ctx.entries);
  return {
    tot,
    kcal: Math.round(ctx.budget - tot.kcal),
    protein: Math.round(ctx.protein - tot.protein),
    carbs: Math.round(ctx.carbs - tot.carbs),
    fat: Math.round(ctx.fat - tot.fat),
  };
}

// ---------- Abendvorschlag ----------

export async function aiEveningSuggestion(ctx: DayContext, signal?: AbortSignal): Promise<CoachSuggestion> {
  const r = remainingOf(ctx);
  const prompt = `${profile(ctx.settings, ctx.weight)}
Heute (${WEEKDAYS_LONG[weekday(ctx.date)]}) ist ein ${ctx.isTraining ? "Trainingstag" : "Ruhetag"}.
Tagesbudget: ${ctx.budget} kcal, Ziel Eiweiß ${ctx.protein} g, Kohlenhydrate ${ctx.carbs} g, Fett min. ${ctx.fat} g.
Bisher gegessen: ${fmt(r.tot.kcal)} kcal, ${fmt(r.tot.protein)} g Eiweiß, ${fmt(r.tot.carbs)} g KH, ${fmt(r.tot.fat)} g Fett.
${mealsText(ctx.entries)}
Noch übrig: ${r.kcal} kcal, ${r.protein} g Eiweiß, ${r.carbs} g KH, ${r.fat} g Fett.
${ctx.favorites.length ? `Lieblingslebensmittel: ${ctx.favorites.join(", ")}.` : ""}

Aufgabe: Schlage 3 konkrete Optionen vor (halal, eiweißreich, günstig, Zutaten von Aldi/Lidl/Rewe), was ich heute Abend noch essen kann, um das restliche Budget möglichst gut zu nutzen und vor allem das Eiweißziel zu erreichen, ohne die übrigen Kalorien zu überschreiten (max. +50 kcal).
- Wenn weniger als 150 kcal übrig sind: nur sehr leichte Optionen (z. B. Gemüse, Tee) und sag ehrlich, dass das Budget fast erreicht ist.
- Wenn das Budget überschritten ist: keine Essensvorschläge, sondern im "tip" ein kurzer Hinweis für morgen; "options" leer lassen.
- Wenn ich unter 1.800 kcal gegessen habe und noch viel übrig ist, ermutige mich, genug zu essen.

Antworte NUR mit JSON in genau diesem Format:
{"intro":"1 kurzer Satz","options":[{"title":"Name des Gerichts","items":[{"name":"Zutat","amount":"250 g"}],"kcal":0,"protein":0,"carbs":0,"fat":0,"prep":"1 Satz Zubereitung","cost":"ca. 1,50 €"}],"tip":"1 kurzer Tipp"}`;
  const text = await callClaude(ctx.settings, { system: SYSTEM, content: prompt, maxTokens: 1400, signal });
  const j = extractJson<Omit<CoachSuggestion, "source">>(text);
  return {
    intro: j.intro,
    tip: j.tip,
    options: (j.options || []).slice(0, 3).map((o) => ({
      ...o,
      items: (o.items || []).map((i) => ({ name: String(i.name), amount: String(i.amount) })),
      kcal: Math.round(Number(o.kcal) || 0),
      protein: Math.round(Number(o.protein) || 0),
      carbs: o.carbs != null ? Math.round(Number(o.carbs)) : undefined,
      fat: o.fat != null ? Math.round(Number(o.fat)) : undefined,
    })),
    source: "ai",
  };
}

/** Regelbasierter Vorschlag ohne KI: füllt das Eiweißziel mit günstigen Basics */
export function basicSuggestion(ctx: DayContext): CoachSuggestion {
  const r = remainingOf(ctx);
  if (r.kcal < 0) return { intro: `Du bist ${fmt(-r.kcal)} kcal über dem Budget.`, options: [], tip: "Kein Stress – morgen einfach normal weitermachen, nicht kompensieren.", source: "basic" };
  if (r.kcal < 150) return { intro: "Dein Budget ist fast erreicht.", options: [], tip: "Wenn du noch Hunger hast: Gurke, Paprika oder ein Tee.", source: "basic" };
  const options: CoachSuggestion["options"] = [];
  const proteinGoal = Math.max(20, r.protein);
  for (const s of PROTEIN_SNACKS) {
    // Menge so, dass Eiweißziel erreicht wird, aber kcal-Rest nicht überschritten
    const perUnitKcal = (s.kcal * s.unitGrams) / 100;
    const perUnitP = (s.protein * s.unitGrams) / 100;
    let units = Math.min(s.maxUnits, Math.ceil(proteinGoal / perUnitP), Math.floor(r.kcal / perUnitKcal));
    if (s.unit === "g") units = Math.floor(units / 25) * 25;
    if (units <= 0 || (s.unit === "g" && units < 100)) continue;
    const g = units * s.unitGrams;
    options.push({
      title: s.name,
      items: [{ name: s.name, amount: s.unit === "g" ? `${units} g` : `${units} ${s.unit}` }],
      kcal: Math.round((s.kcal * g) / 100),
      protein: Math.round((s.protein * g) / 100),
      carbs: Math.round((s.carbs * g) / 100),
      fat: Math.round((s.fat * g) / 100),
      cost: s.cost,
    });
  }
  options.sort((a, b) => b.protein / Math.max(1, b.kcal) - a.protein / Math.max(1, a.kcal));
  return {
    intro: `Noch ${fmt(r.kcal)} kcal und ${fmt(Math.max(0, r.protein))} g Eiweiß offen.`,
    options: options.slice(0, 3),
    tip: r.protein > 40 ? "Eiweiß zuerst – Magerquark oder Skyr mit etwas Obst ist schnell und günstig." : "Den Rest gern mit Gemüse oder Obst auffüllen.",
    source: "basic",
  };
}

// ---------- Tagesfeedback ----------

export async function aiDailyFeedback(ctx: DayContext, signal?: AbortSignal): Promise<string> {
  const r = remainingOf(ctx);
  const prompt = `${profile(ctx.settings, ctx.weight)}
Heute: ${ctx.isTraining ? "Trainingstag" : "Ruhetag"}${ctx.activitiesDone.length ? ` (erledigt: ${ctx.activitiesDone.join(", ")})` : ""}.
Budget ${ctx.budget} kcal, gegessen ${fmt(r.tot.kcal)} kcal. Eiweiß ${fmt(r.tot.protein)}/${ctx.protein} g, KH ${fmt(r.tot.carbs)}/${ctx.carbs} g, Fett ${fmt(r.tot.fat)}/min. ${ctx.fat} g.
${mealsText(ctx.entries)}

Gib mir nach dem Abendessen EIN kurzes, konkretes Feedback zu meinem Tag (maximal 2 Sätze, höchstens 35 Wörter). Kein JSON, keine Anrede, keine Emojis.`;
  const text = await callClaude(ctx.settings, { system: SYSTEM, content: prompt, maxTokens: 200, signal });
  return text.replace(/^["„]|["“]$/g, "").trim();
}

// ---------- Foto-Schätzung ----------

export interface PhotoItem {
  name: string;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface PhotoEstimate {
  items: PhotoItem[];
  confidence?: string;
  hinweis?: string;
}

export async function aiEstimatePhoto(settings: Settings, base64Jpeg: string, note: string, signal?: AbortSignal): Promise<PhotoEstimate> {
  const content: ContentBlock[] = [
    { type: "image", source: { type: "base64", media_type: "image/jpeg", data: base64Jpeg } },
    {
      type: "text",
      text: `Schätze Kalorien und Makros dieser Mahlzeit. Zerlege sie in erkennbare Komponenten mit geschätztem Gewicht in Gramm (inkl. Öl/Soße, falls sichtbar). Nährwerte jeweils für die geschätzte Menge.
${note ? `Zusatzinfo vom Nutzer: ${note}\n` : ""}Wenn etwas möglicherweise nicht halal ist (z. B. Schweinefleisch, Wurst unklarer Herkunft, Alkohol), weise im Feld "hinweis" darauf hin.
Antworte NUR mit JSON:
{"items":[{"name":"Komponente","grams":0,"kcal":0,"protein":0,"carbs":0,"fat":0}],"confidence":"niedrig|mittel|hoch","hinweis":"kurzer Hinweis oder leer"}`,
    },
  ];
  const text = await callClaude(settings, { system: SYSTEM, content, maxTokens: 1200, signal });
  const j = extractJson<PhotoEstimate>(text);
  return {
    confidence: j.confidence,
    hinweis: j.hinweis,
    items: (j.items || []).map((i) => ({
      name: String(i.name || "Komponente"),
      grams: Math.max(1, Math.round(Number(i.grams) || 100)),
      kcal: Math.round(Number(i.kcal) || 0),
      protein: Math.round((Number(i.protein) || 0) * 10) / 10,
      carbs: Math.round((Number(i.carbs) || 0) * 10) / 10,
      fat: Math.round((Number(i.fat) || 0) * 10) / 10,
    })),
  };
}

// ---------- Wochenrückblick ----------

export interface WeekStats {
  from: string;
  to: string;
  daysLogged: number;
  avgKcal: number;
  avgBudget: number;
  daysInGoal: number;
  avgProtein: number;
  proteinTarget: number;
  daysProteinHit: number;
  weightAvg: number | null;
  weightChangeKg: number | null;
  weightChangePct: number | null;
  gymSessions: number;
  activities: Record<string, number>;
  avgWaterL: number;
  avgSteps: number | null;
  lowDays: number;
}

export async function computeWeekStats(settings: Settings, anyDayInWeek: string): Promise<WeekStats> {
  const from = weekStart(anyDayInWeek);
  const to = addDays(from, 6);
  const dates = rangeDates(from, to);
  const [entries, weights, days, workouts] = await Promise.all([
    db.entries.where("date").between(from, to, true, true).toArray(),
    db.weights.toArray(),
    db.days.where("date").between(from, to, true, true).toArray(),
    db.workouts.where("date").between(from, to, true, true).toArray(),
  ]);
  const kcal = dailyKcalMap(entries);
  const tw = trendWeight(weights, to, settings.startWeightKg);
  const logged = dates.filter((d) => (kcal.get(d) || 0) > 0);
  let budgetSum = 0;
  let inGoal = 0;
  let pHit = 0;
  let low = 0;
  const t0 = computeTargets(settings, tw, from);
  for (const d of logged) {
    const day = days.find((x) => x.date === d);
    const t = computeTargets(settings, tw, d, day?.activities || []);
    budgetSum += t.budget;
    const k = kcal.get(d) || 0;
    if (dayInGoal(k, t.budget, settings.minKcal)) inGoal++;
    if (k < settings.minKcal) low++;
    const p = entries.filter((e) => e.date === d).reduce((s, e) => s + e.protein, 0);
    if (p >= t.protein * 0.9) pHit++;
  }
  const proteinTotal = entries.reduce((s, e) => s + e.protein, 0);
  const acts: Record<string, number> = {};
  for (const d of days) for (const a of d.activities) acts[a] = (acts[a] || 0) + 1;
  const gymDays = new Set([...workouts.filter((w) => w.exercises.some((e) => e.sets.some((x) => x.done))).map((w) => w.date), ...days.filter((d) => d.activities.includes("gym")).map((d) => d.date)]);
  const wc = weeklyChange(weights, to);
  const stepsDays = days.filter((d) => d.steps != null);
  return {
    from,
    to,
    daysLogged: logged.length,
    avgKcal: logged.length ? Math.round(logged.reduce((s, d) => s + (kcal.get(d) || 0), 0) / logged.length) : 0,
    avgBudget: logged.length ? Math.round(budgetSum / logged.length) : t0.avgBudget,
    daysInGoal: inGoal,
    avgProtein: logged.length ? Math.round(proteinTotal / logged.length) : 0,
    proteinTarget: t0.protein,
    daysProteinHit: pHit,
    weightAvg: avg7(weights, to),
    weightChangeKg: wc ? Math.round(wc.diffKg * 100) / 100 : null,
    weightChangePct: wc ? Math.round(wc.pct * 100) / 100 : null,
    gymSessions: gymDays.size,
    activities: acts,
    avgWaterL: days.length ? Math.round((days.reduce((s, d) => s + d.waterMl, 0) / 7 / 1000) * 10) / 10 : 0,
    avgSteps: stepsDays.length ? Math.round(stepsDays.reduce((s, d) => s + (d.steps || 0), 0) / stepsDays.length) : null,
    lowDays: low,
  };
}

export async function aiWeeklyReview(settings: Settings, st: WeekStats, signal?: AbortSignal): Promise<WeeklyReview> {
  const plan = Object.entries(settings.schedule)
    .flatMap(([, keys]) => keys)
    .reduce<Record<string, number>>((acc, k) => ((acc[k] = (acc[k] || 0) + 1), acc), {});
  const prompt = `${profile(settings, st.weightAvg ?? settings.startWeightKg)}
Wochenrückblick ${st.from} bis ${st.to}:
- Tage mit Ernährungstagebuch: ${st.daysLogged}/7
- Ø gegessen: ${st.avgKcal} kcal (Ø Budget ${st.avgBudget} kcal), Tage im Ziel: ${st.daysInGoal}, Tage unter ${settings.minKcal} kcal: ${st.lowDays}
- Ø Eiweiß: ${st.avgProtein} g (Ziel ${st.proteinTarget} g), Eiweißziel erreicht an ${st.daysProteinHit} Tagen
- Gewicht 7-Tage-Schnitt: ${st.weightAvg != null ? fmt(st.weightAvg, 1) + " kg" : "keine Daten"}, Veränderung zur Vorwoche: ${st.weightChangeKg != null ? `${st.weightChangeKg} kg (${st.weightChangePct} %)` : "keine Daten"}
- Training: Gym ${st.gymSessions}x (Plan ${plan.gym || 0}x), Aktivitäten abgehakt: ${Object.entries(st.activities).map(([k, v]) => `${k} ${v}x`).join(", ") || "keine"} (Plan: ${Object.entries(plan).map(([k, v]) => `${k} ${v}x`).join(", ")})
- Ø Wasser: ${st.avgWaterL} l (Ziel ${settings.waterGoalMl / 1000} l), Ø Schritte: ${st.avgSteps ?? "keine Daten"} (Ziel ${settings.stepGoalMin}–${settings.stepGoal})
Hinweis: Mehr als 1 % Gewichtsverlust pro Woche erhöht das Risiko für Muskelverlust.

Erstelle einen ehrlichen, motivierenden Wochenrückblick. Antworte NUR mit JSON:
{"summary":"1–2 Sätze Fazit","good":["2–3 Punkte, was gut lief"],"improve":["1–3 Punkte, was besser werden kann"],"tips":["1–2 sehr konkrete Tipps für nächste Woche"]}`;
  const text = await callClaude(settings, { system: SYSTEM, content: prompt, maxTokens: 900, signal });
  const j = extractJson<WeeklyReview>(text);
  return {
    summary: String(j.summary || ""),
    good: (j.good || []).map(String).slice(0, 4),
    improve: (j.improve || []).map(String).slice(0, 4),
    tips: (j.tips || []).map(String).slice(0, 2),
    stats: {
      daysLogged: st.daysLogged,
      avgKcal: st.avgKcal,
      avgProtein: st.avgProtein,
      gym: st.gymSessions,
      weightChangeKg: st.weightChangeKg ?? "–",
    },
  };
}

export async function saveWeeklyReview(date: string, review: WeeklyReview) {
  const ws = weekStart(date);
  const existing = await db.notes.where("date").equals(ws).filter((n) => n.type === "weekly").first();
  if (existing?.id) await db.notes.update(existing.id, { data: review, createdAt: Date.now() });
  else await db.notes.add({ type: "weekly", date: ws, data: review, createdAt: Date.now() });
}
