import type { Settings } from "./db";

/** Direkter Zugriff auf die Claude API aus dem Browser (API-Key bleibt lokal auf dem Gerät) */

const API = "https://api.anthropic.com/v1";

export const FALLBACK_MODELS = [
  { id: "claude-sonnet-5-5", name: "Claude Sonnet 5.5 (empfohlen)" },
  { id: "claude-haiku-5-5", name: "Claude Haiku 5.5 (günstig)" },
  { id: "claude-opus-5-5", name: "Claude Opus 5.5" },
];

export class AiError extends Error {
  status?: number;
  constructor(msg: string, status?: number) {
    super(msg);
    this.status = status;
  }
}

function headers(key: string): HeadersInit {
  return {
    "content-type": "application/json",
    "x-api-key": key.trim(),
    "anthropic-version": "2023-06-01",
    "anthropic-dangerous-direct-browser-access": "true",
  };
}

async function toAiError(res: Response): Promise<AiError> {
  let detail = "";
  try {
    const j = await res.json();
    detail = j?.error?.message || "";
  } catch {}
  const map: Record<number, string> = {
    401: "API-Key ungültig – bitte in den Einstellungen prüfen.",
    403: "Keine Berechtigung für dieses Modell/diesen Key.",
    404: "Modell nicht gefunden – bitte in den Einstellungen ein anderes wählen.",
    429: "Zu viele Anfragen oder Limit erreicht – kurz warten.",
    529: "Claude ist gerade überlastet – gleich nochmal versuchen.",
  };
  return new AiError(map[res.status] || `Fehler ${res.status}${detail ? `: ${detail}` : ""}`, res.status);
}

export type ContentBlock =
  | { type: "text"; text: string }
  | { type: "image"; source: { type: "base64"; media_type: string; data: string } };

export async function callClaude(
  s: Pick<Settings, "apiKey" | "aiModel">,
  opts: { system: string; content: string | ContentBlock[]; maxTokens?: number; signal?: AbortSignal },
): Promise<string> {
  if (!s.apiKey) throw new AiError("Kein API-Key hinterlegt. Trage ihn unter Mehr → KI-Coach ein.");
  let res: Response;
  try {
    res = await fetch(`${API}/messages`, {
      method: "POST",
      headers: headers(s.apiKey),
      signal: opts.signal,
      body: JSON.stringify({
        model: s.aiModel || FALLBACK_MODELS[0].id,
        max_tokens: opts.maxTokens ?? 1500,
        system: opts.system,
        messages: [{ role: "user", content: opts.content }],
      }),
    });
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new AiError("Keine Verbindung zur Claude API.");
  }
  if (!res.ok) throw await toAiError(res);
  const data = await res.json();
  const text = (data.content || [])
    .filter((b: { type: string }) => b.type === "text")
    .map((b: { text: string }) => b.text)
    .join("")
    .trim();
  if (!text) throw new AiError("Leere Antwort von Claude.");
  return text;
}

export async function listModels(apiKey: string): Promise<{ id: string; name: string }[]> {
  const res = await fetch(`${API}/models?limit=100`, { headers: headers(apiKey) });
  if (!res.ok) throw await toAiError(res);
  const data = await res.json();
  return (data.data || []).map((m: { id: string; display_name?: string }) => ({ id: m.id, name: m.display_name || m.id }));
}

/** Holt das erste JSON-Objekt aus einer Antwort (auch aus ```json-Blöcken) */
export function extractJson<T>(text: string): T {
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const src = fence ? fence[1] : text;
  const start = src.indexOf("{");
  const end = src.lastIndexOf("}");
  if (start < 0 || end <= start) throw new AiError("Antwort war kein gültiges JSON.");
  try {
    return JSON.parse(src.slice(start, end + 1)) as T;
  } catch {
    throw new AiError("Antwort konnte nicht gelesen werden.");
  }
}
