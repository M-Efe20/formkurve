import type { Food } from "./db";

/** Grundnahrungsmittel (Werte pro 100 g, Durchschnittswerte für den deutschen Handel) – alle halal-geeignet */
type B = [name: string, kcal: number, protein: number, carbs: number, fat: number, units?: [string, number][]];

const LIST: B[] = [
  // Fleisch & Fisch
  ["Hähnchenbrustfilet (roh)", 105, 23.5, 0, 1.2, [["Filet", 150]]],
  ["Putenbrust (roh)", 107, 24, 0, 1, [["Schnitzel", 150]]],
  ["Rinderhack 5 % Fett (roh)", 125, 21, 0, 4.5],
  ["Rinderhack 15–20 % Fett (roh)", 215, 19, 0, 15],
  ["Sucuk (Rind)", 410, 17, 1, 37, [["Scheibe", 8]]],
  ["Putenbrust-Aufschnitt", 100, 21, 1, 1.5, [["Scheibe", 15]]],
  ["Lachsfilet (roh)", 200, 20, 0, 13, [["Filet", 125]]],
  ["Thunfisch im eigenen Saft (abgetropft)", 110, 25, 0, 1, [["Dose (abgetropft)", 140]]],
  ["Seelachsfilet (roh)", 80, 18, 0, 0.9, [["Filet", 125]]],
  // Eier & Milchprodukte
  ["Ei (Gr. M)", 145, 12.5, 0.7, 10, [["Stück", 55]]],
  ["Eiklar", 50, 11, 0.7, 0.2, [["Eiweiß von 1 Ei", 33]]],
  ["Magerquark", 67, 12, 4, 0.3, [["Becher", 500]]],
  ["Skyr natur", 63, 11, 4, 0.2, [["Becher", 450]]],
  ["Hüttenkäse / körniger Frischkäse", 100, 12.6, 2.6, 4.3, [["Becher", 200]]],
  ["Naturjoghurt 1,5 %", 47, 4, 4.3, 1.5, [["Becher", 500]]],
  ["Griechischer Joghurt 10 %", 115, 4, 4, 10],
  ["Milch 1,5 %", 47, 3.4, 4.9, 1.5, [["Glas (250 ml)", 250]]],
  ["Ayran", 36, 1.7, 2.5, 1.8, [["Becher (250 ml)", 250]]],
  ["Mozzarella light", 160, 19, 1, 9, [["Kugel", 125]]],
  ["Feta / Hirtenkäse", 270, 17, 0.5, 22],
  ["Whey Protein (Pulver)", 380, 75, 8, 5, [["Messlöffel", 30]]],
  // Getreide & Beilagen
  ["Haferflocken", 370, 13.5, 59, 7, [["EL", 10]]],
  ["Reis (roh)", 350, 7, 78, 0.6],
  ["Reis (gekocht)", 130, 2.7, 28, 0.3],
  ["Nudeln (roh)", 355, 12.5, 70, 1.5],
  ["Nudeln (gekocht)", 150, 5.5, 30, 0.8],
  ["Vollkornnudeln (roh)", 340, 13, 63, 2.5],
  ["Bulgur (roh)", 350, 12, 70, 1.5],
  ["Couscous (roh)", 355, 12, 72, 1.5],
  ["Kartoffeln (gekocht)", 72, 2, 15, 0.1, [["Stück", 100]]],
  ["Süßkartoffel (roh)", 86, 1.6, 20, 0.1, [["Stück", 250]]],
  ["Vollkornbrot", 200, 6.5, 38, 1.2, [["Scheibe", 50]]],
  ["Toastbrot", 260, 8, 48, 3.5, [["Scheibe", 25]]],
  ["Brötchen (Weizen)", 270, 9, 52, 2, [["Stück", 60]]],
  ["Fladenbrot", 260, 8.5, 51, 1.5, [["Viertel", 100]]],
  ["Tortilla-Wrap", 300, 8.5, 50, 7, [["Stück", 62]]],
  ["Reiswaffeln", 385, 8, 80, 3, [["Stück", 8]]],
  // Hülsenfrüchte & Tofu
  ["Rote Linsen (roh)", 340, 24, 50, 1.5],
  ["Kichererbsen (Dose, abgetropft)", 120, 7, 15, 2.5, [["Dose (abgetropft)", 265]]],
  ["Kidneybohnen (Dose, abgetropft)", 95, 7, 13, 0.5, [["Dose (abgetropft)", 255]]],
  ["Tofu natur", 125, 13, 1.4, 7.5, [["Packung", 200]]],
  ["Hummus", 270, 7, 12, 21, [["EL", 20]]],
  // Obst & Gemüse
  ["Banane", 93, 1.1, 20, 0.2, [["Stück", 120]]],
  ["Apfel", 54, 0.3, 12, 0.2, [["Stück", 150]]],
  ["Beerenmix (TK)", 45, 1, 7, 0.4],
  ["Datteln", 280, 2, 66, 0.4, [["Stück", 8]]],
  ["Avocado", 160, 2, 3.6, 15, [["Stück", 140]]],
  ["Brokkoli", 34, 3.6, 2.7, 0.2],
  ["Tomate", 18, 1, 2.6, 0.2, [["Stück", 100]]],
  ["Gurke", 12, 0.6, 1.8, 0.2, [["Stück", 400]]],
  ["Paprika", 31, 1, 6, 0.3, [["Stück", 150]]],
  ["Zwiebel", 28, 1.2, 5, 0.3, [["Stück", 80]]],
  ["Zucchini", 20, 1.5, 2.5, 0.4, [["Stück", 250]]],
  ["Spinat (TK)", 20, 2.5, 0.6, 0.3],
  ["Gemüsemischung (TK)", 45, 2.5, 6, 0.4],
  // Fette, Nüsse, Sonstiges
  ["Olivenöl", 884, 0, 0, 100, [["EL", 10], ["TL", 4]]],
  ["Butter", 741, 0.7, 0.6, 83, [["TL", 5]]],
  ["Erdnussbutter", 610, 25, 12, 50, [["EL", 15]]],
  ["Mandeln", 600, 21, 6, 52, [["Handvoll", 30]]],
  ["Honig", 310, 0.4, 76, 0, [["TL", 10]]],
  ["Kaffee schwarz", 2, 0.1, 0, 0, [["Tasse", 200]]],
  ["Cola Zero", 0.3, 0, 0, 0, [["Dose (330 ml)", 330]]],
];

export function basicFoods(): Food[] {
  const now = Date.now();
  return LIST.map(([name, kcal, protein, carbs, fat, units]) => ({
    name,
    source: "basic" as const,
    kcal,
    protein,
    carbs,
    fat,
    units: (units || []).map(([label, grams]) => ({ label, grams })),
    halal: "unknown" as const,
    favorite: 0 as const,
    useCount: 0,
    updatedAt: now,
  }));
}

/** Eiweißreiche, günstige Optionen für den regelbasierten Abendvorschlag (ohne KI) */
export const PROTEIN_SNACKS: { name: string; kcal: number; protein: number; carbs: number; fat: number; unit: string; unitGrams: number; maxUnits: number; cost: string }[] = [
  { name: "Magerquark", kcal: 67, protein: 12, carbs: 4, fat: 0.3, unit: "g", unitGrams: 1, maxUnits: 500, cost: "ca. 0,60 € / 250 g" },
  { name: "Skyr natur", kcal: 63, protein: 11, carbs: 4, fat: 0.2, unit: "g", unitGrams: 1, maxUnits: 450, cost: "ca. 1,20 € / 450 g" },
  { name: "Hüttenkäse", kcal: 100, protein: 12.6, carbs: 2.6, fat: 4.3, unit: "g", unitGrams: 1, maxUnits: 400, cost: "ca. 0,90 € / 200 g" },
  { name: "Thunfisch im eigenen Saft", kcal: 110, protein: 25, carbs: 0, fat: 1, unit: "g", unitGrams: 1, maxUnits: 280, cost: "ca. 1,30 € / Dose" },
  { name: "Hähnchenbrustfilet (gebraten)", kcal: 105, protein: 23.5, carbs: 0, fat: 1.2, unit: "g", unitGrams: 1, maxUnits: 300, cost: "ca. 2,00 € / 250 g" },
  { name: "Eier (M)", kcal: 145, protein: 12.5, carbs: 0.7, fat: 10, unit: "Stück", unitGrams: 55, maxUnits: 4, cost: "ca. 0,25 € / Stück" },
];
