import type { Food } from "./db";
import { checkHalal } from "./halal";

/** Open Food Facts – Lebensmittelsuche & Barcode-Lookup (deutsche Produkte priorisiert) */

const FIELDS = [
  "code",
  "product_name",
  "product_name_de",
  "generic_name_de",
  "brands",
  "nutriments",
  "serving_size",
  "serving_quantity",
  "countries_tags",
  "labels_tags",
  "categories_tags",
  "ingredients_text_de",
  "ingredients_text",
  "image_front_small_url",
  "unique_scans_n",
].join(",");

type OffProduct = Record<string, unknown> & {
  code?: string;
  product_name?: string;
  product_name_de?: string;
  generic_name_de?: string;
  brands?: string | string[];
  nutriments?: Record<string, number | string>;
  serving_size?: string;
  serving_quantity?: number | string;
  countries_tags?: string[];
  labels_tags?: string[];
  categories_tags?: string[];
  ingredients_text_de?: string;
  ingredients_text?: string;
  image_front_small_url?: string;
};

function num(v: unknown): number | undefined {
  if (v == null || v === "") return undefined;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : undefined;
}

export interface OffFood extends Food {
  isGerman: boolean;
}

export function mapOffProduct(p: OffProduct): OffFood | null {
  const n = p.nutriments || {};
  let kcal = num(n["energy-kcal_100g"]);
  if (kcal == null) {
    const kj = num(n["energy-kj_100g"]) ?? num(n["energy_100g"]);
    if (kj != null) kcal = kj / 4.184;
  }
  if (kcal == null) return null;
  const name = (p.product_name_de || p.product_name || p.generic_name_de || "").trim();
  if (!name) return null;
  const brandRaw = Array.isArray(p.brands) ? p.brands[0] : (p.brands || "").split(",")[0];
  const brand = brandRaw ? String(brandRaw).trim() : undefined;
  const units: Food["units"] = [];
  const sq = num(p.serving_quantity);
  if (sq && sq > 0 && sq < 2000) {
    const label = p.serving_size ? `Portion (${String(p.serving_size).slice(0, 24)})` : `Portion (${sq} g)`;
    units.push({ label, grams: sq });
  }
  const halal = checkHalal({
    ingredients: p.ingredients_text_de || p.ingredients_text,
    labels: p.labels_tags,
    name,
    categories: p.categories_tags,
  });
  return {
    name,
    brand,
    barcode: p.code,
    source: "off",
    kcal: Math.round(kcal),
    protein: round1(num(n.proteins_100g) ?? 0),
    carbs: round1(num(n.carbohydrates_100g) ?? 0),
    fat: round1(num(n.fat_100g) ?? 0),
    units,
    halal: halal.status,
    halalNote: halal.reasons.join(", ") || undefined,
    favorite: 0,
    useCount: 0,
    imageUrl: p.image_front_small_url,
    updatedAt: Date.now(),
    isGerman: (p.countries_tags || []).some((c) => c === "en:germany" || c === "de:deutschland"),
  };
}

const round1 = (n: number) => Math.round(n * 10) / 10;

async function fetchJson(url: string, signal?: AbortSignal, timeoutMs = 9000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  const onAbort = () => ctrl.abort();
  signal?.addEventListener("abort", onAbort);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
    signal?.removeEventListener("abort", onAbort);
  }
}

function rank(list: OffFood[], query: string): OffFood[] {
  const q = query.toLowerCase();
  const seen = new Set<string>();
  const unique = list.filter((f) => {
    const k = f.barcode || `${f.name}|${f.brand}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return unique
    .map((f, i) => {
      let score = -i * 0.01;
      if (f.isGerman) score += 3;
      if (f.name.toLowerCase().startsWith(q)) score += 1;
      else if (f.name.toLowerCase().includes(q)) score += 0.5;
      if (f.protein + f.carbs + f.fat > 0) score += 0.5;
      if (f.halal === "warning") score -= 2;
      return { f, score };
    })
    .sort((a, b) => b.score - a.score)
    .map((x) => x.f);
}

export async function searchOff(query: string, signal?: AbortSignal): Promise<OffFood[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const errors: string[] = [];
  // 1) Search-a-licious (schnell)
  try {
    const url = `https://search.openfoodfacts.org/search?q=${encodeURIComponent(q)}&langs=de&page_size=40&fields=${FIELDS}`;
    const data = (await fetchJson(url, signal)) as { hits?: OffProduct[] };
    const mapped = (data.hits || []).map(mapOffProduct).filter((x): x is OffFood => !!x);
    if (mapped.length) return rank(mapped, q).slice(0, 30);
  } catch (e) {
    if (signal?.aborted) throw e;
    errors.push(String(e));
  }
  // 2) Klassische Suche auf de.openfoodfacts.org (nur in DE verkaufte Produkte)
  try {
    const url = `https://de.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(q)}&search_simple=1&action=process&json=1&page_size=30&sort_by=unique_scans_n&fields=${FIELDS}`;
    const data = (await fetchJson(url, signal, 12000)) as { products?: OffProduct[] };
    const mapped = (data.products || []).map(mapOffProduct).filter((x): x is OffFood => !!x);
    return rank(mapped.map((m) => ({ ...m, isGerman: true })), q).slice(0, 30);
  } catch (e) {
    if (signal?.aborted) throw e;
    errors.push(String(e));
    throw new Error("Open Food Facts nicht erreichbar");
  }
}

export async function lookupBarcode(code: string, signal?: AbortSignal): Promise<OffFood | null> {
  const clean = code.replace(/\D/g, "");
  if (!clean) return null;
  const url = `https://world.openfoodfacts.org/api/v2/product/${clean}.json?fields=${FIELDS}`;
  const data = (await fetchJson(url, signal)) as { status?: number; product?: OffProduct };
  if (!data || data.status !== 1 || !data.product) return null;
  const f = mapOffProduct({ ...data.product, code: data.product.code || clean });
  return f;
}
