"use client";
import { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Dumbbell, Play, Settings2, TrendingUp, ChevronRight } from "lucide-react";
import { db } from "@/lib/db";
import { useDay, useSettings } from "@/lib/hooks";
import { addDays, formatDate, rangeDates, todayStr, weekday, weekStart, WEEKDAYS_SHORT } from "@/lib/dates";
import { toggleActivity } from "@/lib/store";
import { e1rm, fmtKg, formatSets, lastPerformance, suggestNext, workoutVolume } from "@/lib/training";
import { fmt } from "@/lib/calc";
import { Button, Card, Chip, PageHeader, SectionTitle, Select, cx } from "@/components/ui";
import { WorkoutSheet, startWorkout } from "@/components/WorkoutSheet";
import { ExerciseManager } from "@/components/ExerciseManager";
import { LineChart } from "@/components/LineChart";

export default function TrainingPage() {
  const settings = useSettings();
  const today = todayStr();
  const day = useDay(today);
  const workouts = useLiveQuery(() => db.workouts.orderBy("date").reverse().toArray(), []);
  const defs = useLiveQuery(() => db.exercises.orderBy("order").toArray(), []);
  const weekDays = useLiveQuery(() => db.days.where("date").between(weekStart(today), addDays(weekStart(today), 6), true, true).toArray(), [today]);
  const [openId, setOpenId] = useState<number | null>(null);
  const [manage, setManage] = useState(false);
  const [chartEx, setChartEx] = useState("");

  const todayWorkout = workouts?.find((w) => w.date === today);
  const chartName = chartEx || defs?.find((d) => d.active)?.name || "";
  const chartPoints = useMemo(() => {
    if (!workouts || !chartName) return [];
    return [...workouts]
      .reverse()
      .map((w) => {
        const sets = w.exercises.find((e) => e.name === chartName)?.sets.filter((s) => s.done !== false && s.reps > 0) || [];
        if (!sets.length) return null;
        return { date: w.date, value: Math.max(...sets.map(e1rm)) };
      })
      .filter((p): p is { date: string; value: number } => !!p);
  }, [workouts, chartName]);

  if (!settings || !day || !workouts || !defs || !weekDays) return null;

  const planned = settings.schedule[weekday(today)] || [];
  const label = (k: string) => settings.activities.find((a) => a.key === k)?.label.replace(/ \(.*\)/, "") || k;
  const week = rangeDates(weekStart(today), addDays(weekStart(today), 6));
  const gymPlannedToday = planned.includes("gym");

  const start = async () => {
    const id = await startWorkout(today);
    setOpenId(id);
  };

  return (
    <div>
      <PageHeader title="Training" subtitle={planned.length ? `Heute geplant: ${planned.map(label).join(" + ")}` : "Heute: Ruhetag"} />

      {/* Wochenübersicht */}
      <Card className="!p-3">
        <div className="grid grid-cols-7 gap-1 text-center">
          {week.map((d) => {
            const plan = settings.schedule[weekday(d)] || [];
            const done = new Set([...(weekDays.find((x) => x.date === d)?.activities || []), ...(workouts.some((w) => w.date === d && w.exercises.some((e) => e.sets.some((x) => x.done))) ? ["gym"] : [])]);
            const allDone = plan.length > 0 && plan.every((p) => done.has(p));
            return (
              <div key={d} className={cx("rounded-2xl py-2", d === today && "bg-card2")}>
                <div className="text-[11px] font-semibold text-muted">{WEEKDAYS_SHORT[weekday(d)]}</div>
                <div
                  className={cx(
                    "mx-auto mt-1 flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-bold",
                    allDone || (plan.length === 0 && done.size > 0) ? "bg-accent-strong text-white dark:bg-accent dark:text-black" : plan.length ? "border-2 border-accent/50 text-fg" : "text-muted",
                  )}
                >
                  {plan.length ? plan.map((p) => label(p).slice(0, 1)).join("") : done.size ? "✓" : "–"}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Heute */}
      <SectionTitle>Heute abhaken</SectionTitle>
      <Card>
        <div className="flex flex-wrap gap-2">
          {settings.activities.map((a) => (
            <Chip key={a.key} active={day.activities.includes(a.key)} onClick={() => toggleActivity(today, a.key)} testId={`train-activity-${a.key}`}>
              {day.activities.includes(a.key) ? "✓ " : ""}
              {label(a.key)} · {a.minutes} min
            </Chip>
          ))}
        </div>
      </Card>

      {/* Gym */}
      <SectionTitle action={<button className="flex items-center gap-1 text-sm font-semibold text-accent-strong dark:text-accent" onClick={() => setManage(true)}><Settings2 size={15} /> Übungen</button>}>
        Ganzkörper-Training
      </SectionTitle>
      <Card>
        {todayWorkout ? (
          <Button size="lg" className="w-full" onClick={() => setOpenId(todayWorkout.id!)} data-testid="workout-open">
            <Dumbbell size={18} /> Heutiges Training öffnen
          </Button>
        ) : (
          <Button size="lg" variant={gymPlannedToday ? "primary" : "soft"} className="w-full" onClick={start} data-testid="workout-start">
            <Play size={18} /> Training starten{gymPlannedToday ? "" : " (ungeplant)"}
          </Button>
        )}
        <div className="mt-4 space-y-2.5" data-testid="next-targets">
          {defs
            .filter((d) => d.active)
            .map((d) => {
              const last = lastPerformance(workouts, d.name, today, todayWorkout?.id);
              const s = suggestNext(d, last);
              return (
                <div key={d.id} className="flex items-start justify-between gap-3 border-b border-line/60 pb-2.5 last:border-0 last:pb-0">
                  <div className="min-w-0">
                    <div className="truncate font-semibold">{d.name}</div>
                    <div className="text-[13px] text-muted">{last ? `Zuletzt: ${formatSets(last.sets)}` : `${d.sets} × ${d.repMin}–${d.repMax}`}</div>
                  </div>
                  <div className={cx("shrink-0 text-right text-[13px] font-semibold", s.kind === "increase" ? "text-accent-strong dark:text-accent" : "text-muted")}>
                    {s.kind === "increase" && <TrendingUp size={13} className="mr-1 inline" />}
                    {s.kind === "first" ? "neu" : `${fmtKg(s.sets[0].kg)} kg × ${s.sets.map((x) => x.reps).join("/")}`}
                  </div>
                </div>
              );
            })}
        </div>
      </Card>

      {/* Fortschritt pro Übung */}
      {workouts.length > 0 && (
        <>
          <SectionTitle>Kraftentwicklung</SectionTitle>
          <Card className="space-y-3">
            <Select value={chartName} onChange={(e) => setChartEx(e.target.value)} aria-label="Übung für Diagramm">
              {defs.map((d) => (
                <option key={d.id} value={d.name}>
                  {d.name}
                </option>
              ))}
            </Select>
            {chartPoints.length >= 2 ? (
              <LineChart points={chartPoints.map((p) => ({ ...p, trend: p.value }))} unit="kg (1RM geschätzt)" height={160} />
            ) : (
              <div className="py-4 text-center text-sm text-muted">Ab 2 Einheiten siehst du hier deinen Kraftverlauf.</div>
            )}
          </Card>
        </>
      )}

      {/* Verlauf */}
      <SectionTitle>Verlauf</SectionTitle>
      <Card className="!py-1" >
        {workouts.length === 0 && <div className="py-6 text-center text-sm text-muted">Noch kein Training gespeichert.</div>}
        {workouts.slice(0, 20).map((w) => (
          <button key={w.id} onClick={() => setOpenId(w.id!)} className="flex w-full items-center justify-between gap-3 border-b border-line/60 py-3 text-left last:border-0" data-testid="workout-history-item">
            <div className="min-w-0">
              <div className="font-semibold">{formatDate(w.date, { weekday: "short", day: "numeric", month: "short" })}</div>
              <div className="truncate text-[13px] text-muted">
                {w.exercises.length} Übungen · {w.exercises.reduce((s, e) => s + e.sets.length, 0)} Sätze · {fmt(workoutVolume(w))} kg Volumen
              </div>
            </div>
            <ChevronRight size={18} className="shrink-0 text-muted" />
          </button>
        ))}
      </Card>

      <WorkoutSheet id={openId} onClose={() => setOpenId(null)} />
      <ExerciseManager open={manage} onClose={() => setManage(false)} />
    </div>
  );
}
