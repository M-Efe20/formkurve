"use client";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Droplet, Footprints, Flame, Minus, AlertTriangle, Info } from "lucide-react";
import { db, MEALS, type Entry, type Food, type MealKey } from "@/lib/db";
import { useDay, useEntries, useNow, useStreak, useTargets } from "@/lib/hooks";
import { fmt, sumNutrients } from "@/lib/calc";
import { addDays, daysBetween, formatDate, relativeDayLabel, todayStr } from "@/lib/dates";
import Link from "next/link";
import { toggleActivity, updateDay } from "@/lib/store";
import { Bar, Card, Chip, IconButton, Notice, NumberInput, Button, Sheet, cx } from "@/components/ui";
import { Ring } from "@/components/Ring";
import { AddFoodSheet } from "@/components/AddFoodSheet";
import { PortionSheet, foodFromEntry } from "@/components/PortionSheet";
import { WeightQuickCard } from "@/components/WeightQuickCard";
import { CoachCard } from "@/components/CoachCard";

function mealForTime(d: Date): MealKey {
  const h = d.getHours() + d.getMinutes() / 60;
  if (h < 10.5) return "breakfast";
  if (h < 15) return "lunch";
  if (h < 17) return "snack";
  if (h < 21.5) return "dinner";
  return "snack";
}

export default function Dashboard() {
  const now = useNow();
  const today = todayStr();
  const [date, setDate] = useState(today);
  const { targets, settings } = useTargets(date);
  const entries = useEntries(date);
  const day = useDay(date);
  const streak = useStreak(settings);
  const totals = useMemo(() => sumNutrients(entries || []), [entries]);

  const [addOpen, setAddOpen] = useState(false);
  const [addMeal, setAddMeal] = useState<MealKey>("breakfast");
  const [edit, setEdit] = useState<{ entry: Entry; food: Food } | null>(null);
  const [stepsOpen, setStepsOpen] = useState(false);

  if (!targets || !settings || !entries || !day) return <div className="pt-safe" />;

  const remaining = targets.budget - totals.kcal;
  const isToday = date === today;
  const isPast = date < today;
  const lowWarn = settings.minKcal > 0 && totals.kcal < settings.minKcal && ((isPast && totals.kcal > 0) || (isToday && now.getHours() >= 20));

  const openAdd = (m: MealKey) => {
    setAddMeal(m);
    setAddOpen(true);
  };
  const openEdit = async (e: Entry) => {
    const f = (e.foodId && (await db.foods.get(e.foodId))) || foodFromEntry(e);
    setEdit({ entry: e, food: f });
  };

  const activityLabels = settings.activities;
  const plannedLabel = targets.plannedActivities.map((k) => activityLabels.find((a) => a.key === k)?.label.replace(/ \(.*\)/, "") || k).join(" + ");

  return (
    <div>
      {/* Kopfzeile mit Datum */}
      <header className="pt-safe mb-3 flex items-center justify-between gap-2">
        <IconButton label="Vorheriger Tag" onClick={() => setDate(addDays(date, -1))}>
          <ChevronLeft size={20} />
        </IconButton>
        <button className="min-w-0 flex-1 text-center" onClick={() => setDate(today)}>
          <div className="text-[22px] font-extrabold leading-tight tracking-tight" data-testid="day-label">
            {relativeDayLabel(date)}
          </div>
          <div className="text-[13px] font-medium text-muted">
            {formatDate(date, { weekday: "long", day: "numeric", month: "long" })} · {targets.isTraining ? `Trainingstag${plannedLabel ? ` (${plannedLabel})` : ""}` : "Ruhetag"}
          </div>
        </button>
        <IconButton label="Nächster Tag" onClick={() => setDate(addDays(date, 1))} disabled={date >= today}>
          <ChevronRight size={20} />
        </IconButton>
      </header>

      {/* Kalorienring */}
      <Card className="flex flex-col items-center pt-5">
        <Ring value={totals.kcal} max={targets.budget} size={208} stroke={18}>
          <div className={cx("text-[44px] font-extrabold leading-none tracking-tight tabular", remaining < 0 && "text-danger")} data-testid="kcal-remaining">
            {fmt(Math.abs(remaining))}
          </div>
          <div className="mt-1 text-sm font-semibold text-muted">{remaining >= 0 ? "kcal übrig" : "kcal drüber"}</div>
        </Ring>
        <div className="mt-3 grid w-full grid-cols-3 text-center">
          <div>
            <div className="text-lg font-bold tabular" data-testid="kcal-eaten">
              {fmt(totals.kcal)}
            </div>
            <div className="text-xs font-medium text-muted">gegessen</div>
          </div>
          <div>
            <div className="text-lg font-bold tabular" data-testid="kcal-budget">
              {fmt(targets.budget)}
            </div>
            <div className="text-xs font-medium text-muted">Budget</div>
          </div>
          <div>
            <div className="flex items-center justify-center gap-1 text-lg font-bold tabular" data-testid="streak">
              <Flame size={18} className={streak?.streak ? "fill-orange-500 text-orange-500" : "text-muted"} />
              {streak?.streak ?? 0}
            </div>
            <div className="text-xs font-medium text-muted">Tage im Ziel</div>
          </div>
        </div>

        <div className="mt-5 w-full space-y-3">
          <MacroRow label="Eiweiß" value={totals.protein} target={targets.protein} color="var(--protein)" />
          <MacroRow label="Kohlenhydrate" value={totals.carbs} target={targets.carbs} color="var(--carbs)" />
          <MacroRow label="Fett" value={totals.fat} target={targets.fat} color="var(--fat)" min />
        </div>

        {targets.clampedToFloor && (
          <Notice tone="info" className="mt-4 w-full">
            <span className="inline-flex items-start gap-2">
              <Info size={16} className="mt-0.5 shrink-0" /> Budget auf die Untergrenze von {fmt(settings.minKcal)} kcal angehoben.
            </span>
          </Notice>
        )}
        {lowWarn && (
          <Notice tone="warn" className="mt-4 w-full" >
            <span className="inline-flex items-start gap-2" data-testid="low-warning">
              <AlertTriangle size={16} className="mt-0.5 shrink-0" />
              {isPast
                ? `Nur ${fmt(totals.kcal)} kcal – unter ${fmt(settings.minKcal)} kcal riskierst du Muskelverlust.`
                : `Noch unter ${fmt(settings.minKcal)} kcal. Iss heute noch etwas Eiweißreiches.`}
            </span>
          </Notice>
        )}
      </Card>

      {isToday && <WeightQuickCard date={date} now={now} />}

      {isToday && <CoachCard date={date} now={now} totals={totals} targets={targets} settings={settings} entries={entries} />}

      {/* Wasser & Schritte */}
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Card className="!p-3.5">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-muted">
            <Droplet size={16} className="text-water" /> Wasser
          </div>
          <div className="mt-1 text-2xl font-extrabold tabular" data-testid="water">
            {fmt(day.waterMl / 1000, 2)} <span className="text-base font-semibold text-muted">/ {fmt(settings.waterGoalMl / 1000, 1)} l</span>
          </div>
          <Bar value={day.waterMl} max={settings.waterGoalMl} color="var(--water)" className="mt-2" />
          <div className="mt-3 flex gap-2">
            <IconButton label="250 ml weniger" className="h-9 w-9" onClick={() => updateDay(date, (d) => ({ waterMl: Math.max(0, d.waterMl - 250) }))}>
              <Minus size={16} />
            </IconButton>
            <Button size="sm" variant="soft" className="flex-1 !text-water !bg-water/12" onClick={() => updateDay(date, (d) => ({ waterMl: d.waterMl + 250 }))} data-testid="water-add">
              + 250 ml
            </Button>
          </div>
        </Card>
        <Card className="!p-3.5" onClick={() => setStepsOpen(true)}>
          <div className="flex items-center gap-1.5 text-sm font-semibold text-muted">
            <Footprints size={16} className="text-accent" /> Schritte
          </div>
          <div className="mt-1 text-2xl font-extrabold tabular" data-testid="steps">
            {day.steps != null ? fmt(day.steps) : "–"}
          </div>
          <Bar value={day.steps || 0} max={settings.stepGoal} marker={settings.stepGoalMin} color="var(--accent)" className="mt-2" />
          <div className="mt-3 text-[13px] font-medium text-muted">
            Ziel {fmt(settings.stepGoalMin)}–{fmt(settings.stepGoal)} · <span className="text-accent-strong dark:text-accent">eintragen</span>
          </div>
        </Card>
      </div>

      {/* Aktivitäten */}
      <Card className="mt-3 !p-3.5">
        <div className="mb-2 text-sm font-semibold text-muted">Sport {isToday ? "heute" : "an diesem Tag"}</div>
        <div className="flex flex-wrap gap-2">
          {settings.activities.map((a) => {
            const done = day.activities.includes(a.key);
            const planned = targets.plannedActivities.includes(a.key);
            return (
              <Chip key={a.key} active={done} onClick={() => toggleActivity(date, a.key)} testId={`activity-${a.key}`} className={cx(!done && planned && "ring-2 ring-accent/50")}>
                {done ? "✓ " : ""}
                {a.label.replace(/ \(.*\)/, "")}
                {planned && !done ? " · geplant" : ""}
              </Chip>
            );
          })}
        </div>
      </Card>

      {/* Mahlzeiten */}
      {MEALS.map((m) => {
        const list = entries.filter((e) => e.meal === m.key);
        const sum = sumNutrients(list);
        return (
          <Card key={m.key} className="mt-3 !p-0" >
            <div className="flex items-center justify-between px-4 pt-3 pb-2">
              <div>
                <div className="font-bold">{m.label}</div>
                <div className="text-[13px] text-muted tabular">
                  {list.length ? `${fmt(sum.kcal)} kcal · ${fmt(sum.protein)} g Eiweiß` : "Noch nichts eingetragen"}
                </div>
              </div>
              <button
                aria-label={`${m.label} hinzufügen`}
                data-testid={`add-${m.key}`}
                onClick={() => openAdd(m.key)}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-accent-strong text-white transition active:scale-90 dark:bg-accent dark:text-black"
              >
                <Plus size={22} strokeWidth={2.6} />
              </button>
            </div>
            {list.length > 0 && (
              <ul className="border-t border-line/70 px-4" data-testid={`entries-${m.key}`}>
                {list.map((e) => (
                  <li key={e.id}>
                    <button onClick={() => openEdit(e)} className="flex w-full items-center justify-between gap-3 border-b border-line/50 py-2.5 text-left last:border-0 active:opacity-60">
                      <div className="min-w-0">
                        <div className="truncate text-[15px] font-medium">{e.name}</div>
                        <div className="text-[13px] text-muted tabular">
                          {fmt(e.amount, 1)} {e.unit} · {fmt(e.protein)} g P
                        </div>
                      </div>
                      <div className="shrink-0 font-semibold tabular">{fmt(e.kcal)}</div>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        );
      })}

      {isToday && settings.startDate && daysBetween(settings.lastBackup || settings.startDate, today) > 14 && (
        <Link href="/settings/#daten" className="mt-3 block">
          <Notice tone="warn">Zeit für ein Backup – deine Daten liegen nur auf diesem Gerät. Jetzt sichern →</Notice>
        </Link>
      )}

      <div className="mt-4 text-center text-xs text-muted">
        Ø-Budget {fmt(targets.avgBudget)} kcal · Verbrauch {fmt(targets.tdee)} kcal ({targets.tdeeSource})
      </div>

      {/* Schnell-Hinzufügen */}
      <button
        aria-label="Essen hinzufügen"
        data-testid="fab-add"
        onClick={() => openAdd(isToday ? mealForTime(now) : "snack")}
        className="fixed right-4 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-accent-strong text-white shadow-xl shadow-emerald-900/25 transition active:scale-90 dark:bg-accent dark:text-black"
        style={{ bottom: "calc(env(safe-area-inset-bottom) + 84px)" }}
      >
        <Plus size={28} strokeWidth={2.6} />
      </button>

      <AddFoodSheet open={addOpen} onClose={() => setAddOpen(false)} date={date} meal={addMeal} />
      <PortionSheet food={edit?.food || null} entry={edit?.entry} date={date} meal={edit?.entry.meal || "snack"} onClose={() => setEdit(null)} />
      <StepsSheet open={stepsOpen} onClose={() => setStepsOpen(false)} date={date} current={day.steps} />
    </div>
  );
}

function MacroRow({ label, value, target, color, min }: { label: string; value: number; target: number; color: string; min?: boolean }) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-sm">
        <span className="font-semibold">{label}</span>
        <span className="tabular text-muted">
          <span className="font-bold text-fg">{fmt(value)}</span> / {min ? "min. " : ""}
          {fmt(target)} g
        </span>
      </div>
      <Bar value={value} max={target} color={color} />
    </div>
  );
}

function StepsSheet({ open, onClose, date, current }: { open: boolean; onClose: () => void; date: string; current?: number }) {
  const [v, setV] = useState<number | undefined>(current);
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) setV(current);
  }
  const save = async () => {
    await updateDay(date, { steps: v != null ? Math.round(v) : undefined });
    onClose();
  };
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Schritte eintragen"
      footer={
        <Button size="lg" className="w-full" onClick={save} data-testid="steps-save">
          Speichern
        </Button>
      }
    >
      <NumberInput value={v} onChange={setV} suffix="Schritte" autoFocus data-testid="steps-input" />
      <div className="mt-3 flex flex-wrap gap-2">
        {[1000, 2000, 5000].map((n) => (
          <Chip key={n} onClick={() => setV((v || 0) + n)}>
            + {fmt(n)}
          </Chip>
        ))}
      </div>
      <p className="mt-3 text-sm text-muted">Tipp: Die Zahl findest du in der Health-App unter „Schritte“.</p>
    </Sheet>
  );
}
