"use client";
import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { AlertTriangle, Camera, Trash2, TrendingDown, TrendingUp, Ruler, Brain } from "lucide-react";
import { db, type ProgressPhoto } from "@/lib/db";
import { useSettings, useWeights } from "@/lib/hooks";
import {
  avg7,
  computeAdaptive,
  computeTargets,
  dailyKcalMap,
  fmt,
  trendWeight,
  weeklyChange,
  weightSeries,
  ADAPTIVE_MIN_DAYS,
} from "@/lib/calc";
import { addDays, daysBetween, formatDate, todayStr } from "@/lib/dates";
import { saveSettings, setWeight } from "@/lib/store";
import { compressImage } from "@/lib/image";
import { Button, Card, Field, IconButton, Notice, NumberInput, PageHeader, SectionTitle, Segmented, Sheet, TextInput, cx } from "@/components/ui";
import { LineChart } from "@/components/LineChart";
import { useToast } from "@/components/Toast";

type Range = "28" | "90" | "all";

export default function ProgressPage() {
  const settings = useSettings();
  const weights = useWeights();
  const today = todayStr();
  const toast = useToast();
  const [date, setDate] = useState(today);
  const [kg, setKg] = useState<number | undefined>();
  const [range, setRange] = useState<Range>("28");

  const existing = weights?.find((w) => w.date === date);
  useEffect(() => {
    setKg(existing?.kg);
  }, [existing?.kg, date]);

  const series = useMemo(() => (weights ? weightSeries(weights) : []), [weights]);
  const shown = useMemo(() => {
    if (range === "all") return series;
    const from = addDays(today, -parseInt(range) + 1);
    return series.filter((p) => p.date >= from);
  }, [series, range, today]);

  if (!settings || !weights) return null;

  const cur = avg7(weights, today);
  const wc = weeklyChange(weights, today);
  const startW = settings.startWeightKg;
  const totalDiff = cur != null ? cur - startW : null;
  const toGoal = cur != null ? cur - settings.goalWeightKg : null;
  const weeksSinceStart = settings.startDate ? Math.max(1, daysBetween(settings.startDate, today) / 7) : 1;

  const save = async () => {
    if (!kg || kg < 30 || kg > 300) return;
    await setWeight(date, Math.round(kg * 10) / 10);
    toast({ text: `Gewicht für ${date === today ? "heute" : formatDate(date)} gespeichert` });
  };

  return (
    <div>
      <PageHeader title="Fortschritt" />

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <div className="font-bold">Gewicht eintragen</div>
          <input
            type="date"
            value={date}
            max={today}
            onChange={(e) => e.target.value && setDate(e.target.value)}
            className="rounded-xl bg-card2 px-3 py-1.5 text-sm font-semibold"
            aria-label="Datum"
          />
        </div>
        <div className="flex gap-2">
          <NumberInput value={kg} onChange={setKg} suffix="kg" className="flex-1" placeholder={cur ? fmt(cur, 1) : "kg"} data-testid="weight-input" />
          <Button size="lg" onClick={save} disabled={!kg} data-testid="weight-save">
            {existing ? "Ändern" : "Speichern"}
          </Button>
        </div>
        <p className="mt-2 text-xs text-muted">Täglich morgens wiegen – gezählt wird der 7-Tage-Durchschnitt, nicht der Tageswert.</p>
      </Card>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <Card className="!p-3.5">
          <div className="text-sm font-semibold text-muted">Ø 7 Tage</div>
          <div className="text-3xl font-extrabold tabular" data-testid="avg7">
            {cur != null ? fmt(cur, 1, 1) : "–"}
            <span className="text-base font-semibold text-muted"> kg</span>
          </div>
          <div className="mt-1 text-[13px] text-muted">
            {toGoal != null && toGoal > 0 ? `noch ${fmt(toGoal, 1, 1)} kg bis ${fmt(settings.goalWeightKg)} kg` : toGoal != null ? "Ziel erreicht" : ""}
          </div>
        </Card>
        <Card className="!p-3.5">
          <div className="text-sm font-semibold text-muted">Diese Woche</div>
          <div className={cx("flex items-center gap-1 text-3xl font-extrabold tabular", wc && wc.diffKg > 0 && "text-warn")} data-testid="weekly-change">
            {wc ? (
              <>
                {wc.diffKg <= 0 ? <TrendingDown size={22} /> : <TrendingUp size={22} />}
                {wc.diffKg > 0 ? "+" : ""}
                {fmt(wc.diffKg, 2)}
              </>
            ) : (
              "–"
            )}
            {wc && <span className="text-base font-semibold text-muted">kg</span>}
          </div>
          <div className="mt-1 text-[13px] text-muted tabular" data-testid="weekly-pct">
            {wc ? `${wc.pct > 0 ? "+" : ""}${fmt(wc.pct, 2)} % Körpergewicht` : "ab 8 Tagen Daten"}
          </div>
        </Card>
      </div>

      {wc?.tooFast && (
        <Notice tone="danger" className="mt-3">
          <span className="flex items-start gap-2" data-testid="too-fast">
            <AlertTriangle size={18} className="mt-0.5 shrink-0" />
            Du verlierst mehr als 1 % pro Woche ({fmt(Math.abs(wc.pct), 1)} %). Risiko für Muskelverlust – iss etwas mehr (z. B. Defizit um 100–200 kcal senken) und halte das Eiweiß hoch.
          </span>
        </Notice>
      )}
      {totalDiff != null && settings.startDate && (
        <div className="mt-2 px-1 text-[13px] text-muted">
          Seit Start ({formatDate(settings.startDate, { day: "numeric", month: "short" })}): <b className="text-fg tabular">{totalDiff > 0 ? "+" : ""}{fmt(totalDiff, 1)} kg</b> · Ø {fmt(totalDiff / weeksSinceStart, 2)} kg/Woche
        </div>
      )}

      <SectionTitle
        action={
          <Segmented
            size="sm"
            value={range}
            onChange={setRange}
            options={[
              { value: "28", label: "4 W" },
              { value: "90", label: "3 M" },
              { value: "all", label: "Alle" },
            ]}
          />
        }
      >
        Verlauf
      </SectionTitle>
      <Card>
        <LineChart points={shown.map((p) => ({ date: p.date, value: p.kg, trend: p.avg }))} goal={settings.goalWeightKg} testId="weight-chart" />
      </Card>

      <AdaptiveCard />
      <WaistCard />
      <PhotosCard />

      <SectionTitle>Letzte Wiegungen</SectionTitle>
      <Card className="!py-1">
        {[...weights].reverse().slice(0, 14).map((w) => (
          <div key={w.date} className="flex items-center justify-between border-b border-line/60 py-2.5 last:border-0">
            <span className="text-sm">{formatDate(w.date)}</span>
            <span className="flex items-center gap-3">
              <b className="tabular">{fmt(w.kg, 1, 1)} kg</b>
              <button aria-label="Wiegung löschen" className="text-muted" onClick={() => db.weights.delete(w.date)}>
                <Trash2 size={16} />
              </button>
            </span>
          </div>
        ))}
        {weights.length === 0 && <div className="py-4 text-center text-sm text-muted">Noch keine Wiegungen</div>}
      </Card>
    </div>
  );
}

function AdaptiveCard() {
  const settings = useSettings();
  const toast = useToast();
  const today = todayStr();
  const data = useLiveQuery(async () => {
    const [entries, weights] = await Promise.all([db.entries.where("date").between(addDays(today, -30), today, true, true).toArray(), db.weights.toArray()]);
    return { entries, weights };
  }, [today]);
  if (!settings || !data) return null;
  const tw = trendWeight(data.weights, today, settings.startWeightKg);
  const formula = computeTargets({ ...settings, adaptive: false }, tw, today).tdeeFormula;
  const r = computeAdaptive(dailyKcalMap(data.entries), data.weights, today, settings.startDate, formula);
  const progress = Math.min(1, (r.daysTracked || 0) / ADAPTIVE_MIN_DAYS);

  const apply = async () => {
    if (!r.tdee) return;
    await saveSettings({ adaptiveTdee: r.tdee, adaptiveUpdated: today, adaptive: true });
    toast({ text: `Verbrauch auf ${fmt(r.tdee)} kcal gesetzt` });
  };

  return (
    <>
      <SectionTitle>Adaptiver Verbrauch</SectionTitle>
      <Card className="space-y-3" >
        <div className="flex items-start gap-3" data-testid="adaptive-card">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-accent-soft text-accent-strong dark:text-accent">
            <Brain size={20} />
          </div>
          <div className="min-w-0 flex-1 text-sm">
            {!settings.adaptive ? (
              <span className="text-muted">Adaptiver Modus ist aus (Einstellungen).</span>
            ) : r.ready ? (
              <>
                <div className="font-semibold">
                  Echter Verbrauch ≈ <span className="tabular">{fmt(r.tdee!)} kcal</span>
                </div>
                <div className="text-muted">
                  Ø gegessen {fmt(r.avgIntake!)} kcal an {r.loggedDays} Tagen, Trend {fmt(r.kgPerWeek!, 2)} kg/Woche. Formel: {fmt(formula)} kcal.
                </div>
                {settings.adaptiveTdee && <div className="mt-1 text-muted">Aktuell genutzt: {fmt(settings.adaptiveTdee)} kcal (Stand {settings.adaptiveUpdated && formatDate(settings.adaptiveUpdated, { day: "numeric", month: "short" })}).</div>}
              </>
            ) : (
              <>
                <div className="font-semibold">Lernt deinen echten Verbrauch</div>
                <div className="text-muted">{r.reason}. Nach 3 Wochen wird dein Budget automatisch angepasst (danach wöchentlich).</div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-card2">
                  <div className="h-full rounded-full bg-accent" style={{ width: `${progress * 100}%` }} />
                </div>
              </>
            )}
          </div>
        </div>
        {settings.adaptive && r.ready && (
          <Button variant="soft" size="sm" onClick={apply} className="w-full">
            Jetzt übernehmen
          </Button>
        )}
      </Card>
    </>
  );
}

function WaistCard() {
  const waists = useLiveQuery(() => db.waists.orderBy("date").toArray(), []);
  const toast = useToast();
  const today = todayStr();
  const [cm, setCm] = useState<number | undefined>();
  if (!waists) return null;
  const last = waists[waists.length - 1];
  const first = waists[0];
  const dueIn = last ? 7 - daysBetween(last.date, today) : 0;
  const save = async () => {
    if (!cm || cm < 40 || cm > 200) return;
    await db.waists.put({ date: today, cm: Math.round(cm * 10) / 10 });
    setCm(undefined);
    toast({ text: "Taillenumfang gespeichert" });
  };
  return (
    <>
      <SectionTitle>Taillenumfang (wöchentlich)</SectionTitle>
      <Card className="space-y-3">
        <div className="flex items-center gap-3">
          <Ruler size={20} className="text-muted" />
          <div className="flex-1 text-sm">
            {last ? (
              <>
                Zuletzt <b className="tabular">{fmt(last.cm, 1)} cm</b> ({formatDate(last.date, { day: "numeric", month: "short" })})
                {first && first.date !== last.date && (
                  <span className="text-muted tabular">
                    {" "}
                    · {last.cm - first.cm > 0 ? "+" : ""}
                    {fmt(last.cm - first.cm, 1)} cm seit Start
                  </span>
                )}
              </>
            ) : (
              <span className="text-muted">Auf Bauchnabelhöhe messen, morgens, entspannt ausatmen.</span>
            )}
          </div>
        </div>
        {(!last || dueIn <= 0 || last.date === today) && (
          <div className="flex gap-2">
            <NumberInput value={cm} onChange={setCm} suffix="cm" className="flex-1" placeholder={last ? fmt(last.cm, 1) : "cm"} data-testid="waist-input" />
            <Button size="lg" onClick={save} disabled={!cm} data-testid="waist-save">
              Speichern
            </Button>
          </div>
        )}
        {last && dueIn > 0 && last.date !== today && <div className="text-xs text-muted">Nächste Messung in {dueIn} Tag{dueIn === 1 ? "" : "en"}.</div>}
        {waists.length >= 2 && <LineChart points={waists.map((w) => ({ date: w.date, value: w.cm }))} unit="cm" height={140} />}
      </Card>
    </>
  );
}

function usePhotoUrls(photos: ProgressPhoto[] | undefined) {
  const [urls, setUrls] = useState<Record<number, string>>({});
  useEffect(() => {
    if (!photos) return;
    const map: Record<number, string> = {};
    for (const p of photos) map[p.id!] = URL.createObjectURL(p.blob);
    setUrls(map);
    return () => Object.values(map).forEach((u) => URL.revokeObjectURL(u));
  }, [photos]);
  return urls;
}

function PhotosCard() {
  const photos = useLiveQuery(() => db.photos.orderBy("date").toArray(), []);
  const urls = usePhotoUrls(photos);
  const toast = useToast();
  const [view, setView] = useState<ProgressPhoto | null>(null);
  const [compare, setCompare] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const add = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) {
        const blob = await compressImage(f, 1600, 0.82);
        await db.photos.add({ date: todayStr(), blob });
      }
      toast({ text: "Foto gespeichert (nur lokal)" });
    } catch (e) {
      toast({ text: `Foto-Fehler: ${(e as Error).message}`, tone: "error" });
    } finally {
      setBusy(false);
    }
  };

  if (!photos) return null;
  const first = photos[0];
  const last = photos[photos.length - 1];

  return (
    <>
      <SectionTitle
        action={
          photos.length >= 2 ? (
            <button className="text-sm font-semibold text-accent-strong dark:text-accent" onClick={() => setCompare(true)}>
              Vergleichen
            </button>
          ) : undefined
        }
      >
        Fortschrittsfotos
      </SectionTitle>
      <Card>
        <div className="grid grid-cols-3 gap-2" data-testid="photo-grid">
          <label className={cx("flex aspect-[3/4] cursor-pointer flex-col items-center justify-center gap-1 rounded-2xl border-2 border-dashed border-line text-sm font-semibold text-muted", busy && "opacity-50")}>
            <Camera size={22} />
            {busy ? "…" : "Foto"}
            <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => add(e.target.files)} data-testid="photo-input" />
          </label>
          {[...photos].reverse().map((p) => (
            <button key={p.id} onClick={() => setView(p)} className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-card2">
              {urls[p.id!] && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={urls[p.id!]} alt={`Foto vom ${p.date}`} className="h-full w-full object-cover" />
              )}
              <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-2 pb-1.5 pt-4 text-left text-[11px] font-semibold text-white">
                {formatDate(p.date, { day: "numeric", month: "short", year: "2-digit" })}
              </span>
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted">Fotos bleiben nur auf diesem Gerät. Tipp: gleiches Licht, gleiche Pose, einmal pro Woche.</p>
      </Card>

      <Sheet
        open={!!view}
        onClose={() => setView(null)}
        title={view ? formatDate(view.date, { weekday: "short", day: "numeric", month: "long", year: "numeric" }) : ""}
        footer={
          <div className="flex gap-2">
            <Button
              variant="danger"
              size="lg"
              onClick={async () => {
                if (view?.id && confirm("Foto löschen?")) {
                  await db.photos.delete(view.id);
                  setView(null);
                }
              }}
            >
              <Trash2 size={18} /> Löschen
            </Button>
            <TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder={view?.note || "Notiz"} className="flex-1" />
            <Button
              size="lg"
              variant="secondary"
              onClick={async () => {
                if (view?.id) await db.photos.update(view.id, { note });
                setNote("");
                setView(null);
              }}
            >
              OK
            </Button>
          </div>
        }
      >
        {view && urls[view.id!] && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={urls[view.id!]} alt="" className="w-full rounded-2xl" />
        )}
        {view?.note && <p className="mt-2 text-sm text-muted">{view.note}</p>}
      </Sheet>

      <Sheet open={compare} onClose={() => setCompare(false)} title="Vorher / Nachher" full>
        {first && last && (
          <div className="grid grid-cols-2 gap-2">
            {[first, last].map((p, i) => (
              <figure key={p.id}>
                {urls[p.id!] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={urls[p.id!]} alt="" className="aspect-[3/4] w-full rounded-2xl object-cover" />
                )}
                <figcaption className="mt-1 text-center text-sm font-semibold">
                  {i === 0 ? "Start" : "Aktuell"} · {formatDate(p.date, { day: "numeric", month: "short", year: "2-digit" })}
                </figcaption>
              </figure>
            ))}
          </div>
        )}
        <Field label="" className="mt-2">
          <span className="text-xs text-muted">{daysBetween(first?.date || todayStr(), last?.date || todayStr())} Tage dazwischen</span>
        </Field>
      </Sheet>
    </>
  );
}
