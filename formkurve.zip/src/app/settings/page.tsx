"use client";
import { useMemo } from "react";
import { useSettings, useWeights } from "@/lib/hooks";
import { computeTargets, fmt, MANUAL_FACTORS, NEAT_LEVELS, trendWeight } from "@/lib/calc";
import { saveSettings } from "@/lib/store";
import { todayStr } from "@/lib/dates";
import type { Settings } from "@/lib/db";
import { Card, Field, NumberInput, PageHeader, SectionTitle, Segmented, Select, Toggle, Notice, SettingRow as Row } from "@/components/ui";
import { ScheduleEditor } from "@/components/ScheduleEditor";
import { AiSettings } from "@/components/AiSettings";
import { DataSettings } from "@/components/DataSettings";

export default function SettingsPage() {
  const s = useSettings();
  const weights = useWeights();
  const today = todayStr();
  const t = useMemo(() => (s && weights ? computeTargets(s, trendWeight(weights, today, s.startWeightKg), today) : null), [s, weights, today]);
  if (!s || !t) return null;
  const upd = (patch: Partial<Settings>) => saveSettings(patch);
  const num = (k: keyof Settings, min: number, max: number) => (v: number | undefined) => {
    if (v != null && v >= min && v <= max) upd({ [k]: v } as Partial<Settings>);
  };

  return (
    <div>
      <PageHeader title="Einstellungen" />

      <SectionTitle>Profil</SectionTitle>
      <Card className="space-y-3">
        <Segmented value={s.sex} onChange={(v) => upd({ sex: v })} options={[{ value: "m", label: "Männlich" }, { value: "f", label: "Weiblich" }]} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Alter">
            <NumberInput value={s.age} onChange={num("age", 14, 99)} suffix="Jahre" data-testid="set-age" />
          </Field>
          <Field label="Größe">
            <NumberInput value={s.heightCm} onChange={num("heightCm", 120, 230)} suffix="cm" />
          </Field>
          <Field label="Startgewicht">
            <NumberInput value={s.startWeightKg} onChange={num("startWeightKg", 35, 300)} suffix="kg" />
          </Field>
          <Field label="Zielgewicht">
            <NumberInput value={s.goalWeightKg} onChange={num("goalWeightKg", 35, 300)} suffix="kg" data-testid="set-goal" />
          </Field>
        </div>
      </Card>

      <SectionTitle>Kalorienbudget</SectionTitle>
      <Card className="space-y-4">
        <div className="grid grid-cols-3 gap-2 text-center">
          <Mini label="Grundumsatz" value={fmt(t.bmr)} />
          <Mini label={`Verbrauch (${t.tdeeSource})`} value={fmt(t.tdee)} />
          <Mini label="Ø Budget" value={fmt(t.avgBudget)} />
          <Mini label="Trainingstag" value={fmt(Math.max(s.minKcal, Math.round((t.avgBudget + t.trainingOffset) / 10) * 10))} accent />
          <Mini label="Ruhetag" value={fmt(Math.max(s.minKcal, Math.round((t.avgBudget + t.restOffset) / 10) * 10))} accent />
          <Mini label="Faktor" value={fmt(t.factor, 2)} />
        </div>
        <p className="text-xs text-muted">
          Mifflin-St Jeor mit aktuellem 7-Tage-Gewicht ({fmt(t.weightUsed, 1)} kg). {t.trainingDays} Trainingstage: +{t.trainingOffset} kcal, Ruhetage: {t.restOffset} kcal – Wochensumme bleibt gleich.
        </p>
        <Field label={`Defizit: ${s.deficit} kcal/Tag (≈ ${fmt((s.deficit * 7) / 7700, 2)} kg/Woche)`}>
          <input type="range" min={300} max={800} step={50} value={s.deficit} onChange={(e) => upd({ deficit: parseInt(e.target.value) })} className="w-full accent-emerald-500" data-testid="set-deficit" />
        </Field>
        <Field label="Aktivitätsfaktor">
          <Segmented
            value={s.activityMode}
            onChange={(v) => upd({ activityMode: v })}
            options={[
              { value: "auto", label: "Aus Trainingsplan" },
              { value: "manual", label: "Manuell" },
            ]}
          />
        </Field>
        {s.activityMode === "auto" ? (
          <Field label="Alltag (ohne Sport)">
            <Select value={s.neatFactor} onChange={(e) => upd({ neatFactor: parseFloat(e.target.value) })}>
              {NEAT_LEVELS.map((l) => (
                <option key={l.value} value={l.value}>
                  {l.label} ({fmt(l.value, 2)})
                </option>
              ))}
            </Select>
          </Field>
        ) : (
          <Field label="Faktor">
            <Select value={s.manualFactor} onChange={(e) => upd({ manualFactor: parseFloat(e.target.value) })}>
              {MANUAL_FACTORS.map((l) => (
                <option key={l.value} value={l.value}>
                  {l.label}
                </option>
              ))}
            </Select>
          </Field>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Trainingstag-Bonus" hint="Abstand Training ↔ Ruhe = 2×">
            <NumberInput value={s.trainingBonus} onChange={num("trainingBonus", 0, 400)} suffix="kcal" />
          </Field>
          <Field label="Untergrenze" hint="Warnung, wenn darunter">
            <NumberInput value={s.minKcal} onChange={num("minKcal", 1200, 3000)} suffix="kcal" />
          </Field>
        </div>
        <Row label="Adaptiver Modus" hint="Nach 3 Wochen echten Verbrauch aus Gewicht + Essen berechnen">
          <Toggle checked={s.adaptive} onChange={(v) => upd({ adaptive: v })} testId="set-adaptive" />
        </Row>
        {s.adaptive && s.adaptiveTdee && (
          <Notice tone="ok">
            Gemessener Verbrauch: {fmt(s.adaptiveTdee)} kcal (Stand {s.adaptiveUpdated}). Formel: {fmt(t.tdeeFormula)} kcal.
          </Notice>
        )}
      </Card>

      <SectionTitle>Makros</SectionTitle>
      <Card className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Eiweiß pro kg Zielgewicht">
            <NumberInput value={s.proteinPerKg} onChange={num("proteinPerKg", 1, 3)} suffix="g/kg" />
          </Field>
          <Field label="Fett min. pro kg Zielgewicht">
            <NumberInput value={s.fatPerKg} onChange={num("fatPerKg", 0.5, 1.5)} suffix="g/kg" />
          </Field>
        </div>
        <p className="text-sm text-muted">
          Heute: {t.protein} g Eiweiß · min. {t.fat} g Fett · {t.carbs} g Kohlenhydrate (Rest)
        </p>
      </Card>

      <SectionTitle>Tagesziele</SectionTitle>
      <Card className="grid grid-cols-3 gap-3">
        <Field label="Wasser">
          <NumberInput value={s.waterGoalMl / 1000} onChange={(v) => v && v >= 0.5 && v <= 6 && upd({ waterGoalMl: Math.round(v * 1000) })} suffix="l" />
        </Field>
        <Field label="Schritte min.">
          <NumberInput value={s.stepGoalMin} onChange={num("stepGoalMin", 1000, 30000)} />
        </Field>
        <Field label="Schritte Ziel">
          <NumberInput value={s.stepGoal} onChange={num("stepGoal", 1000, 40000)} />
        </Field>
      </Card>

      <SectionTitle>Trainingsplan</SectionTitle>
      <Card className="space-y-4">
        <ScheduleEditor schedule={s.schedule} activities={s.activities} onChange={(v) => upd({ schedule: v })} />
        <div className="space-y-2">
          {s.activities.map((a, i) => (
            <div key={a.key} className="grid grid-cols-[1fr_92px_80px] items-end gap-2">
              <div className="pb-3 text-sm font-semibold">{a.label}</div>
              <Field label="Minuten">
                <NumberInput
                  value={a.minutes}
                  onChange={(v) => v && v > 0 && v < 400 && upd({ activities: s.activities.map((x, j) => (j === i ? { ...x, minutes: v } : x)) })}
                />
              </Field>
              <Field label="MET">
                <NumberInput value={a.met} onChange={(v) => v && v >= 1 && v < 20 && upd({ activities: s.activities.map((x, j) => (j === i ? { ...x, met: v } : x)) })} />
              </Field>
            </div>
          ))}
          <p className="text-xs text-muted">MET = Intensität (Krafttraining ≈ 5, Volleyball ≈ 4, Boxtraining ≈ 7).</p>
        </div>
      </Card>

      <AiSettings />
      <DataSettings />

      <SectionTitle>Darstellung</SectionTitle>
      <Card>
        <Segmented
          value={s.theme}
          onChange={(v) => upd({ theme: v })}
          options={[
            { value: "system", label: "System" },
            { value: "light", label: "Hell" },
            { value: "dark", label: "Dunkel" },
          ]}
        />
      </Card>
      <p className="mt-6 text-center text-xs text-muted">Formkurve · alle Daten bleiben lokal auf diesem Gerät</p>
    </div>
  );
}

function Mini({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl bg-card2 px-2 py-2.5">
      <div className={`text-base font-bold tabular ${accent ? "text-accent-strong dark:text-accent" : ""}`}>{value}</div>
      <div className="text-[11px] font-medium leading-tight text-muted">{label}</div>
    </div>
  );
}
