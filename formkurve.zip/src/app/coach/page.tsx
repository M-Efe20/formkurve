"use client";
import { useState } from "react";
import Link from "next/link";
import { useLiveQuery } from "dexie-react-hooks";
import { Camera, Sparkles, MessageCircle, CalendarCheck, KeyRound } from "lucide-react";
import { db, type MealKey } from "@/lib/db";
import { useDay, useSettings } from "@/lib/hooks";
import { formatDate, todayStr, weekStart, addDays } from "@/lib/dates";
import { Button, Card, Notice, PageHeader, SectionTitle, Spinner } from "@/components/ui";
import { ReviewView, SuggestionView, useCoachRunner } from "@/components/CoachViews";
import { PhotoEstimateSheet } from "@/components/PhotoEstimateSheet";

function mealNow(): MealKey {
  const h = new Date().getHours();
  return h < 10 ? "breakfast" : h < 15 ? "lunch" : h < 17 ? "snack" : h < 22 ? "dinner" : "snack";
}

export default function CoachPage() {
  const settings = useSettings();
  const today = todayStr();
  const day = useDay(today);
  const notes = useLiveQuery(() => db.notes.orderBy("date").reverse().filter((n) => n.type === "weekly").toArray(), []);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [showOld, setShowOld] = useState(false);
  const runner = useCoachRunner(settings!, today);
  if (!settings || !day || !notes) return null;
  const hasKey = !!settings.apiKey;
  const thisWeek = notes.find((n) => n.date === weekStart(today));
  const older = notes.filter((n) => n !== thisWeek);

  return (
    <div>
      <PageHeader title="Coach" subtitle="Dein KI-Coach" />

      {!hasKey && (
        <Card className="mb-3">
          <div className="flex items-start gap-3">
            <KeyRound className="mt-0.5 shrink-0 text-muted" size={20} />
            <div className="text-sm">
              <div className="font-semibold">Claude API-Key fehlt</div>
              <p className="text-muted">Ohne Key gibt es einfache Vorschläge. Mit Key: persönliche Gerichte, Foto-Schätzung, Tagesfeedback und Wochenrückblick.</p>
              <Link href="/settings/" className="mt-2 inline-block font-semibold text-accent-strong dark:text-accent">
                Key eintragen →
              </Link>
            </div>
          </div>
        </Card>
      )}
      {runner.error && <Notice tone="warn" className="mb-3">{runner.error}</Notice>}

      <Card>
        <button className="flex w-full items-center gap-3 text-left" onClick={() => setPhotoOpen(true)} data-testid="coach-photo">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent-soft text-accent-strong dark:text-accent">
            <Camera size={22} />
          </div>
          <div>
            <div className="font-bold">Mahlzeit per Foto erfassen</div>
            <div className="text-sm text-muted">Claude schätzt Kalorien & Makros, du bestätigst.</div>
          </div>
        </button>
      </Card>

      <SectionTitle>Heute</SectionTitle>
      <Card>
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold">
            <Sparkles size={18} className="text-accent-strong dark:text-accent" /> Was kann ich noch essen?
          </div>
          {runner.busy === "suggestion" && <Spinner className="text-muted" />}
        </div>
        {day.suggestion ? (
          <>
            <SuggestionView s={day.suggestion} />
            <div className="mt-2 text-xs text-muted">Stand {day.suggestionAt ? new Date(day.suggestionAt).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) : ""}</div>
          </>
        ) : (
          <p className="text-sm text-muted">Vorschläge basierend auf deinen übrigen Kalorien und Eiweiß – halal, günstig, aus Aldi/Lidl/Rewe.</p>
        )}
        <Button variant="soft" className="mt-3 w-full" onClick={() => runner.run("suggestion")} disabled={!!runner.busy} data-testid="coach-suggest">
          {day.suggestion ? "Neu vorschlagen" : "Vorschlag holen"}
        </Button>
      </Card>

      <Card className="mt-3">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold">
            <MessageCircle size={18} className="text-accent-strong dark:text-accent" /> Tagesfeedback
          </div>
          {runner.busy === "feedback" && <Spinner className="text-muted" />}
        </div>
        <p className="text-[15px]" data-testid="coach-feedback-text">
          {day.feedback || <span className="text-sm text-muted">Kommt automatisch, sobald du dein Abendessen einträgst.</span>}
        </p>
        <Button variant="soft" className="mt-3 w-full" onClick={() => runner.run("feedback")} disabled={!hasKey || !!runner.busy} data-testid="coach-feedback">
          Feedback {day.feedback ? "aktualisieren" : "jetzt holen"}
        </Button>
      </Card>

      <SectionTitle>Wochenrückblick</SectionTitle>
      <Card>
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold">
            <CalendarCheck size={18} className="text-accent-strong dark:text-accent" /> Woche ab {formatDate(weekStart(today), { day: "numeric", month: "short" })}
          </div>
          {runner.busy === "weekly" && <Spinner className="text-muted" />}
        </div>
        {thisWeek ? <ReviewView r={thisWeek.data} /> : <p className="text-sm text-muted">Kommt jeden Sonntag automatisch. Du kannst ihn auch jetzt schon erstellen.</p>}
        <Button variant="soft" className="mt-3 w-full" onClick={() => runner.run("weekly")} disabled={!hasKey || !!runner.busy} data-testid="coach-weekly">
          {thisWeek ? "Neu erstellen" : "Jetzt erstellen"}
        </Button>
      </Card>

      {older.length > 0 && (
        <>
          <SectionTitle
            action={
              <button className="text-sm font-semibold text-accent-strong dark:text-accent" onClick={() => setShowOld(!showOld)}>
                {showOld ? "Ausblenden" : `Anzeigen (${older.length})`}
              </button>
            }
          >
            Frühere Wochen
          </SectionTitle>
          {showOld &&
            older.map((n) => (
              <Card key={n.id} className="mb-3">
                <div className="mb-2 text-sm font-bold text-muted">
                  {formatDate(n.date, { day: "numeric", month: "short" })} – {formatDate(addDays(n.date, 6), { day: "numeric", month: "short" })}
                </div>
                <ReviewView r={n.data} />
              </Card>
            ))}
        </>
      )}

      <PhotoEstimateSheet open={photoOpen} onClose={() => setPhotoOpen(false)} date={today} meal={mealNow()} />
    </div>
  );
}
