import { describe, it, expect } from "vitest";
import { checkHalal } from "../../src/lib/halal";
import { mapOffProduct } from "../../src/lib/off";

describe("Halal-Check", () => {
  it("erkennt Schwein, Alkohol und Gelatine", () => {
    expect(checkHalal({ ingredients: "Schweinefleisch, Salz, Gewürze" }).status).toBe("warning");
    expect(checkHalal({ ingredients: "Zucker, Rum, Aroma" }).reasons).toContain("Alkohol");
    expect(checkHalal({ ingredients: "Zucker, Glukosesirup, Gelatine, Säuerungsmittel" }).reasons[0]).toMatch(/Gelatine/);
  });
  it("keine Fehlalarme bei Zuckeralkohol, Weinsäure, Putenspeck-freien Produkten", () => {
    expect(checkHalal({ ingredients: "Zuckeralkohole (Maltit), Weinsäure, Milch" }).status).toBe("unknown");
    expect(checkHalal({ ingredients: "Rindergelatine, Zucker" }).status).toBe("unknown");
  });
  it("Halal-Siegel", () => {
    expect(checkHalal({ ingredients: "Hähnchen", labels: ["en:halal"] }).status).toBe("certified");
  });
  it("Unklare Zusatzstoffe", () => {
    expect(checkHalal({ ingredients: "Mehl, Emulgator E471" }).status).toBe("caution");
  });
});

describe("Open Food Facts Mapping", () => {
  it("mappt Nährwerte, Portion, Marke", () => {
    const f = mapOffProduct({
      code: "4061458003005",
      product_name_de: "Skyr Natur",
      brands: "Milsani,Aldi",
      nutriments: { "energy-kcal_100g": 63, proteins_100g: 11, carbohydrates_100g: 4, fat_100g: 0.2 },
      serving_quantity: 150,
      serving_size: "150 g",
      countries_tags: ["en:germany"],
      ingredients_text_de: "Magermilch, Milchsäurebakterien, Lab",
    })!;
    expect(f.name).toBe("Skyr Natur");
    expect(f.brand).toBe("Milsani");
    expect(f.kcal).toBe(63);
    expect(f.units[0].grams).toBe(150);
    expect(f.isGerman).toBe(true);
    expect(f.halal).toBe("caution");
  });
  it("rechnet kJ in kcal um und verwirft Produkte ohne Energie", () => {
    const f = mapOffProduct({ product_name: "Test", brands: ["X"], nutriments: { energy_100g: 418.4 } })!;
    expect(f.kcal).toBe(100);
    expect(f.brand).toBe("X");
    expect(mapOffProduct({ product_name: "Leer", nutriments: {} })).toBeNull();
  });
});
