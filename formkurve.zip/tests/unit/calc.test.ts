import { describe, it, expect } from "vitest";
import {
  bmr,
  computeTargets,
  defaultSettings,
  avg7,
  weeklyChange,
  computeAdaptive,
  computeStreak,
  gramsFor,
  nutrientsFor,
  weeklySportKcal,
  dayInGoal,
} from "../../src/lib/calc";
import { addDays, weekday } from "../../src/lib/dates";
import type { Settings, WeightLog } from "../../src/lib/db";

const me: Settings = {
  ...defaultSettings(),
  sex: "m",
  age: 30,
  heightCm: 182,
  startWeightKg: 88,
  goalWeightKg: 80,
  startDate: "2026-10-01",
};

// 2026-10-05 ist ein Montag
const MON = "2026-10-05";
const FRI = "2026-10-09";

describe("Grundumsatz & Budget", () => {
  it("Mifflin-St Jeor für Mann 88 kg / 182 cm / 30 J.", () => {
    expect(bmr("m", 88, 182, 30)).toBeCloseTo(1872.5, 1);
    expect(bmr("f", 60, 165, 30)).toBeCloseTo(600 + 1031.25 - 150 - 161, 1);
  });

  it("Wochentage stimmen", () => {
    expect(weekday(MON)).toBe(1);
    expect(weekday(FRI)).toBe(5);
  });

  it("Sport-kcal aus Plan (netto MET)", () => {
    // Gym 3x (5-1)*88*0.75 = 792, Volleyball (4-1)*88*1.5 = 396, Boxen (7-1)*88*1 = 528
    expect(weeklySportKcal(me, 88)).toBeCloseTo(792 + 396 + 528, 1);
  });

  it("Trainingstag/Ruhetag-Verteilung hält die Wochensumme gleich", () => {
    let sum = 0;
    let avg = 0;
    for (let i = 0; i < 7; i++) {
      const d = addDays(MON, i);
      const t = computeTargets({ ...me, minKcal: 0 }, 88, d);
      sum += t.rawBudget;
      avg = t.avgBudget;
    }
    expect(Math.abs(sum - avg * 7)).toBeLessThanOrEqual(7);
    const train = computeTargets(me, 88, MON);
    const rest = computeTargets(me, 88, FRI);
    expect(train.isTraining).toBe(true);
    expect(rest.isTraining).toBe(false);
    expect(train.rawBudget - rest.rawBudget).toBe(300);
  });

  it("Defizit wird abgezogen und Makros stimmen", () => {
    const t = computeTargets(me, 88, MON);
    expect(t.avgBudget).toBe(Math.round(t.tdeeFormula - 700) === t.avgBudget ? t.avgBudget : NaN);
    expect(t.protein).toBe(160);
    expect(t.fat).toBe(64);
    expect(t.carbs).toBe(Math.round((t.budget - 160 * 4 - 64 * 9) / 4));
    // plausibler Bereich
    expect(t.tdee).toBeGreaterThan(2500);
    expect(t.tdee).toBeLessThan(3200);
  });

  it("Untergrenze 1800 kcal greift", () => {
    const small: Settings = { ...me, heightCm: 160, startWeightKg: 60, deficit: 800, activityMode: "manual", manualFactor: 1.2 };
    const t = computeTargets(small, 60, FRI);
    expect(t.budget).toBe(1800);
    expect(t.clampedToFloor).toBe(true);
  });

  it("Ungeplante Aktivität macht Ruhetag zum Trainingstag", () => {
    const t = computeTargets(me, 88, FRI, ["volleyball"]);
    expect(t.isTraining).toBe(true);
  });

  it("Manueller Aktivitätsfaktor", () => {
    const t = computeTargets({ ...me, activityMode: "manual", manualFactor: 1.55 }, 88, MON);
    expect(t.tdeeFormula).toBe(Math.round(1872.5 * 1.55));
  });

  it("Adaptiver TDEE ersetzt Formel, wenn gesetzt", () => {
    const t = computeTargets({ ...me, adaptive: true, adaptiveTdee: 2600 }, 88, MON);
    expect(t.tdee).toBe(2600);
    expect(t.tdeeSource).toBe("adaptiv");
  });
});

describe("Gewicht", () => {
  const ws: WeightLog[] = [];
  for (let i = 0; i < 14; i++) ws.push({ date: addDays("2026-09-01", i), kg: 90 - i * 0.1 });

  it("7-Tage-Schnitt", () => {
    const a = avg7(ws, "2026-09-14")!;
    // Tage 7..13 → 90-0.7 … 90-1.3 → Schnitt 89.0
    expect(a).toBeCloseTo(89.0, 5);
  });

  it("Wochenveränderung + Warnung >1 %", () => {
    const wc = weeklyChange(ws, "2026-09-14")!;
    expect(wc.diffKg).toBeCloseTo(-0.7, 5);
    expect(wc.pct).toBeCloseTo((-0.7 / 89.7) * 100, 5);
    expect(wc.tooFast).toBe(false);
    const fast: WeightLog[] = ws.map((w, i) => ({ ...w, kg: 90 - i * 0.2 }));
    expect(weeklyChange(fast, "2026-09-14")!.tooFast).toBe(true);
  });
});

describe("Adaptiver Modus", () => {
  it("braucht 21 Tage", () => {
    const r = computeAdaptive(new Map(), [], "2026-10-10", "2026-10-01", 3000);
    expect(r.ready).toBe(false);
  });

  it("berechnet echten Verbrauch aus Aufnahme und Gewichtstrend", () => {
    const start = "2026-09-01";
    const today = "2026-09-29";
    const kcal = new Map<string, number>();
    const ws: WeightLog[] = [];
    for (let i = 0; i < 28; i++) {
      const d = addDays(start, i);
      kcal.set(d, 2300);
      ws.push({ date: d, kg: 90 - (0.5 / 7) * i }); // 0,5 kg/Woche
    }
    const r = computeAdaptive(kcal, ws, today, start, 3000);
    expect(r.ready).toBe(true);
    // 2300 + 0.5/7*7700 = 2850
    expect(r.tdee).toBeGreaterThan(2830);
    expect(r.tdee).toBeLessThan(2870);
    expect(r.kgPerWeek!).toBeCloseTo(-0.5, 2);
  });
});

describe("Streak", () => {
  it("zählt Tage in Folge im Ziel", () => {
    const today = "2026-10-09";
    const kcal = new Map<string, number>([
      ["2026-10-06", 2100],
      ["2026-10-07", 2200],
      ["2026-10-08", 2000],
      ["2026-10-09", 500],
    ]);
    const s = computeStreak(kcal, () => 2200, 1800, today);
    expect(s.streak).toBe(3);
    expect(s.todayCounts).toBe(false);
    kcal.set("2026-10-07", 2600); // drüber
    expect(computeStreak(kcal, () => 2200, 1800, today).streak).toBe(1);
    expect(dayInGoal(1700, 2200, 1800)).toBe(false);
  });
});

describe("Portionen", () => {
  it("Gramm und Nährwerte", () => {
    expect(gramsFor(2, "Stück", [{ label: "Stück", grams: 55 }])).toBe(110);
    expect(gramsFor(150, "g", [])).toBe(150);
    const n = nutrientsFor({ kcal: 67, protein: 12, carbs: 4, fat: 0.3 }, 250);
    expect(n.kcal).toBe(168);
    expect(n.protein).toBe(30);
  });
});
