import { describe, it, expect } from "vitest";
import { suggestNext, lastPerformance, formatSets } from "../../src/lib/training";
import type { Workout } from "../../src/lib/db";

const def = { repMin: 8, repMax: 12, increment: 2.5, sets: 3 };

describe("Progressive Overload", () => {
  it("erstes Mal", () => {
    expect(suggestNext(def, null).kind).toBe("first");
  });
  it("steigert Gewicht, wenn alle Sätze oben in der Spanne", () => {
    const s = suggestNext(def, { date: "2026-10-05", sets: [{ kg: 60, reps: 12 }, { kg: 60, reps: 12 }, { kg: 60, reps: 13 }] });
    expect(s.kind).toBe("increase");
    expect(s.sets[0]).toMatchObject({ kg: 62.5, reps: 8 });
  });
  it("sonst +1 Wiederholung pro Satz", () => {
    const s = suggestNext(def, { date: "2026-10-05", sets: [{ kg: 60, reps: 10 }, { kg: 60, reps: 9 }, { kg: 60, reps: 8 }] });
    expect(s.kind).toBe("reps");
    expect(s.sets.map((x) => x.reps)).toEqual([11, 10, 9]);
    expect(s.sets[0].kg).toBe(60);
  });
  it("hält Gewicht, wenn unter der Spanne", () => {
    const s = suggestNext(def, { date: "2026-10-05", sets: [{ kg: 80, reps: 5 }, { kg: 80, reps: 4 }, { kg: 80, reps: 4 }] });
    expect(s.kind).toBe("hold");
    expect(s.sets.every((x) => x.reps === 8 && x.kg === 80)).toBe(true);
  });
  it("findet die letzte Einheit und ignoriert nicht erledigte Sätze", () => {
    const ws: Workout[] = [
      { id: 1, date: "2026-10-01", name: "GK", createdAt: 1, exercises: [{ name: "Bankdrücken", sets: [{ kg: 50, reps: 10, done: true }] }] },
      { id: 2, date: "2026-10-05", name: "GK", createdAt: 2, exercises: [{ name: "Bankdrücken", sets: [{ kg: 52.5, reps: 8, done: true }, { kg: 52.5, reps: 8, done: false }] }] },
      { id: 3, date: "2026-10-07", name: "GK", createdAt: 3, exercises: [{ name: "Bankdrücken", sets: [{ kg: 55, reps: 8, done: true }] }] },
    ];
    const lp = lastPerformance(ws, "Bankdrücken", "2026-10-07", 3)!;
    expect(lp.date).toBe("2026-10-05");
    expect(lp.sets).toHaveLength(1);
    expect(formatSets([{ kg: 60, reps: 10 }, { kg: 60, reps: 9 }])).toBe("60 kg × 10 · 9");
  });
});
