import { test, expect } from "@playwright/test";
import { mockOff, collectErrors, onboard, num } from "./helpers";

test.describe("Phase 1: Budget, Essen erfassen, Dashboard", () => {
  test("Onboarding → Budget → Essen eintragen (lokal, online, Barcode, eigenes, Gericht)", async ({ page }) => {
    const errors = collectErrors(page);
    await mockOff(page);
    await onboard(page);

    // Budget plausibel (Freitag/Ruhetag oder Trainingstag)
    const budget = await num(page, "kcal-budget");
    expect(budget).toBeGreaterThanOrEqual(1800);
    expect(budget).toBeLessThan(2800);
    expect(await num(page, "kcal-remaining")).toBe(budget);
    await page.screenshot({ path: "tests/screens/01-dashboard-empty.png", fullPage: true });

    // --- Lokale Suche: Magerquark 250 g ---
    await page.getByTestId("add-breakfast").click();
    await expect(page.getByTestId("add-food-sheet")).toBeVisible();
    await page.getByTestId("food-search").fill("magerquark");
    await page.getByTestId("search-results").getByText("Magerquark").first().click();
    await expect(page.getByTestId("portion-sheet")).toBeVisible();
    await page.getByRole("combobox", { name: "Einheit" }).selectOption("g");
    await page.getByTestId("portion-amount").fill("250");
    await expect(page.getByTestId("portion-submit")).toContainText("168 kcal");
    await page.getByTestId("portion-submit").click();
    await expect(page.getByTestId("portion-sheet")).toBeHidden();

    // --- Online-Suche (Open Food Facts, gemockt) ---
    await page.getByTestId("food-search").fill("skyr");
    await expect(page.getByTestId("online-result").first()).toContainText("Skyr Natur");
    await page.getByTestId("online-result").first().locator("button").first().click();
    await expect(page.getByTestId("portion-sheet")).toContainText("Skyr Natur");
    // Standardportion = 1 Portion (150 g) → 95 kcal
    await expect(page.getByTestId("portion-submit")).toContainText("95 kcal");
    await page.getByTestId("portion-submit").click();

    // Halal-Warnung bei Gelatine
    await page.getByTestId("food-search").fill("goldbären");
    await expect(page.getByTestId("online-result").first()).toContainText("Nicht halal?");

    // --- Barcode (manuelle Eingabe, gemockter Lookup) ---
    await page.getByTestId("food-search").fill("");
    await page.getByTestId("btn-scan").click();
    await expect(page.getByTestId("barcode-scanner")).toBeVisible();
    const manualBtn = page.getByRole("button", { name: "Nummer eintippen" });
    if (await manualBtn.isVisible()) await manualBtn.click();
    await page.getByTestId("barcode-manual").fill("4260123456789");
    await page.getByRole("button", { name: "OK", exact: true }).click();
    await expect(page.getByTestId("portion-sheet")).toContainText("Protein Bar Cookie");
    await expect(page.getByTestId("portion-sheet")).toContainText("Halal");
    await page.getByTestId("portion-submit").click();

    // --- Eigenes Lebensmittel ---
    await page.getByTestId("btn-custom").click();
    await page.getByTestId("food-name").fill("Mamas Linsensuppe");
    await page.getByTestId("food-kcal").fill("90");
    await page.getByTestId("food-protein").fill("5,5");
    await page.getByTestId("food-carbs").fill("12");
    await page.getByTestId("food-fat").fill("2");
    await page.getByTestId("food-save").click();
    await expect(page.getByTestId("portion-sheet")).toContainText("Mamas Linsensuppe");
    await page.getByTestId("portion-amount").fill("400");
    await page.getByTestId("portion-submit").click();

    // --- Gericht ---
    await page.getByTestId("btn-recipe").click();
    await page.getByTestId("recipe-name").fill("Hähnchen-Reis-Bowl");
    await page.getByTestId("recipe-search").fill("hähnchenbrust");
    await page.getByTestId("recipe-editor").getByText("Hähnchenbrustfilet (roh)").first().click();
    await page.getByTestId("recipe-search").fill("reis roh");
    await page.getByTestId("recipe-editor").getByText("Reis (roh)").first().click();
    await expect(page.getByTestId("recipe-save")).toBeEnabled();
    await page.getByTestId("recipe-save").click();
    await expect(page.getByTestId("portion-sheet")).toContainText("Hähnchen-Reis-Bowl");
    await page.getByTestId("portion-submit").click();

    // --- Zuletzt: Schnell-Eintrag mit einem Tap ---
    await expect(page.getByTestId("list-recent")).toContainText("Magerquark");
    await page.getByTestId("list-recent").getByRole("button", { name: "Magerquark schnell eintragen" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Magerquark" })).toBeVisible();

    // Favoriten-Tab: Gericht ist automatisch Favorit
    await page.getByRole("tab", { name: "Favoriten" }).click();
    await expect(page.getByTestId("list-fav")).toContainText("Hähnchen-Reis-Bowl");
    await page.getByRole("button", { name: "Schließen" }).first().click();

    // Dashboard-Werte
    const eaten = await num(page, "kcal-eaten");
    // 168 + 95 + 200 (55 g Riegel) + 360 + Bowl + 168
    expect(eaten).toBeGreaterThan(1200);
    expect(await num(page, "kcal-remaining")).toBe(Math.abs(budget - eaten));
    await expect(page.getByTestId("entries-breakfast")).toContainText("Magerquark");

    // --- Eintrag bearbeiten & löschen mit Rückgängig ---
    await page.getByTestId("entries-breakfast").getByText("Skyr Natur").click();
    await page.getByTestId("portion-amount").fill("2");
    await page.getByTestId("portion-submit").click();
    await expect(page.getByTestId("entries-breakfast")).toContainText("2 Portion");
    await page.getByTestId("entries-breakfast").getByText("Skyr Natur").click();
    await page.getByRole("button", { name: "Eintrag löschen" }).click();
    await expect(page.getByTestId("entries-breakfast")).not.toContainText("Skyr Natur");
    await page.getByRole("button", { name: "Rückgängig" }).click();
    await expect(page.getByTestId("entries-breakfast")).toContainText("Skyr Natur");

    // --- Wasser, Schritte, Aktivität ---
    await page.getByTestId("water-add").click();
    await page.getByTestId("water-add").click();
    await expect(page.getByTestId("water")).toContainText("0,5");
    await page.getByTestId("steps").click();
    await page.getByTestId("steps-input").fill("9500");
    await page.getByTestId("steps-save").click();
    await expect(page.getByTestId("steps")).toContainText("9.500");
    await page.getByTestId("activity-volleyball").click();
    await expect(page.getByTestId("activity-volleyball")).toHaveAttribute("aria-pressed", "true");

    await page.screenshot({ path: "tests/screens/02-dashboard-filled.png", fullPage: true });

    // --- Einstellungen: Defizit ändert Budget ---
    const before = await num(page, "kcal-budget");
    await page.getByRole("link", { name: "Mehr" }).click();
    await page.getByTestId("set-deficit").fill("500");
    await page.getByRole("link", { name: "Heute" }).click();
    await expect.poll(() => num(page, "kcal-budget")).toBe(before + 200);

    // Persistenz nach Reload
    await page.reload();
    await expect(page.getByTestId("entries-breakfast")).toContainText("Magerquark");
    expect(errors).toEqual([]);
  });

  test("Dark Mode + 3-Tap-Flow über den Plus-Button", async ({ page }) => {
    await mockOff(page);
    await page.emulateMedia({ colorScheme: "dark" });
    await onboard(page);
    // Tap 1: +, Tap 2: Lebensmittel, Tap 3: Eintragen
    await page.getByTestId("fab-add").click();
    await page.getByTestId("food-search").fill("banane");
    await page.getByTestId("search-results").getByText("Banane").first().click();
    await page.getByTestId("portion-submit").click();
    await page.getByRole("button", { name: "Schließen" }).first().click();
    await expect(page.getByTestId("kcal-eaten")).toHaveText("112");
    await expect(page.locator("html")).toHaveClass(/dark/);
    await page.screenshot({ path: "tests/screens/03-dashboard-dark.png", fullPage: true });
    await page.getByTestId("fab-add").click();
    await page.screenshot({ path: "tests/screens/04-add-sheet-dark.png" });
  });
});
