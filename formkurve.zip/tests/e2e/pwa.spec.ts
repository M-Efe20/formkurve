import { test, expect } from "@playwright/test";

test.use({ serviceWorkers: "allow" });

test("PWA: Manifest, Icons, Service Worker & Offline-Start", async ({ page, context, request }) => {
  const m = await (await request.get("manifest.webmanifest")).json();
  expect(m.display).toBe("standalone");
  expect(m.start_url).toBe("./");
  for (const icon of m.icons) expect((await request.get(icon.src)).status()).toBe(200);
  expect((await request.get("icons/apple-touch-icon.png")).status()).toBe(200);

  await page.goto("./");
  await expect(page.locator('link[rel="manifest"]')).toHaveAttribute("href", "/formkurve/manifest.webmanifest");
  await expect(page.locator('link[rel="apple-touch-icon"]')).toHaveAttribute("href", "/formkurve/icons/apple-touch-icon.png");
  await expect(page.locator('meta[name="apple-mobile-web-app-capable"]')).toHaveAttribute("content", "yes");
  // SW aktiv
  await page.waitForFunction(async () => !!(await navigator.serviceWorker.ready).active, null, { timeout: 15000 });
  await page.reload();
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  await expect(page.getByText("Willkommen bei")).toBeVisible();

  // Offline: App startet weiterhin, auch Unterseiten
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByText("Willkommen bei")).toBeVisible();
  await page.goto("settings/");
  await expect(page.locator("body")).not.toContainText("ERR_INTERNET_DISCONNECTED");
  await context.setOffline(false);
});
