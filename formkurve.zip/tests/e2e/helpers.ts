import { expect, type Page } from "@playwright/test";

export const SKYR = {
  code: "4061458003005",
  product_name_de: "Skyr Natur",
  brands: ["Milsani"],
  nutriments: { "energy-kcal_100g": 63, proteins_100g: 11, carbohydrates_100g: 4, fat_100g: 0.2 },
  serving_quantity: 150,
  serving_size: "150 g",
  countries_tags: ["en:germany"],
  labels_tags: [],
  ingredients_text_de: "Magermilch, Milchsäurebakterienkulturen",
};

export const GUMMY = {
  code: "4001686301265",
  product_name_de: "Goldbären",
  brands: ["Haribo"],
  nutriments: { "energy-kcal_100g": 343, proteins_100g: 6.9, carbohydrates_100g: 77, fat_100g: 0.5 },
  countries_tags: ["en:germany"],
  ingredients_text_de: "Glukosesirup, Zucker, Gelatine, Dextrose",
};

export const PROTEIN_BAR = {
  code: "4260123456789",
  product_name: "Protein Bar Cookie",
  brands: "Barebells",
  nutriments: { "energy-kcal_100g": 364, proteins_100g: 36, carbohydrates_100g: 33, fat_100g: 14 },
  serving_quantity: 55,
  serving_size: "55 g",
  countries_tags: ["en:sweden"],
  labels_tags: ["en:halal"],
  ingredients_text: "Milk protein, sweetener",
};

export async function mockOff(page: Page) {
  await page.route("https://search.openfoodfacts.org/**", async (route) => {
    const q = new URL(route.request().url()).searchParams.get("q") || "";
    const hits = q.toLowerCase().includes("skyr") ? [SKYR] : q.toLowerCase().includes("gold") ? [GUMMY] : [];
    await route.fulfill({ json: { hits, count: hits.length }, headers: { "Access-Control-Allow-Origin": "*" } });
  });
  await page.route("https://de.openfoodfacts.org/**", (route) => route.fulfill({ json: { products: [] }, headers: { "Access-Control-Allow-Origin": "*" } }));
  await page.route("https://world.openfoodfacts.org/api/v2/product/**", async (route) => {
    const url = route.request().url();
    const product = url.includes(PROTEIN_BAR.code) ? PROTEIN_BAR : url.includes(SKYR.code) ? SKYR : null;
    await route.fulfill({ json: product ? { status: 1, product } : { status: 0 }, headers: { "Access-Control-Allow-Origin": "*" } });
  });
}

export function collectErrors(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !/Failed to load resource|net::ERR|favicon/.test(m.text())) errors.push(`console: ${m.text()}`);
  });
  return errors;
}

export async function onboard(page: Page, opts: { age?: string; height?: string; weight?: string; goal?: string } = {}) {
  await page.goto("./");
  await expect(page.getByText("Willkommen bei")).toBeVisible();
  await page.locator('input[name="age"]').fill(opts.age ?? "30");
  await page.locator('input[name="height"]').fill(opts.height ?? "182");
  await page.locator('input[name="weight"]').fill(opts.weight ?? "88");
  await page.locator('input[name="goal"]').fill(opts.goal ?? "80");
  await page.getByRole("button", { name: "Weiter" }).click();
  await page.getByRole("button", { name: "Weiter" }).click();
  await expect(page.getByText("Dein Plan")).toBeVisible();
  await page.getByTestId("onboarding-finish").click();
  await expect(page.getByTestId("kcal-budget")).toBeVisible();
}

export async function num(page: Page, testId: string): Promise<number> {
  const t = (await page.getByTestId(testId).innerText()).replace(/\./g, "").replace(",", ".");
  return parseFloat(t.match(/-?[\d.]+/)![0]);
}

/** Datenbank direkt im Browser befüllen (für Gewicht/Verlauf-Tests) */
export async function seed(page: Page, fn: string) {
  await page.evaluate(async (code) => {
    const open = indexedDB.open("formkurve");
    const db: IDBDatabase = await new Promise((res, rej) => {
      open.onsuccess = () => res(open.result);
      open.onerror = () => rej(open.error);
    });
    // eslint-disable-next-line no-new-func
    await new Function("db", `return (async () => { ${code} })()`)(db);
    db.close();
  }, fn);
}
