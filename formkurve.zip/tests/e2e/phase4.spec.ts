import { test, expect } from "@playwright/test";
import { mockOff, collectErrors, onboard } from "./helpers";

test("Phase 4: Trainingslog, Progressive Overload, Aktivitäten, Backup Export/Import", async ({ page, browser }) => {
  const errors = collectErrors(page);
  await page.clock.setFixedTime(new Date("2026-10-12T09:00:00+02:00")); // Montag → Gym geplant
  await mockOff(page);
  await onboard(page);
  // ein Essenseintrag, damit das Backup Inhalte hat
  await page.getByTestId("fab-add").click();
  await page.getByTestId("food-search").fill("skyr natur");
  await page.getByTestId("search-results").getByText("Skyr natur").first().click();
  await page.getByTestId("portion-submit").click();
  await page.getByRole("button", { name: "Schließen" }).first().click();

  await page.getByRole("link", { name: "Training" }).click();
  await expect(page.getByText("Heute geplant: Gym")).toBeVisible();
  await page.getByTestId("workout-start").click();
  await expect(page.getByTestId("workout-sheet")).toBeVisible();
  await expect(page.getByTestId("exercise-block")).toHaveCount(6);

  // Kniebeuge: 3 × 60 kg × 10 (obere Grenze) → nächstes Mal steigern
  for (let i = 1; i <= 3; i++) {
    await page.getByLabel(`Kniebeuge (Langhantel) Satz ${i} kg`).fill("60");
    await page.getByLabel(`Kniebeuge (Langhantel) Satz ${i} Wdh`).fill("10");
    await page.getByLabel(`Kniebeuge (Langhantel) Satz ${i} erledigt`).click();
  }
  // Bankdrücken: nur 1 Satz 50 × 8
  await page.getByLabel("Bankdrücken Satz 1 kg").fill("50");
  await page.getByLabel("Bankdrücken Satz 1 Wdh").fill("8");
  await page.getByLabel("Bankdrücken Satz 1 erledigt").click();
  await page.screenshot({ path: "tests/screens/09-workout.png" });
  await expect(page.getByTestId("workout-finish")).toContainText("4 Sätze");
  await page.getByTestId("workout-finish").click();
  await expect(page.getByRole("status").filter({ hasText: "2 Übungen, 4 Sätze" })).toBeVisible();
  await expect(page.getByTestId("workout-history-item")).toHaveCount(1);
  await expect(page.getByTestId("train-activity-gym")).toHaveAttribute("aria-pressed", "true");

  // Volleyball abhaken
  await page.getByTestId("train-activity-volleyball").click();
  await expect(page.getByTestId("train-activity-volleyball")).toHaveAttribute("aria-pressed", "true");

  // Mittwoch: Vorschläge für Progressive Overload
  await page.clock.setFixedTime(new Date("2026-10-14T18:00:00+02:00"));
  await page.reload();
  await expect(page.getByTestId("next-targets")).toContainText("62,5 kg × 6/6/6");
  await expect(page.getByTestId("next-targets")).toContainText("50 kg × 9/9/9");
  await page.getByTestId("workout-start").click();
  const squat = page.getByTestId("exercise-block").first();
  await expect(squat.getByTestId("last-time")).toContainText("60 kg × 10 · 10 · 10");
  await expect(squat.getByTestId("suggestion-text")).toContainText("Steigern: 62,5 kg");
  await expect(page.getByLabel("Kniebeuge (Langhantel) Satz 1 kg")).toHaveValue("62,5");
  await page.getByRole("button", { name: "Schließen" }).first().click();
  await page.screenshot({ path: "tests/screens/10-training.png", fullPage: true });

  // Backup exportieren
  await page.getByRole("link", { name: "Mehr" }).click();
  const [download] = await Promise.all([page.waitForEvent("download"), page.getByTestId("export").click()]);
  const path = "test-results/backup.json";
  await download.saveAs(path);
  const json = JSON.parse(require("fs").readFileSync(path, "utf8"));
  expect(json.app).toBe("formkurve");
  expect(json.tables.workouts.length).toBe(1); // angefangenes Training ohne Sätze wurde verworfen
  expect(json.tables.settings[0].apiKey).toBeUndefined();

  // In frischem Browser wiederherstellen (wie neues iPhone)
  const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "de-DE", timezoneId: "Europe/Berlin", serviceWorkers: "block" });
  const p2 = await ctx2.newPage();
  await p2.clock.setFixedTime(new Date("2026-10-14T18:00:00+02:00"));
  await p2.goto("http://localhost:4173/formkurve/");
  p2.on("dialog", (d) => d.accept());
  await p2.getByTestId("onboarding-import").setInputFiles(path);
  await expect(p2.getByTestId("kcal-budget")).toBeVisible();
  await p2.getByRole("button", { name: "Vorheriger Tag" }).click();
  await p2.getByRole("button", { name: "Vorheriger Tag" }).click();
  await expect(p2.getByTestId("entries-breakfast")).toContainText("Skyr natur");
  await p2.getByRole("link", { name: "Training" }).click();
  await expect(p2.getByTestId("workout-history-item")).toHaveCount(1);
  await ctx2.close();
  expect(errors).toEqual([]);
});
