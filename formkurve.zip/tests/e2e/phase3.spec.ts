import { test, expect, type Page } from "@playwright/test";
import { mockOff, collectErrors, onboard } from "./helpers";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
};

async function mockClaude(page: Page, calls: string[]) {
  await page.route("https://api.anthropic.com/**", async (route) => {
    const req = route.request();
    if (req.method() === "OPTIONS") return route.fulfill({ status: 204, headers: CORS });
    const url = req.url();
    if (url.includes("/v1/models")) {
      return route.fulfill({
        headers: CORS,
        json: { data: [{ id: "claude-sonnet-5-5", display_name: "Claude Sonnet 5.5" }, { id: "claude-haiku-5-5", display_name: "Claude Haiku 5.5" }] },
      });
    }
    const body = req.postDataJSON();
    expect(req.headers()["x-api-key"]).toBe("sk-ant-test");
    expect(req.headers()["anthropic-dangerous-direct-browser-access"]).toBe("true");
    const content = body.messages[0].content;
    const text = typeof content === "string" ? content : content.map((c: { text?: string }) => c.text || "").join(" ");
    const hasImage = Array.isArray(content) && content.some((c: { type: string }) => c.type === "image");
    let answer = "OK";
    if (hasImage) {
      calls.push("photo");
      answer = JSON.stringify({
        items: [
          { name: "Hähnchenbrust gegrillt", grams: 180, kcal: 297, protein: 55, carbs: 0, fat: 7 },
          { name: "Basmatireis", grams: 200, kcal: 260, protein: 5, carbs: 57, fat: 0.6 },
        ],
        confidence: "mittel",
        hinweis: "",
      });
    } else if (text.includes("Wochenrückblick")) {
      calls.push("weekly");
      answer = "```json\n" + JSON.stringify({ summary: "Solide Woche.", good: ["Eiweißziel oft erreicht"], improve: ["Mehr Wasser"], tips: ["Stell dir eine 1,5-l-Flasche auf den Schreibtisch."] }) + "\n```";
    } else if (text.includes("Feedback")) {
      calls.push("feedback");
      answer = "Starker Tag – Eiweiß fast erreicht, morgen noch etwas mehr Gemüse.";
    } else if (text.includes("Schlage 3")) {
      calls.push("suggestion");
      expect(text).toContain("halal");
      expect(body.system).toContain("kein Schwein");
      answer = JSON.stringify({
        intro: "Du hast noch Platz für eine eiweißreiche Mahlzeit.",
        options: [{ title: "Skyr-Bowl mit Beeren", items: [{ name: "Skyr natur", amount: "300 g" }, { name: "Beerenmix TK", amount: "100 g" }], kcal: 234, protein: 34, carbs: 19, fat: 1, prep: "Verrühren.", cost: "ca. 1,40 €" }],
        tip: "Iss langsam.",
      });
    } else {
      calls.push("test");
    }
    await route.fulfill({ headers: CORS, json: { id: "msg_1", type: "message", role: "assistant", content: [{ type: "text", text: answer }], stop_reason: "end_turn" } });
  });
}

test("Phase 3: KI-Coach mit gemockter Claude API (Sonntagabend)", async ({ page }) => {
  const errors = collectErrors(page);
  const calls: string[] = [];
  await page.clock.setFixedTime(new Date("2026-10-11T19:30:00+02:00")); // Sonntag, 19:30
  await mockOff(page);
  await mockClaude(page, calls);
  await onboard(page);

  // Ohne Key: regelbasierter Abendvorschlag auf dem Dashboard
  await expect(page.getByTestId("coach-card")).toContainText("Was geht heute noch?");
  await expect(page.getByTestId("suggestion")).toContainText("Magerquark");

  // API-Key eintragen & testen
  await page.getByRole("link", { name: "Mehr" }).click();
  await page.getByTestId("api-key").fill("sk-ant-test");
  await page.getByTestId("api-test").click();
  await expect(page.getByText(/Verbindung steht/)).toBeVisible();
  await expect(page.getByTestId("ai-model").locator("option")).toHaveCount(2);

  // Coach-Seite: KI-Vorschlag
  await page.getByRole("link", { name: "Coach" }).click();
  await page.getByTestId("coach-suggest").click();
  await expect(page.getByTestId("suggestion")).toContainText("Skyr-Bowl mit Beeren");

  // Foto-Schätzung → bestätigen → Einträge im Abendessen
  await page.getByTestId("coach-photo").click();
  await page.getByTestId("photo-file").setInputFiles("public/icons/icon-512.png");
  await page.getByTestId("photo-analyze").click();
  await expect(page.getByTestId("photo-items")).toContainText("");
  await expect(page.getByTestId("photo-items").locator('input[aria-label="Name"]').first()).toHaveValue("Hähnchenbrust gegrillt");
  // Reis auf 150 g korrigieren → kcal skaliert
  await page.getByTestId("photo-items").locator('input[aria-label="Gramm"]').nth(1).fill("150");
  await expect(page.getByTestId("photo-confirm")).toContainText("492 kcal");
  await page.screenshot({ path: "tests/screens/06-photo.png" });
  await page.getByTestId("photo-confirm").click();

  // Dashboard: Abendessen eingetragen → automatisches Tagesfeedback + Wochenrückblick (Sonntag)
  await page.getByRole("link", { name: "Heute" }).click();
  await expect(page.getByTestId("entries-dinner")).toContainText("Hähnchenbrust gegrillt");
  await expect(page.getByTestId("daily-feedback")).toContainText("Starker Tag");
  await expect(page.getByTestId("weekly-review")).toContainText("Solide Woche");
  await page.screenshot({ path: "tests/screens/07-coach-dashboard.png", fullPage: true });

  // Keine doppelten Auto-Aufrufe
  await page.waitForTimeout(500);
  expect(calls.filter((c) => c === "feedback").length).toBe(1);
  expect(calls.filter((c) => c === "weekly").length).toBe(1);

  // Coach-Seite zeigt den Rückblick
  await page.getByRole("link", { name: "Coach" }).click();
  await expect(page.getByTestId("weekly-review")).toContainText("Mehr Wasser");
  await page.screenshot({ path: "tests/screens/08-coach-page.png", fullPage: true });
  expect(errors).toEqual([]);
});

test("Phase 3: Fehlerbehandlung bei ungültigem Key", async ({ page }) => {
  await page.route("https://api.anthropic.com/**", (route) =>
    route.request().method() === "OPTIONS"
      ? route.fulfill({ status: 204, headers: CORS })
      : route.fulfill({ status: 401, headers: CORS, json: { type: "error", error: { type: "authentication_error", message: "invalid x-api-key" } } }),
  );
  await mockOff(page);
  await onboard(page);
  await page.getByRole("link", { name: "Mehr" }).click();
  await page.getByTestId("api-key").fill("sk-ant-falsch");
  await page.getByTestId("api-test").click();
  await expect(page.getByText("API-Key ungültig")).toBeVisible();
});
