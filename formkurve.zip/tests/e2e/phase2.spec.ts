import { test, expect } from "@playwright/test";
import { mockOff, collectErrors, onboard, seed } from "./helpers";

const DS = `function ds(off){ const d=new Date(); d.setDate(d.getDate()+off); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }`;

test("Phase 2: Gewicht, 7-Tage-Schnitt, Warnung, adaptiver Modus, Taille, Fotos", async ({ page }) => {
  const errors = collectErrors(page);
  await mockOff(page);
  await onboard(page);

  // 28 Tage Verlauf: 0,2 kg/Tag Abnahme (≈1,5 %/Woche → Warnung), 2.200 kcal/Tag gegessen
  await seed(
    page,
    `${DS}
    const tx = db.transaction(['weights','entries','settings'], 'readwrite');
    for (let i = 28; i >= 0; i--) {
      tx.objectStore('weights').put({ date: ds(-i), kg: Math.round((90 - (28 - i) * 0.2) * 10) / 10 });
      if (i > 0) tx.objectStore('entries').add({ date: ds(-i), meal: 'lunch', name: 'Testessen', amount: 100, unit: 'g', grams: 100, kcal: 2200, protein: 150, carbs: 220, fat: 60, createdAt: Date.now() - i * 86400000 });
    }
    const s = tx.objectStore('settings');
    const r = s.get('main');
    r.onsuccess = () => { const v = r.result; v.startDate = ds(-28); s.put(v); };
    await new Promise((res) => (tx.oncomplete = res));`,
  );
  await page.reload();
  // Adaptiver Modus rechnet beim Start neu
  await expect(page.getByRole("status").filter({ hasText: "Budget angepasst" })).toBeVisible();
  await expect(page.getByText(/\(adaptiv\)/)).toBeVisible();

  // Streak: alle 28 Tage 2.200 kcal, Budget ≥ 2.200? → zumindest Zahl sichtbar
  await expect(page.getByTestId("streak")).toBeVisible();

  await page.getByRole("link", { name: "Fortschritt" }).click();
  await expect(page.getByTestId("avg7")).toContainText("85,0");
  await expect(page.getByTestId("weekly-change")).toContainText("-1,4");
  await expect(page.getByTestId("weekly-pct")).toContainText("%");
  await expect(page.getByTestId("too-fast")).toBeVisible();
  await expect(page.getByTestId("weight-chart").locator("path")).toHaveCount(1);
  await expect(page.getByTestId("adaptive-card")).toContainText("Echter Verbrauch");

  // Gewicht für heute ändern
  await page.getByTestId("weight-input").fill("84,1");
  await page.getByTestId("weight-save").click();
  await expect(page.getByText("84,1 kg").first()).toBeVisible();

  // Taille
  await page.getByTestId("waist-input").fill("104,5");
  await page.getByTestId("waist-save").click();
  await expect(page.getByText("104,5 cm")).toBeVisible();

  // Foto
  await page.getByTestId("photo-input").setInputFiles("public/icons/icon-512.png");
  await expect(page.getByTestId("photo-grid").locator("img")).toHaveCount(1);
  await page.screenshot({ path: "tests/screens/05-progress.png", fullPage: true });
  expect(errors).toEqual([]);
});
