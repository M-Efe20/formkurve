# Formkurve

Persönlicher Kalorien- & Fitness-Coach als PWA (Next.js, läuft komplett im Browser).

## Funktionen

- **Kalorienbudget**: Grundumsatz nach Mifflin-St Jeor, Gesamtumsatz aus Alltag + Trainingsplan (oder fester Faktor), einstellbares Defizit (300–800 kcal). Trainingstage bekommen 2 × Bonus mehr als Ruhetage, die Wochensumme bleibt gleich. Untergrenze (Standard 1.800 kcal) mit Warnhinweis. Makros: Eiweiß 2 g/kg Zielgewicht, Fett min. 0,8 g/kg, Rest Kohlenhydrate.
- **Essen erfassen**: Open-Food-Facts-Suche (deutsche Produkte zuerst), Barcode-Scanner, Halal-Check der Zutaten (Schwein, Alkohol, Gelatine, unklare Zusatzstoffe), eigene Lebensmittel & Gerichte, Zuletzt/Favoriten mit Ein-Tap-Eintrag, Portion in Gramm oder Einheiten, KI-Schätzung per Foto.
- **Dashboard**: Kalorienring, Makro-Balken, Wasser, Schritte, Streak, Sport abhaken.
- **Gewicht & Fortschritt**: 7-Tage-Durchschnitt, Verlauf, Wochenveränderung in kg und %, Warnung bei > 1 %/Woche, adaptiver Verbrauch nach 3 Wochen, Taillenumfang, Fortschrittsfotos (lokal).
- **KI-Coach (Claude API)**: Abendvorschlag (halal, eiweißreich, günstig, Aldi/Lidl/Rewe), Tagesfeedback nach dem Abendessen, Wochenrückblick am Sonntag. Ohne Key gibt es regelbasierte Vorschläge.
- **Training**: Ganzkörper-Log mit Werten vom letzten Mal und Progressive-Overload-Vorschlag (Doppel-Progression), Volleyball/Boxen abhakbar, Kraftverlauf.
- **Daten**: alles lokal in IndexedDB, Export/Import als JSON, offline nutzbar.

## Auf dem iPhone installieren

Seite in **Safari** öffnen → Teilen → **Zum Home-Bildschirm**.

## Entwicklung

```bash
npm install
npm run dev          # http://localhost:3000
npm test             # Unit-Tests (Vitest)
NEXT_PUBLIC_BASE_PATH=/formkurve npm run build && npm run e2e   # E2E-Tests (Playwright)
```

Deploy: Push auf `main` → GitHub Actions baut den statischen Export und veröffentlicht ihn auf GitHub Pages.
